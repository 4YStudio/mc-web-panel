import { ref, reactive, onMounted, onUnmounted, getCurrentInstance } from '/js/vue.esm-browser.js';
import { api } from '/js/api.js';
import { store } from '/js/store.js';
import { showToast, openModal, isLargeFile, uploadFileWithChunk, waitForPanel } from '/js/utils.js';

export default {
    template: `
    <div class="animate-in">
        <div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
            <div class="d-flex align-items-center">
                <button @click="store.view = store.prevView || 'instance-manager'" class="btn-back me-3">
                    <i class="fa-solid fa-chevron-left"></i>
                </button>
                <div>
                    <h3 class="m-0 fw-bold d-flex align-items-center text-nowrap">
                        <i class="fa-solid fa-box-archive me-2 me-md-3 text-warning"></i>
                        <span>{{ $t('plugins.mc-panel-plugin-backup.title') }}</span>
                    </h3>
                    <p class="text-muted mb-0 mt-1 small d-none d-md-block">{{ $t('plugins.mc-panel-plugin-backup.description') }}</p>
                </div>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-warning btn-sm rounded-pill fw-bold" @click="triggerRestoreImport" :title="$t('panel_settings.import_backup')">
                    <i class="fa-solid fa-file-import"></i>
                    <span class="d-none d-sm-inline ms-1">{{ $t('panel_settings.import_backup') }}</span>
                </button>
                <button class="btn btn-warning btn-sm rounded-pill fw-bold" @click="askCreateGlobalBackup" :title="$t('panel_settings.create_global_backup')">
                    <i class="fa-solid fa-plus"></i>
                    <span class="d-none d-sm-inline ms-1">{{ $t('panel_settings.create_global_backup') }}</span>
                </button>
                <input type="file" ref="restoreInput" class="d-none" accept=".zip" @change="handleRestoreImport">
            </div>
        </div>

        <div class="card border-0 shadow-sm overflow-hidden" style="border-radius: 16px;">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-body-tertiary">
                        <tr class="small text-uppercase text-muted fw-bold">
                            <th class="px-3 px-md-4 py-3">{{ $t('common.name') }}</th>
                            <th>{{ $t('common.size') }}</th>
                            <th class="d-none d-sm-table-cell">{{ $t('common.time') }}</th>
                            <th class="text-end px-3 px-md-4">{{ $t('common.actions') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="b in globalBackups" :key="b.name">
                            <td class="px-3 px-md-4 py-3">
                                <div class="fw-bold small text-body">{{ b.name }}</div>
                                <div class="text-muted" style="font-size: 0.7rem;">{{ b.note || '-' }}</div>
                                <div class="d-sm-none text-muted" style="font-size: 0.7rem;">{{ new Date(b.mtime).toLocaleDateString() }}</div>
                            </td>
                            <td class="small text-nowrap">{{ (b.size/1024/1024).toFixed(1) }} MB</td>
                            <td class="small text-muted d-none d-sm-table-cell text-nowrap">{{ new Date(b.mtime).toLocaleString() }}</td>
                            <td class="text-end px-3 px-md-4">
                                <div class="d-flex justify-content-end gap-1">
                                    <button class="btn btn-xs btn-outline-success border-0" @click="downloadGlobalBackup(b)" :title="$t('common.download')">
                                        <i class="fa-solid fa-download"></i>
                                    </button>
                                    <button class="btn btn-xs btn-outline-primary border-0" @click="askRestoreGlobalBackup(b)" :title="$t('plugins.mc-panel-plugin-backup.backups.restore')">
                                        <i class="fa-solid fa-clock-rotate-left"></i>
                                    </button>
                                    <button class="btn btn-xs btn-outline-danger border-0" @click="deleteGlobalBackup(b)" :title="$t('common.delete')">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="!globalBackups.length && !loading">
                            <td colspan="4" class="text-center text-muted py-5 small">
                                <i class="fa-solid fa-folder-open d-block mb-2 opacity-25" style="font-size: 2rem;"></i>
                                {{ $t('common.no_data') }}
                            </td>
                        </tr>
                        <tr v-if="loading">
                            <td colspan="4" class="text-center py-5">
                                <div class="spinner-border spinner-border-sm text-primary"></div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    `,
    setup() {
        const { proxy } = getCurrentInstance();
        const $t = proxy.$t;
        const pluginApiBase = '/api/plugins/mc-panel-plugin-backup';

        const loading = ref(false);
        const saving = ref(false);
        const globalBackups = ref([]);
        const instances = ref([]);
        const javaList = ref([]);
        const restoreInput = ref(null);

        const loadGlobalBackups = async () => {
            try {
                loading.value = true;
                const res = await api.get(`${pluginApiBase}/list`);
                globalBackups.value = res.data;
            } catch (e) {
                showToast(e.message, 'danger');
            } finally {
                loading.value = false;
            }
        };

        const loadInstances = async () => {
            try {
                const res = await api.get('/api/instances/list');
                instances.value = res.data;
            } catch (e) { }
        };

        const loadJavaList = async () => {
            try {
                const res = await api.get('/api/java/installed');
                javaList.value = res.data;
            } catch (e) { }
        };

        const triggerRestoreImport = () => restoreInput.value.click();
        const handleRestoreImport = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            saving.value = true;
            try {
                let filename;
                if (isLargeFile(file)) {
                    store.task.visible = true;
                    store.task.title = $t('setup.restoring_uploading') || '正在上传备份...';
                    store.task.percent = 0;
                    store.task.message = file.name;
                    const chunkResult = await uploadFileWithChunk(file, {
                        initUrl: `${pluginApiBase}/import-chunk/init`,
                        completeUrl: `${pluginApiBase}/import-chunk/complete`,
                        onProgress: (bytesDone, bytesTotal, chunkNum, totalChunks) => {
                            store.task.percent = Math.round((bytesDone * 100) / bytesTotal);
                            store.task.subMessage = `${chunkNum} / ${totalChunks}`;
                        }
                    });
                    filename = chunkResult.filename;
                    setTimeout(() => { store.task.visible = false; }, 500);
                } else {
                    const formData = new FormData();
                    formData.append('backup', file);
                    showToast($t('setup.restoring_uploading') || '正在上传备份...', 'info');
                    const uploadRes = await api.post(`${pluginApiBase}/import`, formData, {
                        headers: { 'Content-Type': 'multipart/form-data' }
                    });
                    filename = uploadRes.data.filename;
                }
                
                showToast($t('plugins.mc-panel-plugin-backup.restoring'), 'info');
                await api.post(`${pluginApiBase}/restore`, { filename });
                
                setTimeout(() => window.location.reload(), 5000);
            } catch (e) {
                saving.value = false;
                showToast(e.response?.data?.error || e.message, 'danger');
            }
            e.target.value = '';
        };

        const askCreateGlobalBackup = () => {
            const managedJava = javaList.value.filter(j => j.source !== 'local');

            const instanceListHtml = instances.value.length ? `
                <div class="mt-2 p-2 bg-body-tertiary rounded small" style="max-height: 150px; overflow-y: auto;">
                    ${instances.value.map(i => `
                        <div class="form-check mb-1">
                            <input class="form-check-input check-inst-item" type="checkbox" value="${i.id}" id="check-inst-${i.id}" checked>
                            <label class="form-check-label" for="check-inst-${i.id}">${i.name} <span class="opacity-50">(${i.id})</span></label>
                        </div>
                    `).join('')}
                </div>
            ` : `<div class="small text-muted py-2">${$t('plugins.mc-panel-plugin-backup.no_instances')}</div>`;

            const javaListHtml = managedJava.length ? `
                <div class="mt-2 p-2 bg-body-tertiary rounded small" style="max-height: 150px; overflow-y: auto;">
                    ${managedJava.map(j => `
                        <div class="form-check mb-1">
                            <input class="form-check-input check-java-item" type="checkbox" value="${j.id}" id="check-java-${j.id}" checked>
                            <label class="form-check-label" for="check-java-${j.id}">Java ${j.featureVersion} <span class="opacity-50">(${j.id})</span></label>
                        </div>
                    `).join('')}
                </div>
            ` : `<div class="small text-muted py-2">${$t('plugins.mc-panel-plugin-backup.no_java')}</div>`;

            openModal({
                title: $t('panel_settings.create_global_backup'),
                message: `
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-muted">${$t('plugins.mc-panel-plugin-backup.backups.prompt_note')}</label>
                        <input type="text" id="backup-note" class="form-control form-control-sm" placeholder="e.g. Before update">
                    </div>
                    <div class="small fw-bold text-muted mb-2">${$t('plugins.mc-panel-plugin-backup.backup_include')}</div>
                    <div class="form-check small mb-1">
                        <input class="form-check-input" type="checkbox" id="check-configs" checked>
                        <label class="form-check-label" for="check-configs">${$t('plugins.mc-panel-plugin-backup.backup_configs')}</label>
                    </div>
                    
                    <div class="mt-3 ms-2">
                        <div class="form-check small mb-1">
                            <input class="form-check-input" type="checkbox" id="check-java-all" checked onchange="document.querySelectorAll('.check-java-item').forEach(i=>i.checked=this.checked)">
                            <label class="form-check-label fw-bold" for="check-java-all">${$t('plugins.mc-panel-plugin-backup.backup_java')}</label>
                        </div>
                        ${javaListHtml}
                    </div>

                    <div class="mt-3 ms-2">
                        <div class="form-check small mb-1">
                            <input class="form-check-input" type="checkbox" id="check-inst-all" checked onchange="document.querySelectorAll('.check-inst-item').forEach(i=>i.checked=this.checked)">
                            <label class="form-check-label fw-bold" for="check-inst-all">${$t('plugins.mc-panel-plugin-backup.backup_instances')}</label>
                        </div>
                        ${instanceListHtml}
                    </div>
                `,
                callback: async () => {
                    const note = document.getElementById('backup-note').value;
                    const configs = document.getElementById('check-configs').checked;
                    
                    const javaItems = Array.from(document.querySelectorAll('.check-java-item:checked')).map(i => i.value);
                    const instItems = Array.from(document.querySelectorAll('.check-inst-item:checked')).map(i => i.value);
                    
                    const options = {
                        configs,
                        java: javaItems,
                        instances: instItems
                    };

                    try {
                        showToast($t('common.processing'), 'info');
                        await api.post(`${pluginApiBase}/create`, { note, options });
                        showToast($t('common.success'), 'success');
                        loadGlobalBackups();
                    } catch (e) {
                        showToast(e.message, 'danger');
                    }
                }
            });
        };

        const downloadGlobalBackup = (b) => {
            window.open(`${pluginApiBase}/download?filename=${encodeURIComponent(b.name)}`, '_blank');
        };

        const askRestoreGlobalBackup = (b) => {
            openModal({
                title: $t('plugins.mc-panel-plugin-backup.backups.restore'),
                message: $t('plugins.mc-panel-plugin-backup.restore_confirm', { name: b.name }),
                callback: async () => {
                    try {
                        showToast($t('plugins.mc-panel-plugin-backup.restoring'), 'info');
                        await api.post(`${pluginApiBase}/restore`, { filename: b.name });
                        setTimeout(() => window.location.reload(), 5000);
                    } catch (e) {
                        showToast(e.message, 'danger');
                    }
                }
            });
        };

        const deleteGlobalBackup = (b) => {
            openModal({
                title: $t('common.delete'),
                message: $t('plugins.mc-panel-plugin-backup.backups.confirm_delete_msg', { name: b.name }),
                callback: async () => {
                    try {
                        await api.post(`${pluginApiBase}/delete`, { filename: b.name });
                        showToast($t('common.success'), 'success');
                        loadGlobalBackups();
                    } catch (e) {
                        showToast(e.message, 'danger');
                    }
                }
            });
        };

        onMounted(() => {
            loadGlobalBackups();
            loadInstances();
            loadJavaList();
        });

        return {
            store, loading, globalBackups,
            askCreateGlobalBackup, downloadGlobalBackup, askRestoreGlobalBackup, deleteGlobalBackup,
            restoreInput, triggerRestoreImport, handleRestoreImport
        };
    }
};
