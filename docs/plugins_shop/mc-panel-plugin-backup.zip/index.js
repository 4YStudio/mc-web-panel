const fs = require('fs-extra');
const path = require('path');
const archiver = require('archiver');
const AdmZip = require('adm-zip');
const crypto = require('crypto');
const os = require('os');
const express = require('express');
const multer = require('multer');

module.exports = async function (api) {
    const { registerRoutes, context } = api;
    const { 
        globalBackupDir: GLOBAL_BACKUP_DIR, 
        dataDir: DATA_DIR, 
        instancesDir: INSTANCES_DIR,
        instancesState,
        appendLog,
        getConfig
    } = context;

    const CHUNK_TEMP_DIR = path.join(DATA_DIR, 'tmp_uploads');
    const upload = multer({ dest: path.join(DATA_DIR, 'tmp_uploads') });

    const fixFileName = (name) => {
        return name.replace(/[\\/:*?"<>|]/g, '_');
    };

    const createGlobalBackup = async (options = { configs: true, java: [], instances: [] }, note = '') => {
        await fs.ensureDir(GLOBAL_BACKUP_DIR);
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `global_backup_${timestamp}.zip`;
        const zipPath = path.join(GLOBAL_BACKUP_DIR, filename);

        const instanceConfig = await fs.readJson(path.join(DATA_DIR, 'instances.json')).catch(() => ({ instances: [] }));

        // Notify all consoles
        instanceConfig.instances.forEach(inst => appendLog(inst.id, `[系统] 全局备份开始: ${filename}...\n`));

        return new Promise((resolve, reject) => {
            const output = fs.createWriteStream(zipPath);
            const archive = archiver('zip', { zlib: { level: 5 } });

            output.on('close', async () => {
                const metaPath = zipPath + '.meta.json';
                await fs.writeJson(metaPath, { note, options, createdAt: new Date() }, { spaces: 2 });
                instanceConfig.instances.forEach(inst => appendLog(inst.id, `[系统] 全局备份完成！大小: ${(archive.pointer() / 1024 / 1024).toFixed(1)} MB\n`));
                resolve({ filename, size: archive.pointer() });
            });

            archive.on('error', (err) => {
                instanceConfig.instances.forEach(inst => appendLog(inst.id, `[错误] 全局备份失败: ${err.message}\n`));
                reject(err);
            });

            archive.pipe(output);

            if (options.configs) {
                const files = fs.readdirSync(DATA_DIR);
                for (const file of files) {
                    const fullPath = path.join(DATA_DIR, file);
                    if (fs.statSync(fullPath).isFile() && (file.endsWith('.json') || file === 'executable_path.txt')) {
                        archive.file(fullPath, { name: `data/${file}` });
                    }
                }
            }

            if (Array.isArray(options.java)) {
                for (const javaId of options.java) {
                    const javaPath = path.join(DATA_DIR, 'java', javaId);
                    if (fs.existsSync(javaPath)) {
                        archive.directory(javaPath, `data/java/${javaId}`);
                    }
                }
            } else if (options.java === true) {
                const javaDir = path.join(DATA_DIR, 'java');
                if (fs.existsSync(javaDir)) archive.directory(javaDir, 'data/java');
            }

            if (Array.isArray(options.instances)) {
                for (const instId of options.instances) {
                    const instPath = path.join(INSTANCES_DIR, instId);
                    if (fs.existsSync(instPath)) {
                        archive.directory(instPath, `instances/${instId}`);
                    }
                }
            } else if (options.instances === true) {
                archive.directory(INSTANCES_DIR, 'instances');
            }

            archive.finalize();
        });
    };

    const router = express.Router();

    router.get('/list', async (req, res) => {
        const appConfig = getConfig();
        if (!appConfig.isSetup || req.session.authenticated) {
            try {
                const backups = [];
                if (fs.existsSync(GLOBAL_BACKUP_DIR)) {
                    const files = await fs.readdir(GLOBAL_BACKUP_DIR);
                    for (const file of files) {
                        if (file.endsWith('.zip')) {
                            const filePath = path.join(GLOBAL_BACKUP_DIR, file);
                            const stat = await fs.stat(filePath);
                            const metaPath = filePath + '.meta.json';
                            let meta = { note: '', options: {} };
                            if (fs.existsSync(metaPath)) {
                                try { meta = await fs.readJson(metaPath); } catch (e) { }
                            }
                            backups.push({
                                name: file,
                                size: stat.size,
                                mtime: stat.mtime,
                                note: meta.note || '',
                                options: meta.options || {}
                            });
                        }
                    }
                }
                backups.sort((a, b) => b.mtime - a.mtime);
                res.json(backups);
            } catch (e) { res.status(500).json({ error: e.message }); }
        } else {
            res.status(401).json({ error: 'Unauthorized' });
        }
    });

    router.post('/create', async (req, res) => {
        const { options, note } = req.body;
        try {
            const result = await createGlobalBackup(options, note);
            res.json({ success: true, ...result });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    router.post('/delete', async (req, res) => {
        const { filename } = req.body;
        const zipPath = path.join(GLOBAL_BACKUP_DIR, filename);
        try {
            if (fs.existsSync(zipPath)) {
                await fs.remove(zipPath);
                const metaPath = zipPath + '.meta.json';
                if (fs.existsSync(metaPath)) await fs.remove(metaPath).catch(() => { });
                res.json({ success: true });
            } else {
                res.status(404).json({ error: 'File not found' });
            }
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    router.get('/download', (req, res) => {
        const { filename } = req.query;
        const zipPath = path.join(GLOBAL_BACKUP_DIR, filename);
        if (!fs.existsSync(zipPath)) return res.status(404).send('Not Found');
        res.download(zipPath);
    });

    router.post('/import', upload.single('backup'), async (req, res) => {
        const appConfig = getConfig();
        if (!appConfig.isSetup || req.session.authenticated) {
            if (!req.file) return res.status(400).json({ error: 'No file' });
            const targetPath = path.join(GLOBAL_BACKUP_DIR, fixFileName(req.file.originalname));
            try {
                await fs.move(req.file.path, targetPath, { overwrite: true });
                const metaPath = targetPath + '.meta.json';
                await fs.writeJson(metaPath, { note: 'Imported Global Backup', createdAt: new Date() }, { spaces: 2 });
                res.json({ success: true, filename: path.basename(targetPath) });
            } catch (e) { res.status(500).json({ error: e.message }); }
        } else {
            res.status(401).json({ error: 'Unauthorized' });
        }
    });

    router.post('/import-chunk/init', async (req, res) => {
        const appConfig = getConfig();
        if (!(appConfig.isSetup ? req.session.authenticated : true)) return res.status(401).json({ error: 'Unauthorized' });
        const { fileName, fileSize, totalChunks } = req.body;
        const uploadId = crypto.randomBytes(16).toString('hex');
        const chunkDir = path.join(CHUNK_TEMP_DIR, uploadId);
        await fs.ensureDir(chunkDir);
        await fs.writeJson(path.join(chunkDir, '.meta'), {
            type: 'global-backup',
            fileName: fixFileName(fileName),
            fileSize,
            totalChunks,
            createdAt: Date.now()
        });
        res.json({ uploadId });
    });

    router.post('/import-chunk/complete', async (req, res) => {
        const appConfig = getConfig();
        if (!(appConfig.isSetup ? req.session.authenticated : true)) return res.status(401).json({ error: 'Unauthorized' });
        const { uploadId } = req.body;
        if (!uploadId) return res.status(400).json({ error: 'Missing uploadId' });
        const chunkDir = path.join(CHUNK_TEMP_DIR, uploadId);
        const metaPath = path.join(chunkDir, '.meta');
        if (!fs.existsSync(metaPath)) return res.status(404).json({ error: 'Upload session not found' });

        try {
            const meta = await fs.readJson(metaPath);
            const { fileName, totalChunks } = meta;
            const finalPath = path.join(GLOBAL_BACKUP_DIR, fileName);
            await fs.ensureDir(GLOBAL_BACKUP_DIR);

            const writeStream = fs.createWriteStream(finalPath);
            for (let i = 0; i < totalChunks; i++) {
                const chunkFile = path.join(chunkDir, String(i).padStart(6, '0'));
                if (!fs.existsSync(chunkFile)) {
                    writeStream.close();
                    await fs.remove(finalPath).catch(() => {});
                    return res.status(400).json({ error: `Chunk ${i} missing` });
                }
                const data = fs.readFileSync(chunkFile);
                writeStream.write(data);
            }
            await new Promise((resolve, reject) => {
                writeStream.end(resolve);
                writeStream.on('error', reject);
            });

            const metaJsonPath = finalPath + '.meta.json';
            await fs.writeJson(metaJsonPath, { note: 'Imported Global Backup', createdAt: new Date() }, { spaces: 2 });
            await fs.remove(chunkDir);
            res.json({ success: true, filename: path.basename(finalPath) });
        } catch (e) {
            res.status(500).json({ error: e.message });
            try { await fs.remove(path.join(CHUNK_TEMP_DIR, uploadId)); } catch (_) {}
        }
    });

    router.post('/restore', async (req, res) => {
        const appConfig = getConfig();
        if (appConfig.isSetup && !req.session.authenticated) return res.status(401).json({ error: 'Unauthorized' });

        const { filename } = req.body;
        const zipPath = path.join(GLOBAL_BACKUP_DIR, filename);
        if (!fs.existsSync(zipPath)) return res.status(404).json({ error: 'Backup not found' });

        try {
            // 1. Stop all MC servers
            for (const [id, state] of instancesState) {
                if (state.process) {
                    appendLog(id, '[系统] 全局还原中，正在停止服务器...\n');
                    state.process.kill();
                }
            }

            // 2. Extract backup to a temporary location
            const tempExtractDir = path.join(os.tmpdir(), `panel-restore-${Date.now()}`);
            await fs.ensureDir(tempExtractDir);

            const zip = new AdmZip(zipPath);
            zip.extractAllTo(tempExtractDir, true);

            // 3. Apply changes (move files from temp back to BASE_DIR)
            const applyAndRestart = async () => {
                try {
                    const dataRestoreDir = path.join(tempExtractDir, 'data');
                    if (fs.existsSync(dataRestoreDir)) {
                        const files = fs.readdirSync(dataRestoreDir);
                        for (const file of files) {
                            await fs.copy(path.join(dataRestoreDir, file), path.join(DATA_DIR, file), { overwrite: true });
                        }
                    }

                    const instancesRestoreDir = path.join(tempExtractDir, 'instances');
                    if (fs.existsSync(instancesRestoreDir)) {
                        await fs.copy(instancesRestoreDir, INSTANCES_DIR, { overwrite: true });
                    }

                    await fs.remove(tempExtractDir).catch(() => { });
                    process.exit(100);
                } catch (e) {
                    console.error('Failed to apply backup:', e);
                }
            };

            res.json({ success: true, message: 'Restore started, panel will restart.' });
            setTimeout(applyAndRestart, 1000);

        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    registerRoutes('/', router);

    api.registerSidebarItem({
        id: 'backup-manager',
        labelKey: 'plugins.mc-panel-plugin-backup.title',
        icon: 'fa-box-archive',
        color: '#f1c40f',
        view: 'plugin-mc-panel-plugin-backup-main',
        location: 'global'
    });

    api.registerComponent('plugin-mc-panel-plugin-backup-main', 'component/BackupManager.js');
};
