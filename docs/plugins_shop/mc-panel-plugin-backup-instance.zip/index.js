const fs = require('fs-extra');
const path = require('path');
const archiver = require('archiver');
const AdmZip = require('adm-zip');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');

module.exports = async function (api) {
    const { registerRoutes, context } = api;
    const { 
        baseDir: BASE_DIR,
        dataDir: DATA_DIR, 
        instancesDir: INSTANCES_DIR,
        instancesState,
        appendLog,
        getConfig,
        instanceConfig,
        saveInstances
    } = context;

    const CHUNK_TEMP_DIR = path.join(DATA_DIR, 'tmp_uploads');
    const upload = multer({ dest: path.join(DATA_DIR, 'tmp_uploads') });

    const fixFileName = (name) => {
        return name.replace(/[\\/:*?"<>|]/g, '_');
    };

    // Helper to get or create instance state (equivalent to core)
    const getOrCreateInstanceState = (id) => {
        if (!instancesState.has(id)) {
            instancesState.set(id, {
                process: null,
                onlinePlayers: new Set(),
                logHistory: [],
                detectedVersion: { mc: 'Unknown', loader: 'Unknown' },
                javaVersion: ''
            });
        }
        return instancesState.get(id);
    };

    const getInstancesDir = () => INSTANCES_DIR;
    const getInstanceDir = (instanceId) => {
        const inst = instanceConfig.instances.find(i => i.id === instanceId);
        return inst ? path.join(BASE_DIR, inst.dir) : null;
    };

    const withInstance = (req, res, next) => {
        const instanceId = (req.query && req.query.instanceId) || (req.body && req.body.instanceId) || instanceConfig.activeInstanceId || 'default';
        const instDir = getInstanceDir(instanceId);
        if (!instDir) return res.status(404).json({ error: '实例不存在' });
        req.instanceId = instanceId;
        req.instDir = instDir;
        req.instState = getOrCreateInstanceState(instanceId);
        next();
    };

    // --- Panel-Side Map Backup Logic ---
    const createPanelBackup = async (instanceId, isAuto = false, note = '') => {
        const instDir = getInstanceDir(instanceId);
        if (!instDir) return;
        const WORLD_DIR = path.join(instDir, 'world');
        const BACKUP_PANEL_DIR = path.join(instDir, 'backups', 'panel');
        const state = getOrCreateInstanceState(instanceId);
        const instConfig = instanceConfig.instances.find(i => i.id === instanceId);

        if (!fs.existsSync(WORLD_DIR)) {
            if (!isAuto) throw new Error('地图文件夹 (world) 不存在');
            return;
        }

        await fs.ensureDir(BACKUP_PANEL_DIR);

        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `manual_world_${timestamp}.zip`;
        const autoFilename = `auto_world_${timestamp}.zip`;
        const finalFilename = isAuto ? autoFilename : filename;
        const zipPath = path.join(BACKUP_PANEL_DIR, finalFilename);

        appendLog(instanceId, `[系统] ${isAuto ? '自动' : '手动'}备份开始: ${finalFilename}...\n`);

        if (state.process) {
            state.process.stdin.write('save-all flush\n');
            await new Promise(r => setTimeout(r, 2000));
        }

        return new Promise((resolve, reject) => {
            const output = fs.createWriteStream(zipPath);
            const archive = archiver('zip', { zlib: { level: 5 } });

            output.on('close', async () => {
                const metaPath = zipPath + '.meta.json';
                await fs.writeJson(metaPath, { note, locked: false, createdAt: new Date() }, { spaces: 2 });
                appendLog(instanceId, `[系统] 备份完成！大小: ${(archive.pointer() / 1024 / 1024).toFixed(1)} MB\n`);

                if (instConfig && instConfig.maxBackupCount > 0) {
                    try {
                        const files = await fs.readdir(BACKUP_PANEL_DIR);
                        const autoBackups = files.filter(f => f.startsWith('auto_world_') && f.endsWith('.zip')).sort();

                        const candidates = [];
                        for (const f of autoBackups) {
                            const mPath = path.join(BACKUP_PANEL_DIR, f + '.meta.json');
                            let isLocked = false;
                            if (fs.existsSync(mPath)) {
                                const meta = await fs.readJson(mPath);
                                if (meta.locked) isLocked = true;
                            }
                            if (!isLocked) candidates.push(f);
                        }

                        if (candidates.length > instConfig.maxBackupCount) {
                            const toDelete = candidates.slice(0, candidates.length - instConfig.maxBackupCount);
                            for (const f of toDelete) {
                                await fs.remove(path.join(BACKUP_PANEL_DIR, f));
                                await fs.remove(path.join(BACKUP_PANEL_DIR, f + '.meta.json')).catch(() => { });
                                appendLog(instanceId, `[系统] 已清理旧备份: ${f}\n`);
                            }
                        }
                    } catch (e) { console.error('Cleanup failed:', e); }
                }
                resolve();
            });

            archive.on('error', (err) => {
                appendLog(instanceId, `[错误] 备份失败: ${err.message}\n`);
                reject(err);
            });

            archive.pipe(output);
            archive.directory(WORLD_DIR, false);
            archive.finalize();
        });
    };

    const router = express.Router();

    // 1. 获取 mod 备份列表 (differential/snapshots)
    router.get('/list', withInstance, async (req, res) => {
        const BACKUP_DIFF_DIR = path.join(req.instDir, 'backups', 'differential');
        const BACKUP_SNAP_DIR = path.join(req.instDir, 'backups', 'snapshots');
        try {
            const backups = [];
            const scanDir = async (dir, type) => {
                if (fs.existsSync(dir)) {
                    const files = await fs.readdir(dir);
                    for (const file of files) {
                        if (file.endsWith('.zip')) {
                            const stat = await fs.stat(path.join(dir, file));
                            const isPartial = file.includes('partial');
                            backups.push({
                                name: file,
                                path: path.join(dir, file),
                                folder: type,
                                size: stat.size,
                                mtime: stat.mtime,
                                type: isPartial ? 'partial' : 'full'
                            });
                        }
                    }
                }
            };

            await scanDir(BACKUP_DIFF_DIR, 'differential');
            await scanDir(BACKUP_SNAP_DIR, 'snapshots');
            backups.sort((a, b) => b.mtime - a.mtime);
            res.json(backups);
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // 2. 创建 mod 备份 (在线备份指令)
    router.post('/create', withInstance, (req, res) => {
        const { instState, instanceId } = req;
        if (!instState.process) return res.json({ success: false, message: '服务器未运行，无法创建在线备份' });
        instState.process.stdin.write('backup start\n');
        appendLog(instanceId, '> backup start\n');
        res.json({ success: true, message: '备份指令已发送' });
    });

    // 3. 还原备份 (支持 panel, differential, snapshots)
    router.post('/restore', withInstance, async (req, res) => {
        const { instState, instDir, instanceId } = req;
        const { filename, folder, type } = req.body;
        const BACKUP_DIFF_DIR = path.join(instDir, 'backups', 'differential');
        const BACKUP_SNAP_DIR = path.join(instDir, 'backups', 'snapshots');
        const BACKUP_PANEL_DIR = path.join(instDir, 'backups', 'panel');
        const WORLD_DIR = path.join(instDir, 'world');

        let targetZipPath = '';
        if (folder === 'panel') {
            targetZipPath = path.join(BACKUP_PANEL_DIR, filename);
        } else {
            targetZipPath = path.join(folder === 'differential' ? BACKUP_DIFF_DIR : BACKUP_SNAP_DIR, filename);
        }

        const sendProgress = (step, total, msg) => {
            api.io.emit(`restore_progress:${instanceId}`, {
                percent: Math.round((step / total) * 100),
                message: msg
            });
        };

        if (instState.process) {
            instState.process.stdin.write('stop\n');
            appendLog(instanceId, '[系统] 正在停止服务器以进行回档...\n');
            sendProgress(10, 100, '正在停止服务器...');

            let checks = 0;
            while (instState.process && checks < 30) {
                await new Promise(r => setTimeout(r, 1000));
                checks++;
            }
            if (instState.process) return res.status(500).json({ error: '服务器无法停止，请手动停止' });
        }

        try {
            if (!fs.existsSync(targetZipPath)) return res.status(404).json({ error: '备份文件不存在' });

            sendProgress(30, 100, '正在备份当前地图...');
            if (fs.existsSync(WORLD_DIR)) {
                const backupName = `world_bak_${Date.now()}`;
                await fs.rename(WORLD_DIR, path.join(instDir, backupName));
                appendLog(instanceId, `[系统] 已将当前存档重命名为 ${backupName}\n`);
            }
            await fs.ensureDir(WORLD_DIR);

            const filesToUnzip = [];
            if (type === 'partial' && folder === 'differential') {
                const allFiles = await fs.readdir(BACKUP_DIFF_DIR);
                const fullBackups = allFiles.filter(f => f.includes('full') && f.endsWith('.zip')).sort();
                let baseBackup = null;
                for (const fb of fullBackups) {
                    if (fb < filename) baseBackup = fb; else break;
                }
                if (baseBackup) filesToUnzip.push(path.join(BACKUP_DIFF_DIR, baseBackup));
            }
            filesToUnzip.push(targetZipPath);

            const totalSteps = filesToUnzip.length;
            for (let i = 0; i < totalSteps; i++) {
                const zipPath = filesToUnzip[i];
                const currentProgress = 50 + Math.round(((i + 1) / totalSteps) * 40);
                sendProgress(currentProgress, 100, `正在解压 (${i + 1}/${totalSteps}): ${path.basename(zipPath)}`);
                appendLog(instanceId, `[系统] 解压中: ${path.basename(zipPath)}...\n`);
                const zip = new AdmZip(zipPath);
                zip.extractAllTo(WORLD_DIR, true);
            }

            sendProgress(100, 100, '回档完成');
            appendLog(instanceId, `[系统] 回档完成！请启动服务器。\n`);
            setTimeout(() => api.io.emit(`restore_completed:${instanceId}`), 1000);
            res.json({ success: true });
        } catch (e) {
            console.error(e);
            appendLog(instanceId, `[错误] 回档失败: ${e.message}\n`);
            api.io.emit(`restore_error:${instanceId}`, e.message);
            res.status(500).json({ error: e.message });
        }
    });

    // 4. 删除备份
    router.post('/delete', withInstance, async (req, res) => {
        const { instDir } = req;
        const { filename, folder } = req.body;
        const BACKUP_DIFF_DIR = path.join(instDir, 'backups', 'differential');
        const BACKUP_SNAP_DIR = path.join(instDir, 'backups', 'snapshots');
        const BACKUP_PANEL_DIR = path.join(instDir, 'backups', 'panel');

        try {
            let targetPath = '';
            if (folder === 'panel') {
                targetPath = path.join(BACKUP_PANEL_DIR, filename);
            } else {
                targetPath = path.join(folder === 'differential' ? BACKUP_DIFF_DIR : BACKUP_SNAP_DIR, filename);
            }

            const resolvedPath = path.resolve(targetPath);
            if (!resolvedPath.startsWith(path.resolve(BACKUP_DIFF_DIR)) &&
                !resolvedPath.startsWith(path.resolve(BACKUP_SNAP_DIR)) &&
                !resolvedPath.startsWith(path.resolve(BACKUP_PANEL_DIR))) {
                return res.status(403).json({ error: 'Access Denied' });
            }

            if (fs.existsSync(targetPath)) {
                if (folder === 'panel') {
                    const metaPath = targetPath + '.meta.json';
                    if (fs.existsSync(metaPath)) {
                        const meta = await fs.readJson(metaPath);
                        if (meta.locked) return res.status(403).json({ error: '备份已锁定，无法删除' });
                    }
                }

                await fs.remove(targetPath);

                if (folder === 'panel') {
                    const metaPath = targetPath + '.meta.json';
                    if (fs.existsSync(metaPath)) await fs.remove(metaPath).catch(() => { });
                }

                res.json({ success: true });
            } else {
                res.status(404).json({ error: 'File not found' });
            }
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // 5. 获取 panel 备份列表
    router.get('/panel/list', withInstance, async (req, res) => {
        const BACKUP_PANEL_DIR = path.join(req.instDir, 'backups', 'panel');
        try {
            const backups = [];
            if (fs.existsSync(BACKUP_PANEL_DIR)) {
                const files = await fs.readdir(BACKUP_PANEL_DIR);
                for (const file of files) {
                    if (file.endsWith('.zip')) {
                        const filePath = path.join(BACKUP_PANEL_DIR, file);
                        const stat = await fs.stat(filePath);
                        const metaPath = filePath + '.meta.json';
                        let meta = { note: '', locked: false };
                        if (fs.existsSync(metaPath)) {
                            try { meta = await fs.readJson(metaPath); } catch (e) { }
                        }
                        backups.push({
                            name: file,
                            path: filePath,
                            folder: 'panel',
                            size: stat.size,
                            mtime: stat.mtime,
                            type: file.startsWith('auto_') ? 'auto' : 'full',
                            note: meta.note || '',
                            locked: !!meta.locked
                        });
                    }
                }
            }
            backups.sort((a, b) => b.mtime - a.mtime);
            res.json(backups);
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // 6. 创建 panel 备份
    router.post('/panel/create', withInstance, async (req, res) => {
        try {
            await createPanelBackup(req.instanceId, false, req.body.note || '');
            res.json({ success: true });
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    // 7. 更新 panel 备份属性 (lock, note)
    router.post('/panel/update', withInstance, async (req, res) => {
        const { filename, note, locked } = req.body;
        const BACKUP_PANEL_DIR = path.join(req.instDir, 'backups', 'panel');
        const zipPath = path.join(BACKUP_PANEL_DIR, filename);
        const metaPath = zipPath + '.meta.json';
        try {
            if (!fs.existsSync(zipPath)) return res.status(404).json({ error: '备份不存在' });
            let meta = {};
            if (fs.existsSync(metaPath)) meta = await fs.readJson(metaPath);
            if (note !== undefined) meta.note = note;
            if (locked !== undefined) meta.locked = locked;
            await fs.writeJson(metaPath, meta, { spaces: 2 });
            res.json({ success: true });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // 8. 克隆备份为新实例
    router.post('/panel/clone', withInstance, async (req, res) => {
        const { filename, newName } = req.body;
        const { instDir, instanceId } = req;
        const sourceInst = instanceConfig.instances.find(i => i.id === instanceId);
        if (!sourceInst) return res.status(404).json({ error: '原实例不存在' });
        const zipPath = path.join(instDir, 'backups', 'panel', filename);

        if (!fs.existsSync(zipPath)) return res.status(404).json({ error: '备份文件不存在' });
        if (!newName) return res.status(400).json({ error: '新实例名称不能为空' });

        try {
            const newId = crypto.randomBytes(4).toString('hex');
            const newDir = `instances/${newId}`;
            const absNewDir = path.join(BASE_DIR, newDir);
            await fs.ensureDir(absNewDir);

            // 1. 复制环境文件
            await fs.copy(instDir, absNewDir, {
                filter: (src) => {
                    const rel = path.relative(instDir, src);
                    if (!rel) return true;
                    const top = rel.split(path.sep)[0];
                    return !['world', 'backups', 'logs'].includes(top);
                }
            });

            // 2. 解压备份到新实例的 world 文件夹
            const zip = new AdmZip(zipPath);
            const newWorldDir = path.join(absNewDir, 'world');
            await fs.ensureDir(newWorldDir);
            zip.extractAllTo(newWorldDir, true);

            // 3. 注册新实例
            instanceConfig.instances.push({
                id: newId,
                name: newName,
                dir: newDir,
                loaderType: sourceInst.loaderType || 'fabric',
                jarName: sourceInst.jarName,
                javaArgs: sourceInst.javaArgs,
                javaPath: sourceInst.javaPath,
                backupStrategy: 'panel',
                autoBackupEnabled: false,
                autoBackupInterval: 12,
                maxBackupCount: 10,
                createdAt: new Date().toISOString()
            });
            saveInstances(instanceConfig);
            getOrCreateInstanceState(newId);

            res.json({ success: true, newId });
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    // 9. 导入备份
    router.post('/panel/import', withInstance, upload.single('backup'), async (req, res) => {
        if (!req.file) return res.status(400).json({ error: '未检测到文件' });
        const { instDir } = req;
        const BACKUP_PANEL_DIR = path.join(instDir, 'backups', 'panel');
        await fs.ensureDir(BACKUP_PANEL_DIR);

        const targetPath = path.join(BACKUP_PANEL_DIR, fixFileName(req.file.originalname));
        try {
            await fs.move(req.file.path, targetPath, { overwrite: true });

            const metaPath = targetPath + '.meta.json';
            await fs.writeJson(metaPath, { note: 'Imported Backup', locked: false, createdAt: new Date() }, { spaces: 2 });

            res.json({ success: true });
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    // 10. 分片上传 init
    router.post('/panel/import-chunk/init', withInstance, async (req, res) => {
        const { instDir } = req;
        const { fileName, fileSize, totalChunks } = req.body;
        const uploadId = crypto.randomBytes(16).toString('hex');
        const chunkDir = path.join(CHUNK_TEMP_DIR, uploadId);
        await fs.ensureDir(chunkDir);
        await fs.writeJson(path.join(chunkDir, '.meta'), {
            type: 'panel-backup',
            fileName: fixFileName(fileName),
            fileSize,
            totalChunks,
            instDir,
            createdAt: Date.now()
        });
        res.json({ uploadId });
    });

    // 11. 分片上传 complete
    router.post('/panel/import-chunk/complete', withInstance, async (req, res) => {
        const { uploadId } = req.body;
        if (!uploadId) return res.status(400).json({ error: 'Missing uploadId' });
        const chunkDir = path.join(CHUNK_TEMP_DIR, uploadId);
        const metaPath = path.join(chunkDir, '.meta');
        if (!fs.existsSync(metaPath)) return res.status(404).json({ error: 'Upload session not found' });

        try {
            const meta = await fs.readJson(metaPath);
            const { fileName, totalChunks, instDir } = meta;
            if (!instDir.startsWith(req.instDir)) return res.status(403).json({ error: 'Access Denied' });

            const BACKUP_PANEL_DIR = path.join(instDir, 'backups', 'panel');
            await fs.ensureDir(BACKUP_PANEL_DIR);
            const finalPath = path.join(BACKUP_PANEL_DIR, fileName);

            const writeStream = fs.createWriteStream(finalPath);
            for (let i = 0; i < totalChunks; i++) {
                const chunkFile = path.join(chunkDir, String(i).padStart(6, '0'));
                if (!fs.existsSync(chunkFile)) {
                    writeStream.close();
                    await fs.remove(finalPath).catch(() => { });
                    return res.status(400).json({ error: `Chunk ${i} missing` });
                }
                const data = fs.readFileSync(chunkFile);
                writeStream.write(data);
            }
            await new Promise((resolve, reject) => {
                writeStream.end(resolve);
                writeStream.on('error', reject);
            });

            const metaJsonPath = finalPath + '.meta.json';
            await fs.writeJson(metaJsonPath, { note: 'Imported Backup', locked: false, createdAt: new Date() }, { spaces: 2 });
            await fs.remove(chunkDir);
            res.json({ success: true });
        } catch (e) {
            res.status(500).json({ error: e.message });
            try { await fs.remove(path.join(CHUNK_TEMP_DIR, uploadId)); } catch (_) { }
        }
    });

    // 12. 下载备份
    router.get('/panel/download', withInstance, (req, res) => {
        const { filename } = req.query;
        const BACKUP_PANEL_DIR = path.join(req.instDir, 'backups', 'panel');
        const zipPath = path.join(BACKUP_PANEL_DIR, filename);
        if (!fs.existsSync(zipPath)) return res.status(404).send('Not Found');
        res.download(zipPath);
    });

    registerRoutes('/', router);

    api.registerSidebarItem({
        id: 'backup-instance',
        labelKey: 'plugins.mc-panel-plugin-backup-instance.title',
        icon: 'fa-clock-rotate-left',
        color: '#f1c40f',
        view: 'backup-instance-view',
        location: 'instance'
    });

    api.registerComponent('backup-instance-view', 'component/BackupInstanceView.js');

    // Scheduler for Panel Backups
    const lastBackupTimes = new Map();

    const schedulerInterval = setInterval(() => {
        instanceConfig.instances.forEach(async (inst) => {
            if (!inst.autoBackupEnabled) return;
            if (inst.backupStrategy !== 'panel') return;

            const state = getOrCreateInstanceState(inst.id);
            if (!state.process) return;

            if (inst.autoBackupOnlyIfPlayersOnline && state.onlinePlayers.size === 0) return;

            const now = new Date();
            const lastTime = lastBackupTimes.get(inst.id) || 0;
            const mode = inst.autoBackupMode || 'interval';

            let shouldBackup = false;
            if (mode === 'interval') {
                const hours = inst.autoBackupIntervalHours !== undefined ? inst.autoBackupIntervalHours : (inst.autoBackupInterval || 12);
                const minutes = inst.autoBackupIntervalMinutes || 0;
                const intervalMs = (hours * 60 + minutes) * 60 * 1000;
                if (Date.now() - lastTime >= intervalMs) shouldBackup = true;
            } else if (mode === 'schedule') {
                const [targetH, targetM] = (inst.autoBackupScheduleTime || "03:00").split(':').map(Number);
                const scheduleDays = inst.autoBackupScheduleDays || 1;

                if (now.getHours() === targetH && now.getMinutes() === targetM) {
                    const daysSinceLast = (Date.now() - lastTime) / (1000 * 60 * 60 * 24);
                    if (daysSinceLast >= scheduleDays - 0.01) shouldBackup = true;
                }
            }

            if (shouldBackup) {
                lastBackupTimes.set(inst.id, Date.now());
                try {
                    await createPanelBackup(inst.id, true);
                } catch (e) {
                    console.error(`Auto backup failed for ${inst.id}:`, e);
                }
            }
        });
    }, 60000);

    return {
        destroy: async () => {
            clearInterval(schedulerInterval);
        }
    };
};
