module.exports = async function(api) {
    // Register the frontend components
    api.registerComponent('CPUCard', 'CPUCard.js');
    api.registerComponent('RAMCard', 'RAMCard.js');
    
    // Register the dashboard cards
    api.registerDashboardCard('CPUInfo', 'CPUCard');
    api.registerDashboardCard('RAMInfo', 'RAMCard');

    api.logger.info('System Status Cards plugin initialized');

    return {
        destroy() {
            api.logger.info('System Status Cards plugin destroyed');
        }
    };
};
