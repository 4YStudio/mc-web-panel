import { store } from '/js/store.js';

export default {
    template: `
    <div class="card border-0 shadow-sm overflow-hidden h-100 animate-in" style="background: var(--c-surface); border-radius: 20px;">
        <div class="card-body p-3 p-md-4 d-flex align-items-center">
            <div class="rounded-circle d-flex align-items-center justify-content-center me-3 flex-shrink-0" 
                 style="width: 54px; height: 54px; background: rgba(var(--c-primary-rgb), 0.1); color: var(--c-primary);">
                <i class="fa-solid fa-microchip fa-xl"></i>
            </div>
            <div class="flex-grow-1 min-width-0">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <h6 class="text-uppercase small fw-bold text-muted mb-0 tracking-wider">{{ $t('dashboard.cpu_usage') || 'CPU 负载' }}</h6>
                    <span class="fw-black text-primary" style="font-size: 1.1rem;">{{ store.stats.cpu }}%</span>
                </div>
                <div class="progress" style="height: 6px; background: rgba(var(--c-primary-rgb), 0.05); border-radius: 10px;">
                    <div class="progress-bar bg-primary rounded-pill transition-all" 
                         role="progressbar" :style="{width: store.stats.cpu + '%'}" 
                         :aria-valuenow="store.stats.cpu" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <div class="mt-2 small text-muted d-flex align-items-center opacity-75">
                    <i class="fa-solid fa-bolt me-1" style="font-size: 0.7rem;"></i>
                    <span>{{ store.stats.cpu > 50 ? '负载较高' : '运行平稳' }}</span>
                </div>
            </div>
        </div>
    </div>
    `,
    setup() {
        return { store };
    }
};
