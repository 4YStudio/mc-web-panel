import { ref, reactive, computed, onMounted, onUnmounted, watch, getCurrentInstance } from '/js/vue.esm-browser.js';
import { api } from '/js/api.js';
import { store } from '/js/store.js';
import { socket } from '/js/socket.js';
import { showToast, openModal } from '/js/utils.js';
import CustomSelect from '/js/components/CustomSelect.js';

const CONFIG_GROUPS = [
    {
        titleKey: 'plugins.mc-panel-plugin-backup-mod.config_groups.basic',
        items: [
            { key: 'config.advancedbackups.enabled', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.enabled', type: 'boolean' },
            { key: 'config.advancedbackups.type', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.type', type: 'select', options: ['differential', 'incremental', 'zip'] },
            { key: 'config.advancedbackups.save', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.save', type: 'boolean' },
            { key: 'config.advancedbackups.togglesave', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.togglesave', type: 'boolean' },
            { key: 'config.advancedbackups.flush', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.flush', type: 'boolean' },
            { key: 'config.advancedbackups.activity', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.activity', type: 'boolean' }
        ]
    },
    {
        titleKey: 'plugins.mc-panel-plugin-backup-mod.config_groups.schedule',
        items: [
            { key: 'config.advancedbackups.frequency.min', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.freq_min', type: 'number', step: 0.05 },
            { key: 'config.advancedbackups.frequency.max', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.freq_max', type: 'number', step: 0.5 },
            { key: 'config.advancedbackups.frequency.uptime', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.freq_uptime', type: 'boolean' },
            { key: 'config.advancedbackups.frequency.schedule', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.freq_schedule', type: 'text' },
            { key: 'config.advancedbackups.frequency.shutdown', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.freq_shutdown', type: 'boolean' },
            { key: 'config.advancedbackups.frequency.startup', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.freq_startup', type: 'boolean' },
            { key: 'config.advancedbackups.frequency.delay', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.freq_delay', type: 'number', step: 1 }
        ]
    },
    {
        titleKey: 'plugins.mc-panel-plugin-backup-mod.config_groups.chains',
        items: [
            { key: 'config.advancedbackups.chains.length', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.chains_length', type: 'number', step: 1 },
            { key: 'config.advancedbackups.chains.compress', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.chains_compress', type: 'boolean' },
            { key: 'config.advancedbackups.chains.smart', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.chains_smart', type: 'boolean' },
            { key: 'config.advancedbackups.chains.maxpercent', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.chains_maxpercent', type: 'number', step: 1 }
        ]
    },
    {
        titleKey: 'plugins.mc-panel-plugin-backup-mod.config_groups.purge',
        items: [
            { key: 'config.advancedbackups.purge.size', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.purge_size', type: 'number', step: 1 },
            { key: 'config.advancedbackups.purge.days', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.purge_days', type: 'number', step: 1 },
            { key: 'config.advancedbackups.purge.count', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.purge_count', type: 'number', step: 1 },
            { key: 'config.advancedbackups.purge.incrementals', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.purge_incrementals', type: 'boolean' },
            { key: 'config.advancedbackups.purge.incrementalchains', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.purge_incrementalchains', type: 'number', step: 1 }
        ]
    },
    {
        titleKey: 'plugins.mc-panel-plugin-backup-mod.config_groups.logging',
        items: [
            { key: 'config.advancedbackups.logging.clients', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.logging_clients', type: 'select', options: ['ops', 'all', 'none'] },
            { key: 'config.advancedbackups.logging.clientfrequency', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.logging_clientfrequency', type: 'number', step: 100 },
            { key: 'config.advancedbackups.logging.console', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.logging_console', type: 'boolean' },
            { key: 'config.advancedbackups.logging.consolefrequency', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.logging_consolefrequency', type: 'number', step: 500 }
        ]
    },
    {
        titleKey: 'plugins.mc-panel-plugin-backup-mod.config_groups.advanced',
        items: [
            { key: 'config.advancedbackups.path', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.path', type: 'text' },
            { key: 'config.advancedbackups.zips.compression', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.compression', type: 'range', min: 1, max: 9 },
            { key: 'config.advancedbackups.buffer', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.buffer', type: 'number', step: 1024 },
            { key: 'config.advancedbackups.blacklist', labelKey: 'plugins.mc-panel-plugin-backup-mod.config_labels.blacklist', type: 'text' }
        ]
    }
];

export default {
    components: { CustomSelect },
    template: `
    <div class="animate-in">
        <div v-if="!isModAvailable" class="d-flex flex-column align-items-center justify-content-center py-5 text-muted">
            <i class="fa-solid fa-triangle-exclamation fa-4x mb-3 opacity-25"></i>
            <h4>未检测到 Advanced Backups 模组</h4>
            <p class="mt-2 text-center">此功能需要服务器安装 <b>Advanced Backups</b> 模组才能使用。<br>您可以前往模组下载界面搜索并安装它。</p>
            <div class="mt-4 d-flex gap-2">
                <button class="btn btn-primary px-4 rounded-pill fw-bold shadow-sm" @click="store.view = 'modrinth'">
                    <i class="fa-solid fa-cloud-arrow-down me-2"></i>前往下载
                </button>
                <button class="btn btn-outline-secondary px-3 rounded-pill fw-bold" @click="checkStatus">
                    <i class="fa-solid fa-rotate me-1"></i>重新检测
                </button>
            </div>
        </div>

        <template v-else>
            <div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <div class="d-flex align-items-center">
                    <h3 class="m-0 fw-bold text-nowrap">{{ $t('plugins.mc-panel-plugin-backup-mod.title') }}</h3>
                    <span v-if="backupList.length" class="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill ms-2 ms-md-3 px-2 py-1 small">
                        {{ backupList.length }} 个备份
                    </span>
                </div>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <template v-if="currentTab === 'list'">
                        <button class="btn btn-sm btn-outline-secondary rounded-pill px-2 px-md-3 fw-bold" @click="loadBackups" :title="$t('common.refresh')">
                            <i class="fa-solid fa-rotate" :class="{'fa-spin': loading}"></i>
                            <span class="d-none d-md-inline ms-1">{{ $t('common.refresh') }}</span>
                        </button>
                        <button class="btn btn-sm btn-outline-warning rounded-pill px-2 px-md-3 fw-bold" @click="askResetChain" :disabled="!store.isRunning" :title="$t('plugins.mc-panel-plugin-backup-mod.reset_chain')">
                            <i class="fa-solid fa-link-slash"></i>
                            <span class="d-none d-md-inline ms-1">{{ $t('plugins.mc-panel-plugin-backup-mod.reset_chain') }}</span>
                        </button>
                        <button class="btn btn-sm btn-outline-primary rounded-pill px-2 px-md-3 fw-bold" @click="createBackup('snapshot')" :disabled="!store.isRunning" :title="$t('plugins.mc-panel-plugin-backup-mod.create_snap')">
                            <i class="fa-solid fa-camera"></i>
                            <span class="d-none d-md-inline ms-1">{{ $t('plugins.mc-panel-plugin-backup-mod.create_snap') }}</span>
                        </button>
                        <button class="btn btn-primary btn-sm rounded-pill px-2 px-md-3 shadow-sm fw-bold" @click="createBackup('start')" :disabled="!store.isRunning" :title="$t('plugins.mc-panel-plugin-backup-mod.create_backup')">
                            <i class="fa-solid fa-plus-circle"></i>
                            <span class="d-none d-md-inline ms-1">{{ $t('plugins.mc-panel-plugin-backup-mod.create_backup') }}</span>
                        </button>
                    </template>
                    <template v-else-if="currentTab === 'config'">
                        <button class="btn btn-sm btn-outline-secondary rounded-pill px-2 px-md-3 fw-bold" @click="toggleEditMode">
                            <i class="fa-solid" :class="editMode==='gui'?'fa-code':'fa-sliders'"></i>
                            <span class="d-none d-md-inline ms-1">{{ editMode==='gui' ? $t('common.text_mode') : $t('common.gui_mode') }}</span>
                        </button>
                        <button class="btn btn-success btn-sm rounded-pill px-2 px-md-3 shadow-sm fw-bold" @click="saveConfig" :title="$t('common.save')">
                            <i class="fa-solid fa-save"></i>
                            <span class="d-none d-md-inline ms-1">{{ $t('common.save') }}</span>
                        </button>
                    </template>
                </div>
            </div>

            <ul class="nav nav-tabs mb-3 border-0 bg-body-tertiary p-1 rounded-pill d-inline-flex" style="font-size: 0.85rem;">
                <li class="nav-item">
                    <a class="nav-link border-0 rounded-pill px-3 py-1 cursor-pointer" :class="{active: currentTab==='list', 'bg-primary text-white shadow-sm': currentTab==='list'}" @click="currentTab='list'">{{ $t('plugins.mc-panel-plugin-backup-mod.list_title') }}</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link border-0 rounded-pill px-3 py-1 cursor-pointer" :class="{active: currentTab==='config', 'bg-primary text-white shadow-sm': currentTab==='config'}" @click="currentTab='config'">{{ $t('plugins.mc-panel-plugin-backup-mod.config') }}</a>
                </li>
            </ul>

            <Transition name="fade" mode="out-in">
                <div v-if="currentTab === 'list'" key="list">
                    <div class="alert alert-info py-2 px-3 small mb-3 border-0 shadow-sm d-flex align-items-center">
                        <i class="fa-solid fa-circle-info me-2 fs-6 text-primary"></i>
                        <span>{{ $t('plugins.mc-panel-plugin-backup-mod.tips') }}</span>
                    </div>

                    <div class="card overflow-hidden border-0 shadow-sm">
                        <!-- Desktop Table View -->
                        <div class="table-responsive d-none d-md-block">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-body-tertiary">
                                    <tr class="small text-uppercase text-muted fw-bold">
                                        <th class="px-3">{{ $t('common.name') }}</th>
                                        <th>{{ $t('plugins.mc-panel-plugin-backup-mod.world') }}</th>
                                        <th>{{ $t('plugins.mc-panel-plugin-backup-mod.mode') }}</th>
                                        <th class="d-none d-md-table-cell">{{ $t('common.time') }}</th>
                                        <th class="d-none d-sm-table-cell">{{ $t('common.size') }}</th>
                                        <th class="text-end px-3">{{ $t('common.actions') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="b in backupList" :key="b.path" class="animate-in">
                                        <td class="px-3 fw-bold small">
                                            <div class="d-flex align-items-center">
                                                <i class="fa-solid fa-file-zipper me-2 opacity-50"></i>
                                                <span class="text-truncate" style="max-width: 260px;" :title="b.name">{{ b.name }}</span>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle rounded-pill px-2 py-1 small">
                                                {{ b.world || 'world' }}
                                            </span>
                                        </td>
                                        <td>
                                            <span v-if="b.folder === 'snapshots' || b.type === 'snapshot'" class="badge bg-warning-subtle text-warning border border-warning-subtle rounded-pill px-2 py-1 small">
                                                <i class="fa-solid fa-camera me-1"></i>{{ $t('plugins.mc-panel-plugin-backup-mod.type_snapshot') }}
                                            </span>
                                            <span v-else-if="b.folder === 'zips'" class="badge bg-secondary-subtle text-body border border-secondary-subtle rounded-pill px-2 py-1 small">
                                                <i class="fa-solid fa-file-zipper me-1"></i>{{ $t('plugins.mc-panel-plugin-backup-mod.mode_zip') }}
                                            </span>
                                            <span v-else-if="b.folder === 'differential'" :class="b.type === 'full' ? 'bg-success-subtle text-success border-success-subtle' : 'bg-info-subtle text-info border-info-subtle'" class="badge border rounded-pill px-2 py-1 small">
                                                <i class="fa-solid me-1" :class="b.type === 'full' ? 'fa-layer-group' : 'fa-code-branch'"></i>
                                                {{ b.type === 'full' ? '差量 (全量基准)' : '差量 (增量部分)' }}
                                            </span>
                                            <span v-else-if="b.folder === 'incremental'" :class="b.type === 'full' ? 'bg-success-subtle text-success border-success-subtle' : 'bg-primary-subtle text-primary border-primary-subtle'" class="badge border rounded-pill px-2 py-1 small">
                                                <i class="fa-solid me-1" :class="b.type === 'full' ? 'fa-layer-group' : 'fa-plus-minus'"></i>
                                                {{ b.type === 'full' ? '增量 (全量基准)' : '增量 (按序部分)' }}
                                            </span>
                                            <span v-else class="badge bg-secondary-subtle text-muted border border-secondary-subtle rounded-pill px-2 py-1 small">
                                                {{ b.folder }}
                                            </span>
                                        </td>
                                        <td class="small text-muted d-none d-md-table-cell">{{ new Date(b.mtime).toLocaleString() }}</td>
                                        <td class="small d-none d-sm-table-cell">{{ (b.size/1024/1024).toFixed(1) }} MB</td>
                                        <td class="text-end px-3">
                                            <div class="d-flex justify-content-end gap-1">
                                                <button class="btn btn-xs btn-outline-success border-0" @click="downloadBackup(b)" :title="$t('common.download')">
                                                    <i class="fa-solid fa-download"></i>
                                                </button>
                                                <button class="btn btn-xs btn-outline-primary border-0" @click="askRestore(b)" :title="$t('plugins.mc-panel-plugin-backup-mod.restore')">
                                                    <i class="fa-solid fa-clock-rotate-left"></i>
                                                </button>
                                                <button class="btn btn-xs btn-outline-danger border-0" @click="askDelete(b)" :title="$t('common.delete')">
                                                    <i class="fa-solid fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr v-if="!backupList.length && !loading">
                                        <td colspan="6" class="text-center text-muted py-5">
                                            <i class="fa-solid fa-box-open fa-2x mb-2 opacity-25 d-block"></i>
                                            暂无备份文件
                                        </td>
                                    </tr>
                                    <tr v-if="loading && !backupList.length">
                                        <td colspan="6" class="text-center text-muted py-5">
                                            <div class="spinner-border spinner-border-sm text-primary mb-2"></div>
                                            <div class="small">加载中...</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Mobile Card View -->
                        <div class="d-md-none p-2.5 p-sm-3">
                            <div v-if="loading && !backupList.length" class="text-center text-muted py-4">
                                <div class="spinner-border spinner-border-sm text-primary mb-2"></div>
                                <div class="small">加载中...</div>
                            </div>
                            <div v-else-if="!backupList.length" class="text-center text-muted py-4">
                                <i class="fa-solid fa-box-open fa-2x mb-2 opacity-25 d-block"></i>
                                暂无备份文件
                            </div>
                            <div v-else class="d-flex flex-column gap-2.5">
                                <div v-for="b in backupList" :key="b.path" class="card border rounded-3 p-3 bg-body shadow-sm" style="background: var(--c-surface-elevated, var(--c-surface)) !important; border-color: var(--c-border) !important;">
                                    <div class="d-flex align-items-center justify-content-between gap-2 mb-2.5">
                                        <div class="min-w-0 flex-grow-1">
                                            <div class="fw-bold small text-body text-truncate d-flex align-items-center">
                                                <i class="fa-solid fa-file-zipper me-2 text-warning flex-shrink-0 fs-6"></i>
                                                <span class="text-truncate" :title="b.name" style="font-size: 0.9rem;">{{ b.name }}</span>
                                            </div>
                                        </div>
                                        <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle rounded-pill px-2.5 py-1 flex-shrink-0" style="font-size: 0.68rem;">
                                            <i class="fa-solid fa-earth-americas me-1 opacity-75"></i>{{ b.world || 'world' }}
                                        </span>
                                    </div>
                                    <!-- 时间与大小行 -->
                                    <div class="d-flex align-items-center justify-content-between text-muted small mb-2.5 font-monospace" style="font-size: 0.75rem;">
                                        <span class="d-flex align-items-center text-truncate me-2"><i class="fa-regular fa-clock me-1.5 opacity-75 flex-shrink-0"></i>{{ new Date(b.mtime).toLocaleString() }}</span>
                                        <span class="fw-semibold text-body flex-shrink-0"><i class="fa-solid fa-hard-drive me-1 opacity-50"></i>{{ (b.size/1024/1024).toFixed(1) }} MB</span>
                                    </div>

                                    <!-- 类型徽标与操作按钮行 -->
                                    <div class="d-flex align-items-center justify-content-between pt-2.5 border-top gap-2 flex-wrap" style="border-color: var(--c-border) !important;">
                                        <div class="d-flex align-items-center gap-1.5 flex-shrink-0">
                                            <span v-if="b.folder === 'snapshots' || b.type === 'snapshot'" class="badge bg-warning-subtle text-warning border border-warning-subtle rounded-pill px-2.5 py-1" style="font-size: 0.65rem;">
                                                <i class="fa-solid fa-camera me-1"></i>{{ $t('plugins.mc-panel-plugin-backup-mod.type_snapshot') }}
                                            </span>
                                            <span v-else-if="b.folder === 'zips'" class="badge bg-secondary-subtle text-body border border-secondary-subtle rounded-pill px-2.5 py-1" style="font-size: 0.65rem;">
                                                <i class="fa-solid fa-file-zipper me-1"></i>{{ $t('plugins.mc-panel-plugin-backup-mod.mode_zip') }}
                                            </span>
                                            <span v-else-if="b.folder === 'differential'" :class="b.type === 'full' ? 'bg-success-subtle text-success border-success-subtle' : 'bg-info-subtle text-info border-info-subtle'" class="badge border rounded-pill px-2.5 py-1" style="font-size: 0.65rem;">
                                                <i class="fa-solid me-1" :class="b.type === 'full' ? 'fa-layer-group' : 'fa-code-branch'"></i>
                                                {{ b.type === 'full' ? '差量 (全量)' : '差量 (增量)' }}
                                            </span>
                                            <span v-else-if="b.folder === 'incremental'" :class="b.type === 'full' ? 'bg-success-subtle text-success border-success-subtle' : 'bg-primary-subtle text-primary border-primary-subtle'" class="badge border rounded-pill px-2.5 py-1" style="font-size: 0.65rem;">
                                                <i class="fa-solid me-1" :class="b.type === 'full' ? 'fa-layer-group' : 'fa-plus-minus'"></i>
                                                {{ b.type === 'full' ? '增量 (基准)' : '增量 (按序)' }}
                                            </span>
                                            <span v-else class="badge bg-secondary-subtle text-muted border border-secondary-subtle rounded-pill px-2.5 py-1" style="font-size: 0.65rem;">
                                                {{ b.folder }}
                                            </span>
                                        </div>
                                        <div class="d-flex align-items-center gap-1.5 ms-auto flex-shrink-0">
                                            <button class="btn btn-sm btn-outline-success rounded-pill px-2.5 py-1" @click="downloadBackup(b)" :title="$t('common.download')">
                                                <i class="fa-solid fa-download"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-primary rounded-pill px-2.5 py-1" @click="askRestore(b)" :title="$t('plugins.mc-panel-plugin-backup-mod.restore')">
                                                <i class="fa-solid fa-clock-rotate-left"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-danger rounded-pill px-2.5 py-1" @click="askDelete(b)" :title="$t('common.delete')">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div v-else-if="currentTab === 'config'" key="config">
                    <Transition name="fade" mode="out-in">
                        <div v-if="editMode === 'gui'" class="row g-3 g-md-4 overflow-auto custom-scrollbar pb-5" key="gui">
                            <div class="col-md-6" v-for="(group, idx) in CONFIG_GROUPS" :key="idx">
                                <div class="card h-100 border-0 shadow-sm">
                                    <div class="card-header bg-body-tertiary fw-bold border-0 py-2 px-3 small text-uppercase text-muted">
                                        {{ $t(group.titleKey) }}
                                    </div>
                                    <div class="card-body p-3">
                                        <div v-for="item in group.items" :key="item.key" class="mb-3">
                                            <div v-if="item.type === 'boolean'" class="form-check form-switch d-flex justify-content-between p-0 align-items-center">
                                                <label class="form-check-label small fw-bold text-muted">{{ $t(item.labelKey) }}</label>
                                                <input class="form-check-input ms-0" type="checkbox" v-model="formModel[item.key]">
                                            </div>
                                            <div v-else-if="item.type === 'select'">
                                                <label class="form-label small fw-bold text-muted mb-1">{{ $t(item.labelKey) }}</label>
                                                <CustomSelect v-model="formModel[item.key]" :options="item.options" size="sm" />
                                            </div>
                                            <div v-else-if="item.type === 'range'">
                                                <label class="form-label small fw-bold text-muted mb-1 d-flex justify-content-between">
                                                    <span>{{ $t(item.labelKey) }}</span>
                                                    <span class="badge bg-primary-subtle text-primary rounded-pill">{{ formModel[item.key] }}</span>
                                                </label>
                                                <input type="range" class="form-range" :min="item.min" :max="item.max" v-model="formModel[item.key]">
                                            </div>
                                            <div v-else>
                                                <label class="form-label small fw-bold text-muted mb-1">{{ $t(item.labelKey) }}</label>
                                                <input :type="item.type" class="form-control form-control-sm border-0 bg-body-tertiary px-2" v-model="formModel[item.key]" :step="item.step">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div v-else class="h-100" key="text">
                            <textarea class="form-control bg-body text-body border-secondary font-monospace" style="height: 65vh; resize: vertical;" v-model="rawContent"></textarea>
                        </div>
                    </Transition>
                </div>
            </Transition>
        </template>
    </div>
    `,
    setup() {
        const currentTab = ref('list');
        const editMode = ref('gui');
        const backupList = ref([]);
        const rawContent = ref('');
        const formModel = reactive({});
        const loading = ref(false);
        const modStatus = reactive({ hasMod: false, backupCount: 0 });
        const { proxy } = getCurrentInstance();
        const $t = proxy.$t;

        const isModAvailable = computed(() => {
            return !!(store.hasBackupMod || store.stats?.hasBackupMod || modStatus.hasMod || backupList.value.length > 0);
        });

        const parseProperties = (text) => {
            const lines = (text || '').split('\n');
            lines.forEach(line => {
                const cleanLine = line.trim();
                if (cleanLine && !cleanLine.startsWith('#') && cleanLine.includes('=')) {
                    const [key, ...valParts] = cleanLine.split('=');
                    const val = valParts.join('=').trim();
                    if (key) {
                        const cleanKey = key.trim();
                        if (val === 'true') formModel[cleanKey] = true;
                        else if (val === 'false') formModel[cleanKey] = false;
                        else if (!isNaN(val) && val !== '') formModel[cleanKey] = Number(val);
                        else formModel[cleanKey] = val;
                    }
                }
            });
        };

        const stringifyProperties = (originalText, model) => {
            let lines = (originalText || '').split('\n');
            const handled = new Set();
            const updated = lines.map(line => {
                const cleanLine = line.trim();
                if (cleanLine && !cleanLine.startsWith('#') && cleanLine.includes('=')) {
                    const key = cleanLine.split('=')[0].trim();
                    if (model[key] !== undefined) {
                        handled.add(key);
                        return `${key}=${model[key]}`;
                    }
                }
                return line;
            });

            for (const [key, val] of Object.entries(model)) {
                if (!handled.has(key) && val !== undefined) {
                    updated.push(`${key}=${val}`);
                }
            }
            return updated.join('\n');
        };

        const checkStatus = async () => {
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-backup-mod/status');
                if (res.data) {
                    modStatus.hasMod = !!res.data.hasMod;
                    modStatus.backupCount = res.data.backupCount || 0;
                }
            } catch (_) {}
        };

        const loadBackups = async () => {
            try {
                loading.value = true;
                const res = await api.get('/api/plugins/mc-panel-plugin-backup-mod/list');
                backupList.value = res.data || [];
                if (backupList.value.length > 0) modStatus.hasMod = true;
            } catch (e) {
                console.error('Failed to load backup list:', e);
            } finally {
                loading.value = false;
            }
        };

        const loadConfig = async () => {
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-backup-mod/config');
                rawContent.value = res.data.content || '';
                if (res.data.config) {
                    Object.assign(formModel, res.data.config);
                } else {
                    parseProperties(rawContent.value);
                }
            } catch (e) {
                rawContent.value = '# Error loading configuration';
            }
        };

        const saveConfig = async () => {
            let content = rawContent.value;
            if (editMode.value === 'gui') {
                content = stringifyProperties(rawContent.value, formModel);
                rawContent.value = content;
            }
            try {
                const res = await api.post('/api/plugins/mc-panel-plugin-backup-mod/save-config', { content, properties: formModel });
                if (res.data.reloaded) {
                    showToast('保存成功，配置已热重载', 'success');
                } else {
                    showToast($t('common.success'));
                }
            } catch (e) {
                showToast(e.response?.data?.error || $t('common.error'), 'danger');
            }
        };

        const createBackup = async (type = 'start') => {
            try {
                const res = await api.post('/api/plugins/mc-panel-plugin-backup-mod/create', { type });
                if (res.data.success) {
                    showToast(res.data.message || $t('common.success'));
                    setTimeout(loadBackups, 3500);
                } else {
                    showToast(res.data.message || $t('common.error'), 'warning');
                }
            } catch (e) {
                showToast(e.response?.data?.error || e.message, 'danger');
            }
        };

        const askResetChain = () => {
            openModal({
                title: $t('plugins.mc-panel-plugin-backup-mod.confirm_reset_chain_title'),
                message: $t('plugins.mc-panel-plugin-backup-mod.confirm_reset_chain_msg'),
                callback: async () => {
                    try {
                        const res = await api.post('/api/plugins/mc-panel-plugin-backup-mod/reset-chain');
                        showToast(res.data.message || $t('common.success'));
                    } catch (e) {
                        showToast(e.response?.data?.error || e.message, 'danger');
                    }
                }
            });
        };

        const askRestore = (b) => {
            openModal({
                title: $t('plugins.mc-panel-plugin-backup-mod.confirm_restore_title'),
                message: $t('plugins.mc-panel-plugin-backup-mod.confirm_restore_msg', { name: b.name }),
                callback: async () => {
                    store.task.visible = true;
                    store.task.title = $t('plugins.mc-panel-plugin-backup-mod.progress_restoring');
                    store.task.percent = 0;
                    store.task.message = $t('common.loading');
                    store.task.subMessage = '...';
                    try {
                        await api.post('/api/plugins/mc-panel-plugin-backup-mod/restore', {
                            filename: b.name,
                            folder: b.folder,
                            world: b.world,
                            type: b.type,
                            mode: b.mode
                        });
                    } catch (e) {
                        store.task.visible = false;
                        showToast(e.response?.data?.error || e.message, 'danger');
                    }
                }
            });
        };

        const askDelete = (b) => {
            openModal({
                title: $t('plugins.mc-panel-plugin-backup-mod.confirm_delete_title'),
                message: $t('plugins.mc-panel-plugin-backup-mod.confirm_delete_msg', { name: b.name }),
                callback: async () => {
                    try {
                        await api.post('/api/plugins/mc-panel-plugin-backup-mod/delete', {
                            filename: b.name,
                            folder: b.folder,
                            world: b.world
                        });
                        showToast($t('common.success'));
                        loadBackups();
                    } catch (e) {
                        showToast(e.response?.data?.error || e.message, 'danger');
                    }
                }
            });
        };

        const downloadBackup = (b) => {
            const url = `/api/plugins/mc-panel-plugin-backup-mod/download?filename=${encodeURIComponent(b.name)}&folder=${encodeURIComponent(b.folder)}&world=${encodeURIComponent(b.world || '')}&instanceId=${store.currentInstanceId}`;
            window.open(url, '_blank');
        };

        const toggleEditMode = () => {
            if (editMode.value === 'text') parseProperties(rawContent.value);
            editMode.value = editMode.value === 'gui' ? 'text' : 'gui';
        };

        const onRestoreProgress = (data) => {
            if (store.task.visible) {
                store.task.percent = data.percent || 0;
                store.task.message = data.message || '';
            }
        };

        const onRestoreCompleted = () => {
            if (store.task.visible) {
                store.task.percent = 100;
                store.task.message = '回档完成';
                setTimeout(() => {
                    store.task.visible = false;
                    showToast($t('common.success'));
                    loadBackups();
                }, 1200);
            }
        };

        const onRestoreError = (err) => {
            if (store.task.visible) {
                store.task.visible = false;
                showToast('回档失败: ' + err, 'danger');
            }
        };

        watch(currentTab, (val) => {
            if (val === 'list') loadBackups();
            if (val === 'config') loadConfig();
        });

        watch(() => store.currentInstanceId, () => {
            checkStatus();
            loadBackups();
            if (currentTab.value === 'config') loadConfig();
        });

        onMounted(() => {
            checkStatus();
            loadBackups();

            if (socket) {
                socket.on(`restore_progress:${store.currentInstanceId}`, onRestoreProgress);
                socket.on(`restore_completed:${store.currentInstanceId}`, onRestoreCompleted);
                socket.on(`restore_error:${store.currentInstanceId}`, onRestoreError);
            }
        });

        onUnmounted(() => {
            if (socket) {
                socket.off(`restore_progress:${store.currentInstanceId}`, onRestoreProgress);
                socket.off(`restore_completed:${store.currentInstanceId}`, onRestoreCompleted);
                socket.off(`restore_error:${store.currentInstanceId}`, onRestoreError);
            }
        });

        return {
            store, currentTab, editMode, backupList, rawContent, formModel, CONFIG_GROUPS,
            loading, isModAvailable,
            loadBackups, createBackup, askResetChain, askRestore, askDelete, downloadBackup,
            saveConfig, toggleEditMode, checkStatus
        };
    }
};

