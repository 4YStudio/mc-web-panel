const fs = require('fs-extra');
const path = require('path');
const AdmZip = require('adm-zip');
const express = require('express');

const DEFAULT_CONFIG_CONTENT = `#Enable or disable automatic backups.
config.advancedbackups.enabled=true

#Whether to save before making a backup.
config.advancedbackups.save=true

#Whether to disable autosave before making a backup, and whether to re-enable saving afterwards.
config.advancedbackups.togglesave=true

#Buffer size, in bytes, to use when reading / writing files.
config.advancedbackups.buffer=1048576

#Whether to flush when making the aforementioned save.
config.advancedbackups.flush=false

#Whether to require player activity between backups.
config.advancedbackups.activity=true

#The type of backups to use (zip, differential, incremental).
config.advancedbackups.type=differential

#A list of files, relative paths within the world directory, to skip backing up.
config.advancedbackups.blacklist=session.lock,*_old

#The absolute or relative path to the backup location.
config.advancedbackups.path=./backups

#Minimum time between backups, in hours.
config.advancedbackups.frequency.min=0.25

#Triggers a backup if none has already happened within this time.
config.advancedbackups.frequency.max=24.0

#Whether the schedule below uses uptime (true) or real-world time (false).
config.advancedbackups.frequency.uptime=true

#Backup schedule, based off uptime or real-world time.
config.advancedbackups.frequency.schedule=1:00

#Whether to force a backup on server shutdown.
config.advancedbackups.frequency.shutdown=false

#Whether to force a backup on server startup.
config.advancedbackups.frequency.startup=false

#Delay to use after startup, in seconds.
config.advancedbackups.frequency.delay=30

#Which clients to send progress updates to (ops, all, none).
config.advancedbackups.logging.clients=ops

#How often to send progress info to clients, in milliseconds.
config.advancedbackups.logging.clientfrequency=500

#Whether to log backup progress to console.
config.advancedbackups.logging.console=true

#How often to send log progress info in console, in milliseconds.
config.advancedbackups.logging.consolefrequency=5000

#The maximum size to keep, in GB (0 to disable).
config.advancedbackups.purge.size=50.0

#The maximum days to keep backups for (0 to disable).
config.advancedbackups.purge.days=0

#The maximum amount of backups to keep (0 to disable).
config.advancedbackups.purge.count=0

#Whether to delete incremental backup chains if max size is exceeded.
config.advancedbackups.purge.incrementals=true

#The minimum number of incremental chains to keep before purging.
config.advancedbackups.purge.incrementalchains=1

#The compression level to use for zip files (1-9).
config.advancedbackups.zips.compression=4

#The maximum 'chain' length to keep.
config.advancedbackups.chains.length=50

#Whether to compress 'chains'.
config.advancedbackups.chains.compress=true

#Whether to enable 'smart' reset for chains.
config.advancedbackups.chains.smart=true

#What % of a full backup is allowed to be contained in a partial before forcing a full backup.
config.advancedbackups.chains.maxpercent=50.0
`;

module.exports = async function (api) {
    const router = express.Router();

    // 辅助函数：查找配置文件路径
    const findConfigFile = (instDir) => {
        const candidates = [
            path.join(instDir, 'config', 'AdvancedBackups.properties'),
            path.join(instDir, 'config', 'advancedbackups.properties'),
            path.join(instDir, 'AdvancedBackups.properties'),
            path.join(instDir, 'advancedbackups.properties')
        ];
        for (const c of candidates) {
            if (fs.existsSync(c)) return c;
        }
        return path.join(instDir, 'config', 'AdvancedBackups.properties');
    };

    // 辅助函数：解析 properties 文本
    const parseProperties = (text) => {
        const result = {};
        if (!text) return result;
        const lines = text.split('\n');
        for (const line of lines) {
            const clean = line.trim();
            if (clean && !clean.startsWith('#') && clean.includes('=')) {
                const [k, ...vParts] = clean.split('=');
                const key = k.trim();
                const val = vParts.join('=').trim();
                if (val === 'true') result[key] = true;
                else if (val === 'false') result[key] = false;
                else if (!isNaN(val) && val !== '') result[key] = Number(val);
                else result[key] = val;
            }
        }
        return result;
    };

    // 辅助函数：写回 properties 文本
    const updatePropertiesContent = (originalText, updates) => {
        const lines = (originalText || '').split('\n');
        const handledKeys = new Set();
        const updatedLines = lines.map(line => {
            const clean = line.trim();
            if (clean && !clean.startsWith('#') && clean.includes('=')) {
                const key = clean.split('=')[0].trim();
                if (updates[key] !== undefined) {
                    handledKeys.add(key);
                    return `${key}=${updates[key]}`;
                }
            }
            return line;
        });

        // 将新增的未出现在原文件中的配置追加在末尾
        for (const [key, value] of Object.entries(updates)) {
            if (!handledKeys.has(key)) {
                updatedLines.push(`${key}=${value}`);
            }
        }
        return updatedLines.join('\n');
    };

    // 辅助函数：获取模组配置的备份根目录
    const getBackupRoot = (instDir) => {
        const cfgFile = findConfigFile(instDir);
        let customPath = './backups';
        if (fs.existsSync(cfgFile)) {
            try {
                const content = fs.readFileSync(cfgFile, 'utf8');
                const parsed = parseProperties(content);
                if (parsed['config.advancedbackups.path']) {
                    customPath = String(parsed['config.advancedbackups.path']).trim();
                }
            } catch (_) {}
        }
        if (path.isAbsolute(customPath)) {
            return path.resolve(customPath);
        }
        return path.resolve(instDir, customPath);
    };

    // 辅助函数：获取当前主世界名
    const getWorldName = (instDir) => {
        const propsFile = path.join(instDir, 'server.properties');
        if (fs.existsSync(propsFile)) {
            try {
                const content = fs.readFileSync(propsFile, 'utf8');
                const match = content.match(/^level-name=(.+)$/m);
                if (match && match[1]) {
                    return match[1].trim();
                }
            } catch (_) {}
        }
        return 'world';
    };

    // 辅助函数：扫描所有备份文件
    const scanAllBackups = async (instDir) => {
        const backupRoot = getBackupRoot(instDir);
        const defaultWorld = getWorldName(instDir);
        const results = [];

        if (!fs.existsSync(backupRoot)) return results;

        const subDirsToCheck = ['differential', 'incremental', 'zips', 'snapshots'];

        // 内部扫描具体类型子目录
        const scanSubDir = async (dirPath, worldName, folderType) => {
            if (!fs.existsSync(dirPath)) return;
            try {
                const entries = await fs.readdir(dirPath);
                for (const file of entries) {
                    if (file.endsWith('.zip')) {
                        const filePath = path.join(dirPath, file);
                        const stat = await fs.stat(filePath);
                        let type = 'full';
                        let mode = folderType;
                        if (folderType === 'zips') mode = 'zip';

                        if (folderType === 'differential' || folderType === 'incremental') {
                            if (file.includes('partial')) type = 'partial';
                            else if (file.includes('full')) type = 'full';
                        } else if (folderType === 'snapshots') {
                            type = 'snapshot';
                        }

                        results.push({
                            name: file,
                            path: filePath,
                            folder: folderType,
                            world: worldName,
                            mode,
                            type,
                            size: stat.size,
                            mtime: stat.mtime
                        });
                    }
                }
            } catch (_) {}
        };

        // 1. 扫描 backupRoot 下的所有世界子目录（如 backups/world/...）
        try {
            const rootEntries = await fs.readdir(backupRoot, { withFileTypes: true });
            for (const entry of rootEntries) {
                if (entry.isDirectory()) {
                    const worldCandidateDir = path.join(backupRoot, entry.name);
                    // 检查此子目录下是否包含备份分类目录
                    let isWorldDir = false;
                    for (const sub of subDirsToCheck) {
                        const subPath = path.join(worldCandidateDir, sub);
                        if (fs.existsSync(subPath)) {
                            isWorldDir = true;
                            await scanSubDir(subPath, entry.name, sub);
                        }
                    }
                    // 如果该目录不是分类目录，也不是世界目录，但包含直接的 zip（极少数情况）
                    if (!isWorldDir && subDirsToCheck.includes(entry.name)) {
                        await scanSubDir(worldCandidateDir, defaultWorld, entry.name);
                    }
                }
            }

            // 2. 扫描 backupRoot 直接作为分类根目录的情况（如 backups/differential/*.zip）
            for (const sub of subDirsToCheck) {
                const directSubPath = path.join(backupRoot, sub);
                // 仅当之前未扫描过该绝对路径时扫描
                if (fs.existsSync(directSubPath)) {
                    await scanSubDir(directSubPath, defaultWorld, sub);
                }
            }
        } catch (e) {
            console.error('[BackupMod] Scan failed:', e);
        }

        // 去重并按时间降序排序
        const uniqueMap = new Map();
        for (const item of results) {
            if (!uniqueMap.has(item.path)) {
                uniqueMap.set(item.path, item);
            }
        }
        return Array.from(uniqueMap.values()).sort((a, b) => new Date(b.mtime) - new Date(a.mtime));
    };

    // 路由：获取备份列表
    router.get('/list', api.instances.withInstance, async (req, res) => {
        try {
            const list = await scanAllBackups(req.instDir);
            res.json(list);
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    // 路由：获取模组状态及概要
    router.get('/status', api.instances.withInstance, async (req, res) => {
        try {
            const cfgFile = findConfigFile(req.instDir);
            const backupRoot = getBackupRoot(req.instDir);
            const list = await scanAllBackups(req.instDir);
            const modsDir = path.join(req.instDir, 'mods');
            let hasJar = false;
            if (fs.existsSync(modsDir)) {
                const files = (await fs.readdir(modsDir)).map(f => f.toLowerCase());
                hasJar = files.some(f => f.includes('advancedbackups') || f.includes('advanced-backups'));
            }
            res.json({
                hasMod: hasJar || fs.existsSync(cfgFile) || list.length > 0,
                backupCount: list.length,
                backupRoot,
                configExists: fs.existsSync(cfgFile)
            });
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    // 路由：读取模组配置文件
    router.get('/config', api.instances.withInstance, async (req, res) => {
        try {
            const cfgFile = findConfigFile(req.instDir);
            if (!fs.existsSync(cfgFile)) {
                await fs.ensureDir(path.dirname(cfgFile));
                await fs.writeFile(cfgFile, DEFAULT_CONFIG_CONTENT, 'utf8');
            }
            const content = await fs.readFile(cfgFile, 'utf8');
            const parsed = parseProperties(content);
            res.json({ success: true, content, config: parsed, filepath: path.relative(req.instDir, cfgFile) });
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    // 路由：保存模组配置文件
    router.post('/save-config', api.instances.withInstance, async (req, res) => {
        try {
            const cfgFile = findConfigFile(req.instDir);
            await fs.ensureDir(path.dirname(cfgFile));

            let finalContent = '';
            if (req.body.content !== undefined) {
                finalContent = req.body.content;
            } else if (req.body.properties && typeof req.body.properties === 'object') {
                const existing = fs.existsSync(cfgFile) ? await fs.readFile(cfgFile, 'utf8') : DEFAULT_CONFIG_CONTENT;
                finalContent = updatePropertiesContent(existing, req.body.properties);
            } else {
                return res.status(400).json({ error: '缺少 content 或 properties 参数' });
            }

            await fs.writeFile(cfgFile, finalContent, 'utf8');

            // 若服务器正在运行，自动下发 reload-config 指令
            let reloaded = false;
            if (req.instState && req.instState.process) {
                reloaded = api.sendCommand(req.instanceId, 'backup reload-config');
            }

            res.json({ success: true, reloaded });
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    // 路由：创建备份
    router.post('/create', api.instances.withInstance, (req, res) => {
        const { instState, instanceId } = req;
        const isSnapshot = req.body && (req.body.type === 'snapshot' || req.body.snapshot);
        if (!instState || !instState.process) {
            return res.json({ success: false, message: '服务器未运行，无法通过模组执行在线备份' });
        }
        const cmd = isSnapshot ? 'backup snapshot' : 'backup start';
        const ok = api.sendCommand(instanceId, cmd);
        res.json({
            success: ok,
            message: ok ? `已向服务器发送备份指令 (${cmd})` : '发送备份指令失败'
        });
    });

    // 路由：重置备份链
    router.post('/reset-chain', api.instances.withInstance, (req, res) => {
        const { instState, instanceId } = req;
        if (!instState || !instState.process) {
            return res.json({ success: false, message: '服务器未运行，无法发送指令' });
        }
        const ok = api.sendCommand(instanceId, 'backup reset-chain');
        res.json({
            success: ok,
            message: ok ? '已向服务器发送重置备份链指令 (backup reset-chain)' : '发送重置备份链指令失败'
        });
    });

    // 路由：回档还原
    router.post('/restore', api.instances.withInstance, async (req, res) => {
        const { instState, instDir, instanceId } = req;
        const { filename, folder, world, type, mode } = req.body;

        if (!filename) return res.status(400).json({ error: '缺少 filename 参数' });

        const backupRoot = getBackupRoot(instDir);
        const worldName = world || getWorldName(instDir);
        const worldDir = path.join(instDir, worldName);

        // 查找目标备份文件完整绝对路径
        const allBackups = await scanAllBackups(instDir);
        const target = allBackups.find(b => b.name === filename && (!folder || b.folder === folder));
        if (!target || !fs.existsSync(target.path)) {
            return res.status(404).json({ error: `备份文件不存在: ${filename}` });
        }

        // 安全检查：防止路径穿越
        const resolvedPath = path.resolve(target.path);
        if (!resolvedPath.startsWith(path.resolve(backupRoot))) {
            return res.status(403).json({ error: 'Access Denied: 无效的备份路径' });
        }

        const sendProgress = (percent, msg) => {
            api.io.emit(`restore_progress:${instanceId}`, {
                percent: Math.min(100, Math.max(0, Math.round(percent))),
                message: msg
            });
        };

        // 1. 如果服务器运行中，先安全停机
        if (instState && instState.process) {
            api.sendCommand(instanceId, 'stop');
            sendProgress(10, '正在等待服务器安全关闭...');

            let checks = 0;
            while (instState.process && checks < 35) {
                await new Promise(r => setTimeout(r, 1000));
                checks++;
            }
            if (instState.process) {
                return res.status(500).json({ error: '服务器无法在预期时间内停止，请先手动停止服务器后再执行回档' });
            }
        }

        try {
            // 2. 备份当前现有存档
            sendProgress(25, '正在将当前存档备份到安全目录...');
            if (fs.existsSync(worldDir)) {
                const bakName = `${worldName}_bak_${Date.now()}`;
                await fs.rename(worldDir, path.join(instDir, bakName));
                if (api.context.appendLog) {
                    api.context.appendLog(instanceId, `[系统] 已将当前存档重命名备份为 ${bakName}\n`);
                }
            }
            await fs.ensureDir(worldDir);

            // 3. 计算需要依次解压的文件列表（链式推导）
            const filesToExtract = [];
            const isPartial = target.type === 'partial';
            const backupMode = target.mode || (target.folder === 'incremental' ? 'incremental' : 'differential');

            if (isPartial) {
                // 筛选同世界、同分类目录下的所有全量与增量备份
                const siblings = allBackups
                    .filter(b => b.world === target.world && b.folder === target.folder)
                    .sort((a, b) => a.name.localeCompare(b.name));

                // 找到 target 之前最近的一个 full 备份
                let baseFull = null;
                for (const b of siblings) {
                    if (b.type === 'full' && b.name < target.name) {
                        baseFull = b;
                    }
                }

                if (baseFull) {
                    filesToExtract.push(baseFull.path);

                    if (backupMode === 'incremental') {
                        // 增量模式：baseFull 之后、target 之前的所有 partial 也必须按序解压
                        const intermediatePartials = siblings.filter(
                            b => b.type === 'partial' && b.name > baseFull.name && b.name < target.name
                        );
                        for (const p of intermediatePartials) {
                            filesToExtract.push(p.path);
                        }
                    }
                }
            }

            // 最后加入当前目标备份
            filesToExtract.push(target.path);

            // 4. 依次解压，并执行路径标准化以兼容不同平台
            const total = filesToExtract.length;
            for (let i = 0; i < total; i++) {
                const currentZipPath = filesToExtract[i];
                const baseName = path.basename(currentZipPath);
                const stepPercent = 35 + Math.round(((i + 1) / total) * 60);
                sendProgress(stepPercent, `正在解压 (${i + 1}/${total}): ${baseName}`);

                if (api.context.appendLog) {
                    api.context.appendLog(instanceId, `[系统] 正在回档解压 (${i + 1}/${total}): ${baseName}...\n`);
                }

                const zip = new AdmZip(currentZipPath);
                const entries = zip.getEntries();

                for (const entry of entries) {
                    if (entry.isDirectory) continue;
                    // 将 Windows 反斜杠转换为正斜杠
                    const normalizedEntryName = entry.entryName.replace(/\\/g, '/');
                    const targetFilePath = path.join(worldDir, normalizedEntryName);

                    // 防 Zip Slip 漏洞攻击
                    if (!targetFilePath.startsWith(worldDir + path.sep) && targetFilePath !== worldDir) {
                        continue;
                    }

                    await fs.ensureDir(path.dirname(targetFilePath));
                    await fs.writeFile(targetFilePath, entry.getData());
                }
            }

            sendProgress(100, '回档完成！世界数据已成功还原');
            if (api.context.appendLog) {
                api.context.appendLog(instanceId, `[系统] 回档操作完成！请重新启动服务器。\n`);
            }
            setTimeout(() => api.io.emit(`restore_completed:${instanceId}`), 1000);
            res.json({ success: true, filesExtracted: filesToExtract.map(f => path.basename(f)) });
        } catch (e) {
            console.error('[BackupMod] Restore error:', e);
            if (api.context.appendLog) {
                api.context.appendLog(instanceId, `[错误] 回档失败: ${e.message}\n`);
            }
            api.io.emit(`restore_error:${instanceId}`, e.message);
            res.status(500).json({ error: e.message });
        }
    });

    // 路由：删除备份
    router.post('/delete', api.instances.withInstance, async (req, res) => {
        const { instDir } = req;
        const { filename, folder, world } = req.body;
        if (!filename) return res.status(400).json({ error: '缺少 filename 参数' });

        const backupRoot = getBackupRoot(instDir);
        const allBackups = await scanAllBackups(instDir);
        const target = allBackups.find(b => b.name === filename && (!folder || b.folder === folder) && (!world || b.world === world));

        if (!target || !fs.existsSync(target.path)) {
            return res.status(404).json({ error: '备份文件不存在' });
        }

        const resolvedPath = path.resolve(target.path);
        if (!resolvedPath.startsWith(path.resolve(backupRoot))) {
            return res.status(403).json({ error: 'Access Denied: 越界访问' });
        }

        try {
            await fs.remove(target.path);
            res.json({ success: true });
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    // 路由：下载备份
    router.get('/download', api.instances.withInstance, (req, res) => {
        const { filename, folder, world } = req.query;
        if (!filename || typeof filename !== 'string') {
            return res.status(400).send('Invalid filename');
        }

        const backupRoot = getBackupRoot(req.instDir);
        let targetPath = '';
        if (world && folder) {
            targetPath = path.join(backupRoot, world, folder, filename);
        } else if (folder) {
            targetPath = path.join(backupRoot, folder, filename);
        } else {
            targetPath = path.join(backupRoot, filename);
        }

        const resolvedPath = path.resolve(targetPath);
        if (!resolvedPath.startsWith(path.resolve(backupRoot) + path.sep)) {
            return res.status(403).send('Access Denied');
        }
        if (!fs.existsSync(resolvedPath)) {
            return res.status(404).send('Not Found');
        }
        res.download(resolvedPath);
    });

    // 注册插件路由与界面组件
    api.registerRoutes('/', router);

    api.registerSidebarItem({
        id: 'backup-mod',
        labelKey: 'plugins.mc-panel-plugin-backup-mod.title',
        icon: 'fa-shield-halved',
        view: 'backup-mod-view',
        location: 'instance'
    });

    api.registerComponent('backup-mod-view', 'component/BackupModView.js');
};

