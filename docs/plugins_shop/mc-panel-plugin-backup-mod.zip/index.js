module.exports = (api) => {
    api.registerSidebarItem({
        id: 'backup-mod',
        labelKey: 'plugins.mc-panel-plugin-backup-mod.title',
        icon: 'fa-shield-halved',
        view: 'backup-mod-view',
        location: 'instance'
    });
    api.registerComponent('backup-mod-view', 'component/BackupModView.js');
};
