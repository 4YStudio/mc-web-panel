const path = require('path');
const fs = require('fs-extra');
const express = require('express');
const axios = require('axios');

const MODRINTH_UA = 'CloudSpeak/MC-Panel/2.0.0 (henvei@cloudspeak.com)';

function applyGithubProxy(url) {
    if (!url || typeof url !== 'string') return url;
    const config = this._getConfig ? this._getConfig() : {};
    const githubProxy = config.githubProxy || '';
    if (githubProxy && (url.includes('github.com') || url.includes('githubusercontent.com'))) {
        let proxy = githubProxy;
        if (!proxy.endsWith('/')) proxy += '/';
        if (url.startsWith(proxy)) return url;
        return proxy + url;
    }
    return url;
}

module.exports = (api) => {
    const _getConfig = () => api.getConfig() || {};
    const proxyCtx = { _getConfig };
    const applyProxy = applyGithubProxy.bind(proxyCtx);

    const router = express.Router();

    // GET /search - Proxy search to Modrinth API
    router.get('/search', async (req, res) => {
        const { q, facets, offset, limit, index } = req.query;
        try {
            const params = { query: q, limit: limit || 20, offset: offset || 0 };
            if (facets) params.facets = facets;
            if (index) params.index = index;
            const response = await axios.get('https://api.modrinth.com/v2/search', {
                params,
                headers: { 'User-Agent': MODRINTH_UA }
            });
            res.json(response.data);
        } catch (e) {
            api.logger.error('[Modrinth Search Error]', e.message);
            res.status(500).json({ error: e.message });
        }
    });

    // GET /versions - Proxy game versions from Modrinth API
    router.get('/versions', async (req, res) => {
        try {
            const response = await axios.get('https://api.modrinth.com/v2/tag/game_version', {
                headers: { 'User-Agent': MODRINTH_UA }
            });
            res.json(response.data);
        } catch (e) {
            api.logger.error('[Modrinth Versions Error]', e.message);
            res.status(500).json({ error: e.message });
        }
    });

    // GET /project/:id - Proxy project + versions from Modrinth API
    router.get('/project/:id', async (req, res) => {
        try {
            const [project, versions] = await Promise.all([
                axios.get(`https://api.modrinth.com/v2/project/${req.params.id}`, {
                    headers: { 'User-Agent': MODRINTH_UA }
                }),
                axios.get(`https://api.modrinth.com/v2/project/${req.params.id}/version`, {
                    headers: { 'User-Agent': MODRINTH_UA }
                })
            ]);
            res.json({ project: project.data, versions: versions.data });
        } catch (e) {
            api.logger.error('[Modrinth Project Error]', e.message);
            res.status(500).json({ error: e.message });
        }
    });

    // POST /download - Download mod file to the instance's mods directory
    router.post('/download', async (req, res) => {
        const instanceId = (req.body && req.body.instanceId) || api.getActiveInstanceId();
        const instanceDir = api.getInstanceDir(instanceId);
        const { url, filename } = req.body;
        if (!url || !filename) return res.status(400).json({ error: 'URL and filename required' });

        const dest = path.join(instanceDir, 'mods', filename);
        api.logger.info(`[Modrinth] Installing mod: ${filename}...`);

        try {
            const downloadUrl = applyProxy(url);
            const response = await axios.get(downloadUrl, {
                responseType: 'stream',
                headers: { 'User-Agent': MODRINTH_UA }
            });
            const writer = fs.createWriteStream(dest);
            response.data.pipe(writer);

            writer.on('finish', () => {
                api.logger.info(`[Modrinth] Successfully installed ${filename}`);
                res.json({ success: true });
            });

            writer.on('error', (err) => {
                api.logger.error('[Modrinth] Download failed', err.message);
                res.status(500).json({ error: err.message });
            });
        } catch (e) {
            api.logger.error('[Modrinth] Installation error', e.message);
            res.status(500).json({ error: e.message });
        }
    });

    api.registerRoutes('/', router);
    api.registerSidebarItem({
        id: 'modrinth',
        view: 'modrinth-view',
        icon: 'fa-cloud-arrow-down',
        labelKey: 'sidebar.modrinth',
        location: 'instance'
    });
    api.registerComponent('modrinth-view', 'component/MainView.js');

    api.logger.info('[Modrinth Plugin] Backend initialized.');
};
