import { ref, computed, onMounted, onUnmounted, watch, nextTick } from '/js/vue.esm-browser.js';
import { store } from '/js/store.js';
import { api } from '/js/api.js';
import { showToast, openModal } from '/js/utils.js';
import Avatar from '/js/components/Avatar.js';

// ==================== Biome Names Dictionary ====================
const BIOME_NAMES = {
    'ocean': { zh: '海洋', en: 'Ocean' },
    'deep_ocean': { zh: '深海', en: 'Deep Ocean' },
    'warm_ocean': { zh: '暖水海洋', en: 'Warm Ocean' },
    'lukewarm_ocean': { zh: '温水海洋', en: 'Lukewarm Ocean' },
    'cold_ocean': { zh: '冷水海洋', en: 'Cold Ocean' },
    'deep_cold_ocean': { zh: '冷水深海', en: 'Deep Cold Ocean' },
    'frozen_ocean': { zh: '冻洋', en: 'Frozen Ocean' },
    'plains': { zh: '平原', en: 'Plains' },
    'sunflower_plains': { zh: '向日葵平原', en: 'Sunflower Plains' },
    'snowy_plains': { zh: '雪原', en: 'Snowy Plains' },
    'ice_spikes': { zh: '冰刺平原', en: 'Ice Spikes' },
    'desert': { zh: '沙漠', en: 'Desert' },
    'swamp': { zh: '沼泽', en: 'Swamp' },
    'mangrove_swamp': { zh: '红树林沼泽', en: 'Mangrove Swamp' },
    'forest': { zh: '森林', en: 'Forest' },
    'flower_forest': { zh: '繁花森林', en: 'Flower Forest' },
    'birch_forest': { zh: '白桦森林', en: 'Birch Forest' },
    'dark_forest': { zh: '黑森林', en: 'Dark Forest' },
    'old_growth_birch_forest': { zh: '原始白桦森林', en: 'Old Growth Birch Forest' },
    'old_growth_pine_taiga': { zh: '原始松木针叶林', en: 'Old Growth Pine Taiga' },
    'old_growth_spruce_taiga': { zh: '原始云杉针叶林', en: 'Old Growth Spruce Taiga' },
    'taiga': { zh: '针叶林', en: 'Taiga' },
    'snowy_taiga': { zh: '积雪针叶林', en: 'Snowy Taiga' },
    'savanna': { zh: '热带草原', en: 'Savanna' },
    'savanna_plateau': { zh: '热带高原', en: 'Savanna Plateau' },
    'windswept_hills': { zh: '风蚀丘陵', en: 'Windswept Hills' },
    'windswept_gravelly_hills': { zh: '风蚀砂砾丘陵', en: 'Windswept Gravelly Hills' },
    'windswept_forest': { zh: '风蚀森林', en: 'Windswept Forest' },
    'windswept_savanna': { zh: '风蚀热带草原', en: 'Windswept Savanna' },
    'jungle': { zh: '丛林', en: 'Jungle' },
    'sparse_jungle': { zh: '稀疏丛林', en: 'Sparse Jungle' },
    'bamboo_jungle': { zh: '竹林', en: 'Bamboo Jungle' },
    'badlands': { zh: '恶地', en: 'Badlands' },
    'eroded_badlands': { zh: '风蚀恶地', en: 'Eroded Badlands' },
    'wooded_badlands': { zh: '疏林恶地', en: 'Wooded Badlands' },
    'meadow': { zh: '草甸', en: 'Meadow' },
    'cherry_grove': { zh: '樱花树林', en: 'Cherry Grove' },
    'grove': { zh: '雪林', en: 'Grove' },
    'snowy_slopes': { zh: '积雪山坡', en: 'Snowy Slopes' },
    'frozen_peaks': { zh: '冻峰', en: 'Frozen Peaks' },
    'jagged_peaks': { zh: '尖峰', en: 'Jagged Peaks' },
    'stony_peaks': { zh: '裸岩山峰', en: 'Stony Peaks' },
    'river': { zh: '河流', en: 'River' },
    'frozen_river': { zh: '冻河', en: 'Frozen River' },
    'beach': { zh: '沙滩', en: 'Beach' },
    'snowy_beach': { zh: '积雪沙滩', en: 'Snowy Beach' },
    'stony_shore': { zh: '石岸', en: 'Stony Shore' },
    'dripstone_caves': { zh: '溶洞', en: 'Dripstone Caves' },
    'lush_caves': { zh: '繁茂洞穴', en: 'Lush Caves' },
    'deep_dark': { zh: '深暗之域', en: 'Deep Dark' },
    'nether_wastes': { zh: '下界荒地', en: 'Nether Wastes' },
    'warped_forest': { zh: '诡异森林', en: 'Warped Forest' },
    'crimson_forest': { zh: '绯红森林', en: 'Crimson Forest' },
    'soul_sand_valley': { zh: '灵魂沙峡谷', en: 'Soul Sand Valley' },
    'basalt_deltas': { zh: '玄武岩三角洲', en: 'Basalt Deltas' },
    'the_end': { zh: '末地', en: 'The End' },
    'small_end_islands': { zh: '末地小型岛屿', en: 'Small End Islands' },
    'end_midlands': { zh: '末地中阶地', en: 'End Midlands' },
    'end_highlands': { zh: '末地高地', en: 'End Highlands' },
    'end_barrens': { zh: '末地荒地', en: 'End Barrens' }
};

export default {
    name: 'ServerMapView',
    components: { Avatar },
    template: `
    <div :class="isFullscreen ? 'map-fullscreen-root' : 'p-3 p-md-4 p-lg-5'">
        <div :class="isFullscreen ? '' : 'container-xxl p-0'">
            <!-- 顶部标题栏（非全屏状态） -->
            <div v-if="!isFullscreen" class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
                <div class="d-flex align-items-center">
                    <div class="p-3 rounded-4 me-3 d-flex align-items-center justify-content-center" style="background: rgba(16, 185, 129, 0.12); color: #10b981; width: 56px; height: 56px; min-width: 56px;">
                        <i class="fa-solid fa-map-location-dot fa-2x"></i>
                    </div>
                    <div>
                        <h3 class="fw-black m-0 tracking-tight">{{ store.lang === 'zh' ? '服务器交互地图' : 'Server Interactive Map' }}</h3>
                        <p class="text-muted m-0 small d-none d-sm-block">{{ store.lang === 'zh' ? '极速高性能流式渲染，实时追踪玩家动态与安全地表定位' : 'Fast slippy map with real-time player radar and safe surface teleport' }}</p>
                    </div>
                </div>
                
                <div class="d-flex gap-2">
                    <button class="btn btn-sm btn-outline-secondary rounded-3 px-3 py-2" @click="resetView">
                        <i class="fa-solid fa-crosshairs me-1"></i>
                        {{ store.lang === 'zh' ? '重置视图' : 'Reset View' }}
                    </button>
                    <button class="btn btn-sm btn-outline-emerald rounded-3 px-3 py-2" @click="forceRebuild" :disabled="rendering">
                        <i class="fa-solid fa-rotate me-1" :class="{'fa-spin': rendering}"></i>
                        {{ store.lang === 'zh' ? '完整重建地图' : 'Rebuild Map' }}
                    </button>
                </div>
            </div>

            <!-- 主地图展示区与右侧玩家雷达 -->
            <div :class="isFullscreen ? '' : 'row g-4'">
                <!-- 地图视口 -->
                <div :class="isFullscreen ? '' : 'col-12 col-xl-9'">
                    <div :class="isFullscreen ? 'map-fullscreen-card' : 'card border-0 shadow-sm rounded-4 overflow-hidden position-relative'" :style="isFullscreen ? {} : {background: 'var(--c-surface-elevated)'}">
                        <!-- 悬浮维度切换栏与高度切片 -->
                        <div class="dimension-selector position-absolute top-0 start-0 m-2 m-md-3 d-flex align-items-center gap-1 p-1 rounded-3 shadow-lg overflow-x-auto" style="z-index: 400; background: rgba(15, 23, 42, 0.85); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.08); max-width: calc(100% - 16px);">
                            <button v-for="dim in dimensionsList" :key="dim.id"
                                    class="btn btn-sm rounded-2 border-0 px-2 px-md-3 py-1.5 transition-all text-white flex-shrink-0"
                                    :class="selectedDim === dim.id ? dim.activeClass : 'bg-transparent text-muted-hover'"
                                    @click="selectedDim = dim.id">
                                <i class="fa-solid me-1" :class="dim.icon"></i>
                                {{ store.lang === 'zh' ? dim.zh : dim.en }}
                            </button>

                            <!-- Y 轴切片高度选择 (下界必用) -->
                            <div class="d-flex align-items-center gap-1 ms-1 ps-2 border-start border-white border-opacity-10 text-white-50 small">
                                <i class="fa-solid fa-layer-group text-warning" :title="store.lang === 'zh' ? '地图渲染高度上限 (向下切片扫描)' : 'Max Render Height (Slice)'"></i>
                                <span class="d-none d-sm-inline font-monospace" style="font-size: 11px;">Y:</span>
                                <select v-model="currentDimMaxY" class="form-select form-select-sm text-white border-0 py-0 px-2" style="font-size: 11px; height: 26px; width: auto; background-color: rgba(30, 41, 59, 0.95)!important; border-radius: 6px;">
                                    <option v-for="opt in heightOptions" :key="opt.value" :value="opt.value">
                                        {{ opt.label }}
                                    </option>
                                </select>
                            </div>
                        </div>

                        <!-- 地图容器 -->
                        <div id="leaflet-map" :style="isFullscreen ? 'width:100%;height:100%;background:#0b0f19;' : 'width:100%;height:620px;background:#0b0f19;'"></div>

                        <!-- 渲染加载指示 -->
                        <div v-if="rendering" class="position-absolute start-50 top-50 translate-middle d-flex flex-column align-items-center justify-content-center p-4 rounded-4 shadow-lg" style="z-index: 401; background: rgba(15, 23, 42, 0.88); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.15);">
                            <div class="spinner-border text-emerald mb-3" role="status"></div>
                            <span class="text-white-50 small">{{ store.lang === 'zh' ? '正在解包方块状态，生成高清晰度地图图层...' : 'Parsing block states, generating high-res map tiles...' }}</span>
                        </div>

                        <!-- 无区块数据提示 -->
                        <div v-if="!rendering && !regions.length" class="position-absolute start-50 top-50 translate-middle d-flex flex-column align-items-center justify-content-center p-4 rounded-4 text-center" style="z-index: 399; pointer-events: none; background: rgba(15, 23, 42, 0.78); backdrop-filter: blur(6px); border: 1px dashed rgba(255,255,255,0.15); max-width: 320px;">
                            <i class="fa-solid fa-mountain-sun fa-2x text-muted mb-2 opacity-50"></i>
                            <div class="text-white-50 small fw-bold">{{ store.lang === 'zh' ? '当前维度暂无已生成的区块' : 'No region data in this dimension' }}</div>
                            <div class="text-muted mt-1" style="font-size: 11px;">{{ store.lang === 'zh' ? '玩家进入该维度探索后，地图将自动实时呈现' : 'Tiles will render once players explore this dimension' }}</div>
                        </div>

                        <!-- 悬浮坐标 HUD 与生物群系 -->
                        <div class="coords-hud position-absolute bottom-0 start-50 translate-middle-x mb-3 px-3 py-1.5 rounded-3 shadow-lg font-monospace text-white d-flex align-items-center gap-2" style="z-index: 400; background: rgba(15, 23, 42, 0.8); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.1); font-size: 12px; letter-spacing: 0.5px;">
                            <span class="text-muted">X:</span> <span class="text-emerald fw-bold">{{ mouseCoords.x }}</span>
                            <span class="text-white-50">|</span>
                            <span class="text-muted">Z:</span> <span class="text-emerald fw-bold">{{ mouseCoords.z }}</span>
                            <template v-if="currentBiome">
                                <span class="text-white-50">|</span>
                                <i class="fa-solid fa-leaf text-success" style="font-size:10px;"></i>
                                <span class="text-success">{{ currentBiome }}</span>
                            </template>
                        </div>

                        <!-- 左下角全屏开关 -->
                        <button class="btn btn-sm position-absolute bottom-0 start-0 m-3 rounded-3 text-white-50" style="z-index:400; background:rgba(15,23,42,0.75); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.08);"
                                @click="isFullscreen = !isFullscreen" :title="store.lang === 'zh' ? '全屏显示' : 'Fullscreen'">
                            <i class="fa-solid" :class="isFullscreen ? 'fa-compress' : 'fa-expand'"></i>
                        </button>

                        <!-- 全屏模式悬浮工具按钮 -->
                        <template v-if="isFullscreen">
                            <button class="btn btn-sm position-absolute bottom-0 start-0 ms-5 mb-3 rounded-pill text-white-50 px-3" style="z-index:400; background:rgba(15,23,42,0.75); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.08);"
                                    @click="resetView" :title="store.lang === 'zh' ? '重置视图' : 'Reset View'">
                                <i class="fa-solid fa-crosshairs me-1"></i>{{ store.lang === 'zh' ? '重置' : 'Reset' }}
                            </button>
                            <button class="btn btn-sm position-absolute bottom-0 start-0 ms-5 mb-3 rounded-pill text-white-50 px-3" style="z-index:400; left:160px; background:rgba(15,23,42,0.75); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.08);"
                                    @click="forceRebuild" :disabled="rendering" :title="store.lang === 'zh' ? '完整重建地图' : 'Rebuild Map'">
                                <i class="fa-solid fa-rotate me-1" :class="{'fa-spin': rendering}"></i>{{ store.lang === 'zh' ? '重建' : 'Rebuild' }}
                            </button>
                        </template>
                    </div>
                </div>

                <!-- 右侧玩家雷达列表 -->
                <div v-if="!isFullscreen" class="col-12 col-xl-3">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden h-100" style="background: var(--c-surface-elevated);">
                        <div class="card-header border-bottom border-white border-opacity-10 p-3 bg-transparent d-flex align-items-center">
                            <h5 class="m-0 fw-bold d-flex align-items-center text-white-50">
                                <i class="fa-solid fa-users me-2 text-emerald opacity-75"></i>
                                {{ store.lang === 'zh' ? '玩家雷达' : 'Player Radar' }}
                                <span class="badge bg-emerald-soft ms-2" style="font-size: 0.75rem;">{{ players.length }}</span>
                            </h5>
                        </div>
                        <div class="card-body p-0 overflow-auto custom-scrollbar" style="max-height: 550px;">
                            <div class="list-group list-group-flush">
                                <div v-for="(p, index) in players" :key="'p-' + (p.uuid || p.name || index)"
                                     class="list-group-item bg-transparent border-white border-opacity-10 p-3 d-flex align-items-center justify-content-between hover-bg-dark transition-all"
                                     @click="panToPlayer(p)">
                                    <div class="d-flex align-items-center min-w-0 cursor-pointer">
                                        <avatar :player="p.name" :size="28" class="me-2 flex-shrink-0"></avatar>
                                        <div class="min-w-0">
                                            <div class="fw-bold d-flex align-items-center gap-1 text-white">
                                                <span class="text-truncate">{{ p.name }}</span>
                                                <span v-if="p.online" class="badge rounded-pill bg-success bg-opacity-25 text-success" style="font-size: 7px; padding: 1px 4px;">ON</span>
                                                <span class="badge text-white" :class="getDimBadgeClass(p.dimension)" style="font-size: 9px; opacity: 0.85;">
                                                    {{ getDimName(p.dimension) }}
                                                </span>
                                            </div>
                                            <div class="font-monospace text-muted mt-0.5" style="font-size: 0.7rem;">
                                                {{ p.coordsText }}
                                            </div>
                                            <div v-if="p.online && (p.hasHealth || p.hasFood)" class="d-flex gap-2 mt-1 align-items-center" style="font-size: 0.65rem;">
                                                <div v-if="p.hasHealth" class="d-flex align-items-center gap-1" :title="store.lang === 'zh' ? '生命值' : 'Health'">
                                                    <i class="fa-solid fa-heart text-danger" style="font-size: 8px;"></i>
                                                    <div class="progress" style="width: 40px; height: 4px; background: rgba(255,255,255,0.1);">
                                                        <div class="progress-bar bg-danger" :style="{width: p.healthPercent + '%'}"></div>
                                                    </div>
                                                    <span class="text-white-50">{{ p.healthDisplay }}</span>
                                                </div>
                                                <div v-if="p.hasFood" class="d-flex align-items-center gap-1" :title="store.lang === 'zh' ? '饥饿值' : 'Hunger'">
                                                    <i class="fa-solid fa-drumstick-bite" style="font-size: 8px; color: #d97706;"></i>
                                                    <div class="progress" style="width: 40px; height: 4px; background: rgba(255,255,255,0.1);">
                                                        <div class="progress-bar" style="background: #d97706;" :style="{width: p.foodPercent + '%'}"></div>
                                                    </div>
                                                    <span class="text-white-50">{{ p.foodDisplay }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="btn btn-sm btn-link p-0 text-white-50 text-decoration-none small flex-shrink-0" @click.stop="showPlayerMenuFn(p, $event)">
                                        <i class="fa-solid fa-ellipsis-vertical"></i>
                                    </button>
                                </div>
                                <div v-if="!players.length" class="text-center py-5 text-muted opacity-50 small">
                                    {{ store.lang === 'zh' ? '暂未发现任何玩家数据档案' : 'No player profiles found' }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 全屏模式悬浮玩家雷达 -->
                <div v-if="isFullscreen" class="position-fixed" style="top:80px;right:16px;z-index:9999;width:280px;">
                    <div class="rounded-4 shadow-lg overflow-hidden" style="background:rgba(15,23,42,0.88);backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.1);">
                        <div class="d-flex align-items-center px-3 py-2 border-bottom" style="border-color:rgba(255,255,255,0.08)!important;">
                            <i class="fa-solid fa-users me-2 text-emerald opacity-75"></i>
                            <span class="text-white-50 small fw-bold">{{ store.lang === 'zh' ? '玩家雷达' : 'Player Radar' }}</span>
                            <span class="badge bg-emerald-soft ms-2" style="font-size:0.7rem;">{{ players.length }}</span>
                            <button class="btn btn-sm btn-link p-0 ms-auto text-white-50" @click="radarCollapsed = !radarCollapsed">
                                <i class="fa-solid" :class="radarCollapsed ? 'fa-chevron-down' : 'fa-chevron-up'" style="font-size:10px;"></i>
                            </button>
                        </div>
                        <div v-if="!radarCollapsed" class="overflow-auto custom-scrollbar" style="max-height:calc(100vh - 200px);">
                            <div class="list-group list-group-flush">
                                <div v-for="(p, index) in players" :key="'fs-p-' + (p.uuid || p.name || index)"
                                     class="list-group-item bg-transparent border-white border-opacity-10 p-2 d-flex align-items-center justify-content-between hover-bg-dark transition-all"
                                     @click="panToPlayer(p)">
                                    <div class="d-flex align-items-center min-w-0 cursor-pointer">
                                        <avatar :player="p.name" :size="24" class="me-2 flex-shrink-0"></avatar>
                                        <div class="min-w-0">
                                            <div class="fw-bold d-flex align-items-center gap-1 text-white" style="font-size:0.8rem;">
                                                <span class="text-truncate">{{ p.name }}</span>
                                                <span v-if="p.online" class="badge rounded-pill bg-success bg-opacity-25 text-success" style="font-size:6px;padding:0 3px;">ON</span>
                                            </div>
                                            <div class="font-monospace text-muted" style="font-size:0.6rem;">{{ p.coordsText }}</div>
                                        </div>
                                    </div>
                                    <button class="btn btn-sm btn-link p-0 text-white-50 flex-shrink-0" @click.stop="showPlayerMenuFn(p, $event)">
                                        <i class="fa-solid fa-ellipsis-vertical" style="font-size:10px;"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <!-- 玩家快捷管理菜单 -->
    <div v-if="playerMenu.visible" class="position-fixed" :style="{left: playerMenu.x + 'px', top: playerMenu.y + 'px', zIndex: 10000}" @click.stop>
        <ul class="dropdown-menu show" style="min-width: 200px; box-shadow: 0 8px 24px rgba(0,0,0,0.5); background: #1e293b; border: 1px solid rgba(255,255,255,0.1);">
            <li class="px-3 py-2 text-white-50 small fw-bold border-bottom border-white border-opacity-10">
                <i class="fa-solid fa-user me-1"></i> {{ playerMenu.player?.name }}
            </li>
            <li><a class="dropdown-item text-white-50 hover-text-white" @click="askTeleport(playerMenu.player)"><i class="fa-solid fa-location-dot me-2 text-primary"></i>{{ store.lang === 'zh' ? '传送玩家' : 'Teleport' }}</a></li>
            <li><a class="dropdown-item text-white-50 hover-text-white" @click="askGamemode(playerMenu.player)"><i class="fa-solid fa-gamepad me-2 text-info"></i>{{ store.lang === 'zh' ? '游戏模式' : 'Gamemode' }}</a></li>
            <li><a class="dropdown-item text-white-50 hover-text-white" @click="askGiveItem(playerMenu.player)"><i class="fa-solid fa-gift me-2 text-success"></i>{{ store.lang === 'zh' ? '给予物品' : 'Give Item' }}</a></li>
            <li><hr class="dropdown-divider border-white border-opacity-10"></li>
            <li><a class="dropdown-item text-white-50 hover-text-white" @click="sendCmdToPlayer(playerMenu.player, 'clear')"><i class="fa-solid fa-broom me-2 text-warning"></i>{{ store.lang === 'zh' ? '清空背包' : 'Clear Inv' }}</a></li>
            <li><a class="dropdown-item text-danger hover-text-white" @click="sendCmdToPlayer(playerMenu.player, 'kill')"><i class="fa-solid fa-skull me-2"></i>{{ store.lang === 'zh' ? '击杀' : 'Kill' }}</a></li>
            <li><a class="dropdown-item text-danger hover-text-white" @click="askBan(playerMenu.player)"><i class="fa-solid fa-ban me-2"></i>{{ store.lang === 'zh' ? '封禁' : 'Ban' }}</a></li>
        </ul>
    </div>

    <!-- 地图点击菜单 (分享、传送与区块重建) -->
    <div v-if="mapClickMenu.visible" class="position-fixed" :style="{left: mapClickMenu.x + 'px', top: mapClickMenu.y + 'px', zIndex: 10000}" @click.stop>
        <ul class="dropdown-menu show" style="min-width: 210px; box-shadow: 0 8px 24px rgba(0,0,0,0.5); background: #1e293b; border: 1px solid rgba(255,255,255,0.1);">
            <li class="px-3 py-2 text-white-50 small fw-bold border-bottom border-white border-opacity-10">
                <i class="fa-solid fa-crosshairs me-1 text-emerald"></i> {{ mapClickMenu.coords?.x }}, {{ mapClickMenu.coords?.z }}
                <span v-if="mapClickMenu.coords?.surfaceY !== null && mapClickMenu.coords?.surfaceY !== undefined" class="badge bg-emerald-soft ms-1">Y:{{ mapClickMenu.coords.surfaceY }}</span>
            </li>
            <li><a class="dropdown-item text-white-50 hover-text-white" @click="openShareLocationModal"><i class="fa-solid fa-share-from-square me-2 text-info"></i>{{ store.lang === 'zh' ? '分享位置坐标' : 'Share Location' }}</a></li>
            <li><a class="dropdown-item text-white-50 hover-text-white" @click="openTeleportModal"><i class="fa-solid fa-location-dot me-2 text-primary"></i>{{ store.lang === 'zh' ? '传送到这里' : 'Teleport Here' }}</a></li>
            <li><hr class="dropdown-divider border-white border-opacity-10"></li>
            <li><a class="dropdown-item text-warning" @click="rebuildCurrentChunk" @mouseenter="hoveredRebuildChunk=true; updateChunkHighlight(mapClickMenu.coords.x, mapClickMenu.coords.z)" @mouseleave="hoveredRebuildChunk=false; removeChunkHighlight()">
                <i class="fa-solid fa-cube me-2"></i>{{ store.lang === 'zh' ? '重建当前区块' : 'Rebuild Chunk' }}
            </a></li>
        </ul>
    </div>

    <!-- 分享坐标弹窗 -->
    <Transition name="modal-fade">
        <div class="modal fade show" v-if="showShareModal" style="display: block; z-index: 1050;">
            <div class="modal-backdrop fade show" @click="closeShareModal" style="z-index: -1;"></div>
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow-lg" style="border-radius: 16px; overflow: hidden; background: #1e293b; color: #fff;">
                    <div class="modal-header border-bottom border-white border-opacity-10 pb-3 pt-3 px-4">
                        <h5 class="modal-title fw-bold">
                            <i class="fa-solid fa-share-from-square me-2 text-info"></i>
                            {{ store.lang === 'zh' ? '分享位置坐标' : 'Share Location' }}
                        </h5>
                        <button type="button" class="btn-close btn-close-white" @click="closeShareModal"></button>
                    </div>
                    <div class="modal-body px-4 py-3">
                        <div class="mb-3">
                            <label class="form-label small text-muted mb-1">{{ store.lang === 'zh' ? '坐标位置' : 'Coordinates' }}</label>
                            <input type="text" class="form-control bg-dark border-secondary text-white font-monospace" :value="shareCoords" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small text-muted mb-1">{{ store.lang === 'zh' ? '附加消息 (可选)' : 'Message (optional)' }}</label>
                            <input type="text" class="form-control bg-dark border-secondary text-white" v-model="shareMessage" :placeholder="store.lang === 'zh' ? '例如：这里发现了主城遗迹' : 'e.g. Found ruins here'">
                        </div>
                    </div>
                    <div class="modal-footer border-top border-white border-opacity-10 pt-3 px-4 pb-3">
                        <button class="btn btn-outline-secondary rounded-pill px-4" @click="closeShareModal">{{ store.lang === 'zh' ? '取消' : 'Cancel' }}</button>
                        <button class="btn btn-primary rounded-pill px-4 fw-bold shadow" @click="confirmShareLocation">
                            <i class="fa-solid fa-paper-plane me-1"></i> {{ store.lang === 'zh' ? '广播分享' : 'Broadcast' }}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </Transition>

    <!-- 传送到此弹窗 -->
    <Transition name="modal-fade">
        <div class="modal fade show" v-if="showTeleportModal" style="display: block; z-index: 1050;">
            <div class="modal-backdrop fade show" @click="closeTeleportModal" style="z-index: -1;"></div>
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow-lg" style="border-radius: 16px; overflow: hidden; background: #1e293b; color: #fff;">
                    <div class="modal-header border-bottom border-white border-opacity-10 pb-3 pt-3 px-4">
                        <h5 class="modal-title fw-bold">
                            <i class="fa-solid fa-location-dot me-2 text-primary"></i>
                            {{ store.lang === 'zh' ? '安全地表传送' : 'Safe Surface Teleport' }}
                        </h5>
                        <button type="button" class="btn-close btn-close-white" @click="closeTeleportModal"></button>
                    </div>
                    <div class="modal-body px-4 py-3">
                        <div class="mb-3">
                            <label class="form-label small text-muted mb-1">{{ store.lang === 'zh' ? '传送目标坐标 (已自动校准地表高度)' : 'Target Coords (Surface Y Auto-Calibrated)' }}</label>
                            <input type="text" class="form-control bg-dark border-secondary text-emerald font-monospace fw-bold" :value="teleportCoords" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small text-muted mb-1">{{ store.lang === 'zh' ? '选择在线玩家' : 'Select Online Player' }}</label>
                            <select class="form-select bg-dark border-secondary text-white" v-model="teleportTarget">
                                <option v-for="p in onlinePlayersList" :key="p" :value="p">{{ p }}</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer border-top border-white border-opacity-10 pt-3 px-4 pb-3">
                        <button class="btn btn-outline-secondary rounded-pill px-4" @click="closeTeleportModal">{{ store.lang === 'zh' ? '取消' : 'Cancel' }}</button>
                        <button class="btn btn-primary rounded-pill px-4 fw-bold shadow" @click="confirmTeleport" :disabled="!teleportTarget">
                            <i class="fa-solid fa-circle-check me-1"></i> {{ store.lang === 'zh' ? '立即传送' : 'Teleport Now' }}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </Transition>
    </div>
    `,
    setup() {
        const instanceId = computed(() => store.currentInstanceId || store.activeInstanceId || 'default');
        const selectedDim = ref('minecraft:overworld');
        const regions = ref([]);
        const players = ref([]);
        const rendering = ref(false);
        const autoRefresh = ref(true);
        const isFullscreen = ref(false);
        const radarCollapsed = ref(false);
        const mouseCoords = ref({ x: 0, z: 0 });
        const currentBiome = ref('');

        let map = null;
        let overlays = {}; // file -> L.ImageOverlay
        let overlayMtimes = {}; // file -> mtime
        let lastRenderedDim = '';
        let playerMarkers = {}; // uuid -> L.Marker
        let clickMarker = null;
        let chunkHighlightRect = null;
        let hoveredRebuildChunk = ref(false);
        let heartbeatInterval = null;
        let refreshInterval = null;
        let docClickHandler = null;
        let styleEl = null;
        let isDisposed = false;

        const dimensionsList = [
            { id: 'minecraft:overworld', zh: '主世界', en: 'Overworld', icon: 'fa-earth-americas', activeClass: 'bg-emerald text-white' },
            { id: 'minecraft:the_nether', zh: '下界', en: 'The Nether', icon: 'fa-fire', activeClass: 'bg-danger text-white' },
            { id: 'minecraft:the_end', zh: '末地', en: 'The End', icon: 'fa-meteor', activeClass: 'bg-purple text-white' }
        ];

        // 各维度 Y 轴切片高度记忆 (下界核心透视)
        const dimMaxYMap = ref({
            'minecraft:overworld': 320,
            'minecraft:the_nether': 76,
            'minecraft:the_end': 256
        });

        const currentDimMaxY = computed({
            get: () => dimMaxYMap.value[selectedDim.value] ?? (selectedDim.value === 'minecraft:the_nether' ? 76 : 320),
            set: (val) => {
                dimMaxYMap.value[selectedDim.value] = Number(val);
                drawMapOverlays(true);
            }
        });

        const heightOptions = computed(() => {
            if (selectedDim.value === 'minecraft:the_nether') {
                return [
                    { value: 128, label: store.lang === 'zh' ? 'Y:128 (基岩天花板上方)' : 'Y:128 (Bedrock Roof)' },
                    { value: 96, label: store.lang === 'zh' ? 'Y:96 (高层空腔)' : 'Y:96 (High Caverns)' },
                    { value: 76, label: store.lang === 'zh' ? 'Y:76 (推荐·核心主层/要塞)' : 'Y:76 (Recommended · Fortresses & Main)' },
                    { value: 64, label: store.lang === 'zh' ? 'Y:64 (中下层走廊)' : 'Y:64 (Mid-Lower Corridors)' },
                    { value: 48, label: store.lang === 'zh' ? 'Y:48 (底层洞穴/遗迹)' : 'Y:48 (Lower Caverns)' },
                    { value: 32, label: store.lang === 'zh' ? 'Y:32 (熔岩海平面)' : 'Y:32 (Lava Sea Level)' }
                ];
            }
            if (selectedDim.value === 'minecraft:the_end') {
                return [
                    { value: 256, label: store.lang === 'zh' ? 'Y:256 (末地全高·默认)' : 'Y:256 (Default Top)' },
                    { value: 80, label: store.lang === 'zh' ? 'Y:80 (末地城/高地)' : 'Y:80 (End Cities & Islands)' },
                    { value: 60, label: store.lang === 'zh' ? 'Y:60 (主岛地面层)' : 'Y:60 (Main Island Surface)' }
                ];
            }
            return [
                { value: 320, label: store.lang === 'zh' ? 'Y:320 (地表全高·默认)' : 'Y:320 (Surface All · Default)' },
                { value: 128, label: store.lang === 'zh' ? 'Y:128 (山地切片)' : 'Y:128 (Mountain Slice)' },
                { value: 64, label: store.lang === 'zh' ? 'Y:64 (海平面切片)' : 'Y:64 (Sea Level Slice)' },
                { value: 0, label: store.lang === 'zh' ? 'Y:0 (浅层矿洞/过渡层)' : 'Y:0 (Shallow Caves)' },
                { value: -32, label: store.lang === 'zh' ? 'Y:-32 (深层洞穴/深暗之域)' : 'Y:-32 (Deep Dark / Caves)' }
            ];
        });

        const onlinePlayersList = computed(() => store.onlinePlayers || []);

        // 玩家右键菜单
        const playerMenu = ref({ visible: false, player: null, x: 0, y: 0 });
        const showPlayerMenuFn = (player, event) => {
            hidePlayerMenu();
            let x = event.clientX;
            let y = event.clientY;
            if (x + 200 > window.innerWidth) x = window.innerWidth - 210;
            if (y + 250 > window.innerHeight) y = window.innerHeight - 260;
            playerMenu.value = { visible: true, player, x, y };
        };
        const hidePlayerMenu = () => { playerMenu.value.visible = false; };

        // 地图点击菜单
        const mapClickMenu = ref({ visible: false, x: 0, y: 0, coords: { x: 0, z: 0, surfaceY: null } });
        const hideMapClickMenu = () => {
            mapClickMenu.value.visible = false;
            hoveredRebuildChunk.value = false;
            removeChunkHighlight();
            if (clickMarker && map) {
                map.removeLayer(clickMarker);
                clickMarker = null;
            }
        };

        // 分享位置弹窗
        const showShareModal = ref(false);
        const shareCoords = ref('');
        const shareMessage = ref('');
        const openShareLocationModal = () => {
            const { x, z, surfaceY } = mapClickMenu.value.coords;
            shareCoords.value = surfaceY !== null ? `X:${x}, Y:${surfaceY}, Z:${z}` : `X:${x}, Z:${z}`;
            shareMessage.value = '';
            hideMapClickMenu();
            showShareModal.value = true;
        };
        const closeShareModal = () => { showShareModal.value = false; };
        const confirmShareLocation = async () => {
            const msg = shareMessage.value ? ` (${shareMessage.value})` : '';
            const fullMsg = `[${shareCoords.value}]${msg}`;
            await sendCmd(`tellraw @a {"text":"${fullMsg}","color":"aqua"}`);
            showShareModal.value = false;
        };

        // 传送到此弹窗
        const showTeleportModal = ref(false);
        const teleportCoords = ref('');
        const teleportTarget = ref('');
        const openTeleportModal = () => {
            const { x, z, surfaceY } = mapClickMenu.value.coords;
            const dimName = getDimName(selectedDim.value);
            if (surfaceY !== null && surfaceY !== undefined) {
                teleportCoords.value = `[${dimName}]  X: ${x}  Y: ${surfaceY}  Z: ${z}`;
            } else {
                teleportCoords.value = `[${dimName}]  X: ${x}  Z: ${z}  (Y: 自动地表)`;
            }
            teleportTarget.value = onlinePlayersList.value[0] || '';
            hideMapClickMenu();
            showTeleportModal.value = true;
        };
        const closeTeleportModal = () => { showTeleportModal.value = false; };
        const confirmTeleport = async () => {
            if (!teleportTarget.value) return;
            const { x, z, surfaceY } = mapClickMenu.value.coords;
            const dim = selectedDim.value || 'minecraft:overworld';
            if (surfaceY !== null && surfaceY !== undefined) {
                await sendCmd(`execute in ${dim} run tp ${teleportTarget.value} ${x} ${surfaceY} ${z}`);
            } else {
                await sendCmd(`execute in ${dim} run spreadplayers ${x} ${z} 0 1 false ${teleportTarget.value}`);
            }
            showTeleportModal.value = false;
        };

        // 本地加载 Leaflet
        const loadLeaflet = () => {
            return new Promise((resolve) => {
                if (window.L) { resolve(); return; }
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = '/api/plugins/mc-panel-plugin-map/lib/leaflet.css';
                document.head.appendChild(link);

                const script = document.createElement('script');
                script.src = '/api/plugins/mc-panel-plugin-map/lib/leaflet.js';
                script.onload = () => resolve();
                document.head.appendChild(script);
            });
        };

        // 初始化地图
        const initMap = () => {
            if (map) return;
            map = L.map('leaflet-map', {
                crs: L.CRS.Simple,
                minZoom: -5,
                maxZoom: 3,
                zoom: -2,
                center: [0, 0],
                zoomControl: false,
                attributionControl: false,
                wheelPxPerZoomLevel: 150,
                zoomSnap: 0.5
            });

            L.control.zoom({ position: 'bottomright' }).addTo(map);

            map.on('mousemove', (e) => {
                mouseCoords.value.x = Math.round(e.latlng.lng);
                mouseCoords.value.z = Math.round(-e.latlng.lat);
                fetchBiome(mouseCoords.value.x, mouseCoords.value.z);
                if (hoveredRebuildChunk.value) updateChunkHighlight(mouseCoords.value.x, mouseCoords.value.z);
            });

            map.on('click', async (e) => {
                hideMapClickMenu();
                const x = Math.round(e.latlng.lng);
                const z = Math.round(-e.latlng.lat);

                if (clickMarker) map.removeLayer(clickMarker);
                const clickIcon = L.divIcon({
                    className: 'leaflet-click-marker',
                    html: `<div style="width:16px;height:16px;border:2px solid #fff;border-radius:50%;background:rgba(16,185,129,0.85);box-shadow:0 0 10px rgba(16,185,129,0.7);"></div>`,
                    iconSize: [16, 16],
                    iconAnchor: [8, 8]
                });
                clickMarker = L.marker([-z, x], { icon: clickIcon, interactive: false }).addTo(map);

                // 异步获取地表安全高度
                let surfaceY = null;
                try {
                    const yRes = await api.get('/api/plugins/mc-panel-plugin-map/safe-surface-y', {
                        params: { instanceId: instanceId.value, dimension: selectedDim.value, x, z, maxY: currentDimMaxY.value }
                    });
                    if (yRes.data?.surfaceY !== null && yRes.data?.surfaceY !== undefined) {
                        surfaceY = yRes.data.surfaceY;
                    }
                } catch (e) {}

                mapClickMenu.value = {
                    visible: true,
                    x: e.originalEvent.clientX,
                    y: e.originalEvent.clientY,
                    coords: { x, z, surfaceY }
                };
            });
        };

        // 绘制/平滑换图
        const drawMapOverlays = async (force = false) => {
            if (isDisposed || !map) return;
            if (force) rendering.value = true;
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-map/regions', {
                    params: { instanceId: instanceId.value, dimension: selectedDim.value }
                });
                if (isDisposed) return;
                regions.value = res.data || [];
                const activeFiles = new Set(regions.value.map(r => r.file));

                // 切换维度或切片高度时强制清除旧图层
                const currentHeightKey = `${selectedDim.value}_${currentDimMaxY.value}`;
                const dimOrHeightChanged = lastRenderedDim !== currentHeightKey;
                if (dimOrHeightChanged) {
                    for (const file of Object.keys(overlays)) {
                        try { map.removeLayer(overlays[file]); } catch (e) {}
                        delete overlays[file];
                        delete overlayMtimes[file];
                    }
                    lastRenderedDim = currentHeightKey;
                }

                // 移除失效图层
                for (const file of Object.keys(overlays)) {
                    if (!activeFiles.has(file) || force) {
                        try { map.removeLayer(overlays[file]); } catch (e) {}
                        delete overlays[file];
                        delete overlayMtimes[file];
                    }
                }

                for (const r of regions.value) {
                    if (isDisposed) return;
                    const needsUpdate = force || !overlays[r.file] || (r.mtime && overlayMtimes[r.file] !== r.mtime);
                    if (needsUpdate) {
                        const urlParams = new URLSearchParams({
                            instanceId: instanceId.value,
                            dimension: selectedDim.value,
                            region: r.file,
                            maxY: String(currentDimMaxY.value)
                        });
                        if (force) urlParams.append('force', 'true');
                        if (r.mtime) urlParams.append('mtime', r.mtime);

                        const imageUrl = `/api/plugins/mc-panel-plugin-map/render?${urlParams.toString()}`;
                        const bounds = [[-(r.z + 1) * 512, r.x * 512], [-r.z * 512, (r.x + 1) * 512]];

                        // 预加载平滑换图，防止黑白闪烁
                        const img = new Image();
                        img.src = imageUrl;
                        img.onload = () => {
                            if (isDisposed || !map) return;
                            const newOverlay = L.imageOverlay(imageUrl, bounds).addTo(map);
                            const oldOverlay = overlays[r.file];
                            if (oldOverlay && oldOverlay !== newOverlay) {
                                try { map.removeLayer(oldOverlay); } catch (e) {}
                            }
                            overlays[r.file] = newOverlay;
                            if (r.mtime) overlayMtimes[r.file] = r.mtime;
                        };
                    }
                }
            } catch (e) {
                console.error('[Map Plugin] Draw overlays failed:', e);
            } finally {
                if (force && !isDisposed) rendering.value = false;
            }
        };

        // 生物群系查询
        let biomeTimer = null;
        let lastBiomeChunk = '';
        const fetchBiome = (x, z) => {
            const chunkKey = `${Math.floor(x / 16)}_${Math.floor(z / 16)}`;
            if (biomeTimer) clearTimeout(biomeTimer);
            biomeTimer = setTimeout(async () => {
                if (isDisposed) return;
                if (chunkKey === lastBiomeChunk && currentBiome.value) return;
                lastBiomeChunk = chunkKey;
                try {
                    const res = await api.get('/api/plugins/mc-panel-plugin-map/biome', {
                        params: { instanceId: instanceId.value, dimension: selectedDim.value, x, z }
                    });
                    if (isDisposed) return;
                    const raw = res.data?.biome || '';
                    const key = raw.replace('minecraft:', '');
                    const lang = store.lang === 'zh' ? 'zh' : 'en';
                    currentBiome.value = BIOME_NAMES[key]?.[lang] || key.replace(/_/g, ' ');
                } catch {
                    if (!isDisposed) currentBiome.value = '';
                }
            }, 350);
        };

        // 区块高亮与单区块重建
        const updateChunkHighlight = (x, z) => {
            if (!map) return;
            const cx = Math.floor(x / 16) * 16;
            const cz = Math.floor(z / 16) * 16;
            const bounds = [[-(cz + 16), cx], [-cz, cx + 16]];
            if (chunkHighlightRect) {
                chunkHighlightRect.setBounds(bounds);
            } else {
                chunkHighlightRect = L.rectangle(bounds, {
                    color: '#10b981', weight: 2, fill: true,
                    fillColor: '#10b981', fillOpacity: 0.15, dashArray: '6,4'
                }).addTo(map);
            }
        };

        const removeChunkHighlight = () => {
            if (chunkHighlightRect) {
                map?.removeLayer(chunkHighlightRect);
                chunkHighlightRect = null;
            }
        };

        const rebuildCurrentChunk = async () => {
            const { x, z } = mapClickMenu.value.coords;
            const chunkX = Math.floor(x / 16);
            const chunkZ = Math.floor(z / 16);
            rendering.value = true;
            try {
                await api.get('/api/plugins/mc-panel-plugin-map/chunk-render', {
                    params: { instanceId: instanceId.value, dimension: selectedDim.value, chunkX, chunkZ }
                });
                const regionX = Math.floor(chunkX / 32);
                const regionZ = Math.floor(chunkZ / 32);
                const regionFile = `r.${regionX}.${regionZ}.mca`;
                if (overlays[regionFile]) {
                    map.removeLayer(overlays[regionFile]);
                    delete overlays[regionFile];
                }
                await drawMapOverlays(true);
                showToast(store.lang === 'zh' ? `区块 (${chunkX}, ${chunkZ}) 重建完成` : `Chunk (${chunkX}, ${chunkZ}) rebuilt`);
            } catch (e) {
                showToast(store.lang === 'zh' ? '区块重建失败' : 'Chunk rebuild failed', 'error');
            } finally {
                rendering.value = false;
            }
            hideMapClickMenu();
            removeChunkHighlight();
        };

        // 更新玩家标记雷达
        const updatePlayerMarkers = () => {
            if (!map) return;
            const activeUUIDs = [];
            for (const p of players.value) {
                if (!isOnline(p.name) || p.dimension !== selectedDim.value) {
                    if (playerMarkers[p.uuid]) {
                        map.removeLayer(playerMarkers[p.uuid]);
                        delete playerMarkers[p.uuid];
                    }
                    continue;
                }
                activeUUIDs.push(p.uuid);
                const latlng = [-p.z, p.x];
                const online = isOnline(p.name);
                const borderColor = online ? '#10b981' : '#6c757d';

                const cleanName = encodeURIComponent(p.name);

                if (playerMarkers[p.uuid]) {
                    playerMarkers[p.uuid].setLatLng(latlng);
                    const el = playerMarkers[p.uuid].getElement();
                    if (el) {
                        const yBadge = el.querySelector('.marker-label .badge');
                        if (yBadge) yBadge.textContent = `Y:${Math.round(p.y)}`;
                        const img = el.querySelector('.player-avatar-img');
                        if (img) {
                            img.style.borderColor = borderColor;
                            const targetSrc = `/api/avatar?player=${cleanName}&size=28`;
                            if (!img.src.includes(`/api/avatar?player=${cleanName}`) && !img.dataset.f1 && !img.dataset.f2 && !img.dataset.f3 && !img.dataset.f4 && !img.dataset.f5) {
                                img.src = targetSrc;
                            }
                        }
                        const pulse = el.querySelector('.pulse-ring');
                        if (pulse) {
                            pulse.style.display = online ? 'block' : 'none';
                            pulse.style.borderColor = borderColor;
                        }
                    }
                } else {
                    const playerIcon = L.divIcon({
                        className: 'leaflet-player-marker',
                        html: `
                            <div class="player-marker-wrapper">
                                <span class="pulse-ring" style="display:${online ? 'block' : 'none'};border-color:${borderColor};"></span>
                                <img src="/api/avatar?player=${cleanName}&size=28"
                                     class="player-avatar-img"
                                     alt="${p.name}"
                                     style="width:28px;height:28px;image-rendering:pixelated;border-radius:50%;border:2px solid ${borderColor};box-shadow:0 2px 8px rgba(0,0,0,0.6);background:#1a1a2e;position:relative;z-index:2;cursor:pointer;object-fit:cover;"
                                     onerror="if(!this.dataset.f1){this.dataset.f1='1';this.src='https://crafthead.net/avatar/${cleanName}/28';}else if(!this.dataset.f2){this.dataset.f2='1';this.src='https://littleskin.cn/avatar/player/${cleanName}?size=28';}else if(!this.dataset.f3){this.dataset.f3='1';this.src='https://skinsystem.ely.by/avatars/${cleanName}.png';}else if(!this.dataset.f4){this.dataset.f4='1';this.src='https://minotar.net/helm/${cleanName}/28';}else if(!this.dataset.f5){this.dataset.f5='1';this.src='https://mc-heads.net/avatar/${cleanName}/28';}else{this.style.display='none';this.nextElementSibling.style.display='flex';}">
                                <div class="marker-dot-fallback" style="display:none;width:28px;height:28px;border-radius:50%;border:2px solid ${borderColor};background:${online ? '#10b981' : '#6c757d'};align-items:center;justify-content:center;color:#fff;font-size:11px;font-weight:bold;box-shadow:0 2px 8px rgba(0,0,0,0.6);position:relative;z-index:2;cursor:pointer;">
                                    ${p.name[0].toUpperCase()}
                                </div>
                                <div class="marker-label">
                                    ${p.name} <span class="badge bg-black text-emerald" style="font-size:8px;">Y:${Math.round(p.y)}</span>
                                </div>
                            </div>
                        `,
                        iconSize: [32, 32],
                        iconAnchor: [16, 16]
                    });

                    const marker = L.marker(latlng, { icon: playerIcon }).addTo(map);
                    marker.on('click', (e) => {
                        L.DomEvent.stopPropagation(e);
                        hideMapClickMenu();
                        if (clickMarker) { map.removeLayer(clickMarker); clickMarker = null; }
                        const clickIcon = L.divIcon({
                            className: 'leaflet-click-marker',
                            html: `<div style="width:16px;height:16px;border:2px solid #fff;border-radius:50%;background:rgba(16,185,129,0.85);box-shadow:0 0 10px rgba(16,185,129,0.7);"></div>`,
                            iconSize: [16, 16], iconAnchor: [8, 8]
                        });
                        const currentP = players.value.find(item => item.uuid === p.uuid) || p;
                        clickMarker = L.marker([-currentP.z, currentP.x], { icon: clickIcon, interactive: false }).addTo(map);
                        mapClickMenu.value = {
                            visible: true,
                            x: e.originalEvent.clientX,
                            y: e.originalEvent.clientY,
                            coords: { x: Math.round(currentP.x), z: Math.round(currentP.z), surfaceY: Math.round(currentP.y) }
                        };
                    });
                    playerMarkers[p.uuid] = marker;
                }
            }

            for (const uuid of Object.keys(playerMarkers)) {
                if (!activeUUIDs.includes(uuid)) {
                    map.removeLayer(playerMarkers[uuid]);
                    delete playerMarkers[uuid];
                }
            }
        };

        const fetchPlayers = async () => {
            if (isDisposed || store.view !== 'server-map-view') return;
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-map/players', {
                    params: { instanceId: instanceId.value }
                });
                if (isDisposed || store.view !== 'server-map-view') return;
                const raw = Array.isArray(res.data) ? res.data : [];
                const onlineFromMap = raw.filter(p => p.online).map(p => p.name);
                if (onlineFromMap.length > 0 && (!store.onlinePlayers || store.onlinePlayers.length === 0)) {
                    store.onlinePlayers = onlineFromMap;
                }
                players.value = raw.map(p => ({
                    ...p,
                    online: p.online !== undefined ? Boolean(p.online) : isOnline(p.name),
                    coordsText: `X:${Math.round(p.x)} Y:${Math.round(p.y)} Z:${Math.round(p.z)}`,
                    hasHealth: p.health !== null && p.health !== undefined,
                    healthDisplay: p.health !== null && p.health !== undefined ? Math.round(p.health * 10) / 10 : 0,
                    healthPercent: p.health !== null && p.health !== undefined ? Math.min(Math.max((p.health / 20) * 100, 0), 100) : 0,
                    hasFood: p.foodLevel !== null && p.foodLevel !== undefined,
                    foodDisplay: p.foodLevel ?? 0,
                    foodPercent: p.foodLevel !== null && p.foodLevel !== undefined ? Math.min(Math.max((p.foodLevel / 20) * 100, 0), 100) : 0
                }));
                updatePlayerMarkers();
            } catch (e) {}
        };

        const panToPlayer = (player) => {
            if (!map || !player) return;
            if (player.dimension && selectedDim.value !== player.dimension) {
                selectedDim.value = player.dimension;
            }
            setTimeout(() => { map.setView([-player.z, player.x], 1); }, 150);
        };

        const resetView = () => {
            if (!map) return;
            // 仅定位处于当前选中维度的玩家，绝不强行重置 selectedDim
            const pInDim = players.value.find(p => p.dimension === selectedDim.value);
            if (pInDim) {
                map.setView([-pInDim.z, pInDim.x], 1);
            } else if (regions.value.length) {
                const r = regions.value[0];
                map.setView([-(r.z * 512 + 256), r.x * 512 + 256], -1);
            } else {
                map.setView([0, 0], -1);
            }
        };

        const forceRebuild = () => { drawMapOverlays(true); };

        const isOnline = (name) => store.onlinePlayers?.includes(name);

        const getDimName = (dim) => {
            if (dim === 'minecraft:the_nether') return store.lang === 'zh' ? '下界' : 'Nether';
            if (dim === 'minecraft:the_end') return store.lang === 'zh' ? '末地' : 'The End';
            return store.lang === 'zh' ? '主世界' : 'Overworld';
        };

        const getDimBadgeClass = (dim) => {
            if (dim === 'minecraft:the_nether') return 'bg-danger';
            if (dim === 'minecraft:the_end') return 'bg-purple';
            return 'bg-success';
        };

        const sendCmd = async (c) => {
            if (!store.isRunning) {
                showToast(store.lang === 'zh' ? '服务器未在运行中' : 'Server offline', 'warning');
                return;
            }
            await api.post('/api/server/command', { command: c });
            showToast(store.lang === 'zh' ? '命令已执行' : 'Command executed');
            hidePlayerMenu();
        };

        const sendCmdToPlayer = (player, cmd) => {
            hidePlayerMenu();
            sendCmd(`${cmd} ${player.name}`);
        };

        const askTeleport = (player) => {
            hidePlayerMenu();
            const dim = selectedDim.value || 'minecraft:overworld';
            const dimName = getDimName(dim);
            openModal({
                title: `${store.lang === 'zh' ? '传送' : 'Teleport'} ${player.name} (${dimName})`,
                message: store.lang === 'zh' ? `传送目标坐标 (X Y Z) 或目标玩家名 (当前维度: ${dimName}):` : `Target coords (X Y Z) or Player (Dimension: ${dimName}):`,
                mode: 'input', inputValue: '~ ~ ~',
                callback: (val) => {
                    const trimmed = (val || '').trim();
                    const isCoords = /^-?\d+(\.\d+)?\s+-?\d+(\.\d+)?\s+-?\d+(\.\d+)?$/.test(trimmed);
                    if (isCoords && dim) {
                        sendCmd(`execute in ${dim} run tp ${player.name} ${trimmed}`);
                    } else {
                        sendCmd(`tp ${player.name} ${trimmed}`);
                    }
                }
            });
        };

        const askGamemode = (player) => {
            hidePlayerMenu();
            openModal({
                title: `${store.lang === 'zh' ? '切换游戏模式' : 'Gamemode'} ${player.name}`,
                message: store.lang === 'zh' ? '请选择游戏模式:' : 'Choose mode:',
                mode: 'select', inputValue: 'survival',
                options: [
                    { label: 'Survival (生存)', value: 'survival' },
                    { label: 'Creative (创造)', value: 'creative' },
                    { label: 'Adventure (冒险)', value: 'adventure' },
                    { label: 'Spectator (旁观)', value: 'spectator' }
                ],
                callback: (val) => sendCmd(`gamemode ${val} ${player.name}`)
            });
        };

        const askGiveItem = (player) => {
            hidePlayerMenu();
            openModal({
                title: `${store.lang === 'zh' ? '给予物品' : 'Give Item'} -> ${player.name}`,
                message: store.lang === 'zh' ? '物品ID与数量 (例如: diamond 64 或 netherite_sword):' : 'Item ID and count (e.g. diamond 64):',
                mode: 'input', inputValue: 'diamond 64',
                callback: (val) => {
                    const parts = (val || '').trim().split(/\s+/);
                    if (!parts[0]) return;
                    const item = parts[0];
                    const count = parts[1] || '1';
                    sendCmd(`give ${player.name} ${item} ${count}`);
                }
            });
        };

        const askBan = (player) => {
            hidePlayerMenu();
            openModal({
                title: `${store.lang === 'zh' ? '封禁玩家' : 'Ban Player'} ${player.name}`,
                message: store.lang === 'zh' ? '封禁原因 (可选):' : 'Reason (optional):',
                mode: 'input', inputValue: '',
                callback: (val) => sendCmd(`ban ${player.name}${val ? ' ' + val : ''}`)
            });
        };

        // 监听器
        watch(selectedDim, () => {
            drawMapOverlays().then(() => resetView());
        });

        watch(isFullscreen, () => {
            nextTick(() => { if (map) map.invalidateSize(); });
        });

        // 生命周期
        onMounted(() => {
            styleEl = document.createElement('style');
            styleEl.id = 'map-plugin-leaflet-styles';
            styleEl.textContent = `
                #leaflet-map { cursor: crosshair; }
                .leaflet-player-marker { background: transparent; border: none; }
                .player-marker-wrapper {
                    position: relative;
                    width: 32px; height: 32px;
                    display: flex; align-items: center; justify-content: center;
                }
                .player-marker-wrapper .pulse-ring {
                    position: absolute; top: 50%; left: 50%;
                    transform: translate(-50%, -50%);
                    width: 36px; height: 36px; border-radius: 50%;
                    border: 2px solid #10b981;
                    opacity: 0.5;
                    animation: radar-pulse 1.8s infinite ease-out;
                    pointer-events: none;
                }
                .player-marker-wrapper .marker-label {
                    position: absolute; top: 100%; left: 50%;
                    transform: translateX(-50%) translateY(4px);
                    background: rgba(0,0,0,0.9);
                    border: 1px solid rgba(255,255,255,0.15);
                    color: #fff; font-size: 10px; padding: 2px 6px;
                    border-radius: 4px; pointer-events: none;
                    opacity: 0; transition: opacity 0.2s;
                    white-space: nowrap; box-shadow: 0 4px 6px rgba(0,0,0,0.4);
                    z-index: 100;
                }
                .player-marker-wrapper:hover .marker-label { opacity: 1; }
                .hover-bg-dark:hover { background-color: rgba(255,255,255,0.04) !important; }
                @keyframes radar-pulse {
                    0% { transform: translate(-50%, -50%) scale(0.4); opacity: 0.9; }
                    100% { transform: translate(-50%, -50%) scale(1.6); opacity: 0; }
                }
                .leaflet-container img.leaflet-image-layer {
                    image-rendering: pixelated !important;
                    image-rendering: -moz-crisp-edges !important;
                    image-rendering: crisp-edges !important;
                }
                .leaflet-tile {
                    image-rendering: pixelated !important;
                    image-rendering: -moz-crisp-edges !important;
                    image-rendering: crisp-edges !important;
                }
                #leaflet-map .leaflet-top,
                #leaflet-map .leaflet-bottom,
                #leaflet-map .leaflet-control-container {
                    z-index: 400 !important;
                }
                .map-fullscreen-root { position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 9998; background: #0b0f19; padding: 0; margin: 0; }
                .map-fullscreen-card { width: 100%; height: 100vh; position: relative; overflow: hidden; background: #0b0f19; }
                .bg-purple { background-color: #a855f7 !important; }
                .text-emerald { color: #10b981 !important; }
                .bg-emerald { background-color: #10b981 !important; }
                .bg-emerald-soft { background-color: rgba(16, 185, 129, 0.15) !important; color: #10b981 !important; border: 1px solid rgba(16, 185, 129, 0.25); }
                .btn-outline-emerald { color: #10b981; border-color: rgba(16, 185, 129, 0.4); }
                .btn-outline-emerald:hover { color: #fff; background-color: #10b981; border-color: #10b981; }
            `;
            document.head.appendChild(styleEl);

            // 心跳与追踪启动
            api.post('/api/plugins/mc-panel-plugin-map/heartbeat').catch(() => {});
            heartbeatInterval = setInterval(() => {
                api.post('/api/plugins/mc-panel-plugin-map/heartbeat').catch(() => {});
            }, 5000);

            docClickHandler = (e) => {
                const menuEl = e.target.closest('.dropdown-menu');
                if (playerMenu.value.visible && !menuEl) hidePlayerMenu();
                if (mapClickMenu.value.visible && !menuEl) hideMapClickMenu();
            };
            document.addEventListener('click', docClickHandler, true);

            loadLeaflet().then(() => {
                if (isDisposed) return;
                initMap();
                drawMapOverlays().then(() => { if (!isDisposed) resetView(); });
                fetchPlayers();
                if (!isDisposed) {
                    refreshInterval = setInterval(fetchPlayers, 4000);
                }
            });
        });

        onUnmounted(() => {
            isDisposed = true;
            if (heartbeatInterval) { clearInterval(heartbeatInterval); heartbeatInterval = null; }
            if (refreshInterval) { clearInterval(refreshInterval); refreshInterval = null; }
            if (biomeTimer) clearTimeout(biomeTimer);
            api.post('/api/plugins/mc-panel-plugin-map/stop-tracking').catch(() => {});
            if (docClickHandler) document.removeEventListener('click', docClickHandler, true);
            if (styleEl && styleEl.parentNode) styleEl.parentNode.removeChild(styleEl);
            removeChunkHighlight();
            if (map) {
                try {
                    map.off();
                    for (const uuid in playerMarkers) {
                        try { map.removeLayer(playerMarkers[uuid]); } catch (e) {}
                    }
                    playerMarkers = {};
                    for (const f in overlays) {
                        try { map.removeLayer(overlays[f]); } catch (e) {}
                    }
                    overlays = {};
                } catch (e) {}
                map = null;
            }
        });

        return {
            store, selectedDim, regions, players, rendering, autoRefresh, mouseCoords, dimensionsList,
            currentDimMaxY, heightOptions,
            forceRebuild, panToPlayer, resetView, isOnline, getDimName, getDimBadgeClass,
            currentBiome, isFullscreen, radarCollapsed,
            playerMenu, showPlayerMenuFn, hidePlayerMenu, sendCmdToPlayer,
            mapClickMenu, hideMapClickMenu, openShareLocationModal, openTeleportModal,
            hoveredRebuildChunk, rebuildCurrentChunk, updateChunkHighlight, removeChunkHighlight,
            showShareModal, shareMessage, shareCoords, onlinePlayersList, closeShareModal, confirmShareLocation,
            showTeleportModal, teleportTarget, teleportCoords, closeTeleportModal, confirmTeleport,
            sendCmd, askTeleport, askGamemode, askGiveItem, askBan
        };
    }
};
