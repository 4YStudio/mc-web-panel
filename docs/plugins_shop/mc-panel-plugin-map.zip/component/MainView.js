import { ref, computed, onMounted, onUnmounted, watch, nextTick } from '/js/vue.esm-browser.js';
import { store } from '/js/store.js';
import { api } from '/js/api.js';
import { showToast, openModal } from '/js/utils.js';
import Avatar from '/js/components/Avatar.js';

// ==================== Data Constants (from PlayerManager) ====================
const LEGACY_ITEMS = {
    'minecraft:stone_bricks': { id: 'minecraft:stonebrick', data: 0 },
    'minecraft:mossy_stone_bricks': { id: 'minecraft:stonebrick', data: 1 },
    'minecraft:cracked_stone_bricks': { id: 'minecraft:stonebrick', data: 2 },
    'minecraft:chiseled_stone_bricks': { id: 'minecraft:stonebrick', data: 3 },
    'minecraft:cobweb': { id: 'minecraft:web', data: 0 },
    'minecraft:red_bed': { id: 'minecraft:bed', data: 14 },
    'minecraft:oak_button': { id: 'minecraft:wooden_button', data: 0 },
    'minecraft:melon': { id: 'minecraft:melon_block', data: 0 },
    'minecraft:oak_pressure_plate': { id: 'minecraft:wooden_pressure_plate', data: 0 },
    'minecraft:skeleton_skull': { id: 'minecraft:skull', data: 0 },
    'minecraft:wither_skeleton_skull': { id: 'minecraft:skull', data: 1 },
    'minecraft:zombie_head': { id: 'minecraft:skull', data: 2 },
    'minecraft:player_head': { id: 'minecraft:skull', data: 3 },
    'minecraft:creeper_head': { id: 'minecraft:skull', data: 4 },
    'minecraft:dragon_head': { id: 'minecraft:skull', data: 5 },
    'minecraft:oak_door': { id: 'minecraft:wooden_door', data: 0 },
    'minecraft:oak_trapdoor': { id: 'minecraft:trapdoor', data: 0 },
    'minecraft:cod': { id: 'minecraft:fish', data: 0 },
    'minecraft:salmon': { id: 'minecraft:fish', data: 1 },
    'minecraft:pufferfish': { id: 'minecraft:fish', data: 2 },
    'minecraft:tropical_fish': { id: 'minecraft:fish', data: 3 },
    'minecraft:cooked_cod': { id: 'minecraft:cooked_fish', data: 0 },
    'minecraft:cooked_salmon': { id: 'minecraft:cooked_fish', data: 1 },
    'minecraft:ink_sac': { id: 'minecraft:dye', data: 0 },
    'minecraft:red_dye': { id: 'minecraft:dye', data: 1 },
    'minecraft:green_dye': { id: 'minecraft:dye', data: 2 },
    'minecraft:cocoa_beans': { id: 'minecraft:dye', data: 3 },
    'minecraft:lapis_lazuli': { id: 'minecraft:dye', data: 4 },
    'minecraft:purple_dye': { id: 'minecraft:dye', data: 5 },
    'minecraft:cyan_dye': { id: 'minecraft:dye', data: 6 },
    'minecraft:light_gray_dye': { id: 'minecraft:dye', data: 7 },
    'minecraft:gray_dye': { id: 'minecraft:dye', data: 8 },
    'minecraft:pink_dye': { id: 'minecraft:dye', data: 9 },
    'minecraft:lime_dye': { id: 'minecraft:dye', data: 10 },
    'minecraft:yellow_dye': { id: 'minecraft:dye', data: 11 },
    'minecraft:light_blue_dye': { id: 'minecraft:dye', data: 12 },
    'minecraft:magenta_dye': { id: 'minecraft:dye', data: 13 },
    'minecraft:orange_dye': { id: 'minecraft:dye', data: 14 },
    'minecraft:bone_meal': { id: 'minecraft:dye', data: 15 }
};

const UNGIVEABLE_IDS = new Set([
    'minecraft:air', 'minecraft:cave_air', 'minecraft:void_air',
    'minecraft:water', 'minecraft:lava', 'minecraft:nether_portal',
    'minecraft:portal', 'minecraft:end_portal', 'minecraft:end_gateway',
    'minecraft:fire', 'minecraft:soul_fire', 'minecraft:moving_piston',
    'minecraft:frosted_ice', 'minecraft:bubble_column'
]);

const ENCHANTMENTS = [
    { id: 'minecraft:protection', namecn: '保护', nameen: 'Protection', maxLvl: 4 },
    { id: 'minecraft:fire_protection', namecn: '火焰保护', nameen: 'Fire Protection', maxLvl: 4 },
    { id: 'minecraft:feather_falling', namecn: '摔落保护', nameen: 'Feather Falling', maxLvl: 4 },
    { id: 'minecraft:blast_protection', namecn: '爆炸保护', nameen: 'Blast Protection', maxLvl: 4 },
    { id: 'minecraft:projectile_protection', namecn: '弹射物保护', nameen: 'Projectile Protection', maxLvl: 4 },
    { id: 'minecraft:respiration', namecn: '水下呼吸', nameen: 'Respiration', maxLvl: 3 },
    { id: 'minecraft:aqua_affinity', namecn: '水下速掘', nameen: 'Aqua Affinity', maxLvl: 1 },
    { id: 'minecraft:thorns', namecn: '荆棘', nameen: 'Thorns', maxLvl: 3 },
    { id: 'minecraft:depth_strider', namecn: '深海探索者', nameen: 'Depth Strider', maxLvl: 3 },
    { id: 'minecraft:frost_walker', namecn: '冰霜行者', nameen: 'Frost Walker', maxLvl: 2 },
    { id: 'minecraft:binding_curse', namecn: '绑定诅咒', nameen: 'Binding Curse', maxLvl: 1 },
    { id: 'minecraft:sharpness', namecn: '锋利', nameen: 'Sharpness', maxLvl: 5 },
    { id: 'minecraft:smite', namecn: '亡灵杀手', nameen: 'Smite', maxLvl: 5 },
    { id: 'minecraft:bane_of_arthropods', namecn: '节肢杀手', nameen: 'Bane of Arthropods', maxLvl: 5 },
    { id: 'minecraft:knockback', namecn: '击退', nameen: 'Knockback', maxLvl: 2 },
    { id: 'minecraft:fire_aspect', namecn: '火焰附加', nameen: 'Fire Aspect', maxLvl: 2 },
    { id: 'minecraft:looting', namecn: '抢夺', nameen: 'Looting', maxLvl: 3 },
    { id: 'minecraft:sweeping', namecn: '横扫之刃', nameen: 'Sweeping Edge', maxLvl: 3 },
    { id: 'minecraft:efficiency', namecn: '效率', nameen: 'Efficiency', maxLvl: 5 },
    { id: 'minecraft:silk_touch', namecn: '精准采集', nameen: 'Silk Touch', maxLvl: 1 },
    { id: 'minecraft:unbreaking', namecn: '耐久', nameen: 'Unbreaking', maxLvl: 3 },
    { id: 'minecraft:fortune', namecn: '时运', nameen: 'Fortune', maxLvl: 3 },
    { id: 'minecraft:power', namecn: '力量', nameen: 'Power', maxLvl: 5 },
    { id: 'minecraft:punch', namecn: '冲击', nameen: 'Punch', maxLvl: 2 },
    { id: 'minecraft:flame', namecn: '火矢', nameen: 'Flame', maxLvl: 1 },
    { id: 'minecraft:infinity', namecn: '无限', nameen: 'Infinity', maxLvl: 1 },
    { id: 'minecraft:luck_of_the_sea', namecn: '海之眷顾', nameen: 'Luck of the Sea', maxLvl: 3 },
    { id: 'minecraft:lure', namecn: '饵钓', nameen: 'Lure', maxLvl: 3 },
    { id: 'minecraft:mending', namecn: '经验修补', nameen: 'Mending', maxLvl: 1 },
    { id: 'minecraft:vanishing_curse', namecn: '消失诅咒', nameen: 'Vanishing Curse', maxLvl: 1 }
];

const POTION_EFFECTS = [
    { id: 'healing', namecn: '治疗', nameen: 'Healing', variants: [
        { id: 'minecraft:healing', namecn: '治疗药水 I', nameen: 'Healing I' },
        { id: 'minecraft:strong_healing', namecn: '治疗药水 II', nameen: 'Healing II' }
    ]},
    { id: 'harming', namecn: '伤害', nameen: 'Harming', variants: [
        { id: 'minecraft:harming', namecn: '伤害药水 I', nameen: 'Harming I' },
        { id: 'minecraft:strong_harming', namecn: '伤害药水 II', nameen: 'Harming II' }
    ]},
    { id: 'swiftness', namecn: '迅捷', nameen: 'Swiftness', variants: [
        { id: 'minecraft:swiftness', namecn: '迅捷药水 I (3:00)', nameen: 'Swiftness I' },
        { id: 'minecraft:long_swiftness', namecn: '迅捷药水 I (延长)', nameen: 'Swiftness I (Extended)' },
        { id: 'minecraft:strong_swiftness', namecn: '迅捷药水 II (1:30)', nameen: 'Swiftness II' }
    ]},
    { id: 'slowness', namecn: '缓慢', nameen: 'Slowness', variants: [
        { id: 'minecraft:slowness', namecn: '缓慢药水 I', nameen: 'Slowness I' },
        { id: 'minecraft:long_slowness', namecn: '缓慢药水 I (延长)', nameen: 'Slowness I (Extended)' }
    ]},
    { id: 'strength', namecn: '力量', nameen: 'Strength', variants: [
        { id: 'minecraft:strength', namecn: '力量药水 I', nameen: 'Strength I' },
        { id: 'minecraft:long_strength', namecn: '力量药水 I (延长)', nameen: 'Strength I (Extended)' },
        { id: 'minecraft:strong_strength', namecn: '力量药水 II', nameen: 'Strength II' }
    ]},
    { id: 'regeneration', namecn: '再生', nameen: 'Regeneration', variants: [
        { id: 'minecraft:regeneration', namecn: '再生药水 I', nameen: 'Regeneration I' },
        { id: 'minecraft:long_regeneration', namecn: '再生药水 I (延长)', nameen: 'Regeneration I (Extended)' },
        { id: 'minecraft:strong_regeneration', namecn: '再生药水 II', nameen: 'Regeneration II' }
    ]},
    { id: 'poison', namecn: '剧毒', nameen: 'Poison', variants: [
        { id: 'minecraft:poison', namecn: '剧毒药水 I', nameen: 'Poison I' },
        { id: 'minecraft:long_poison', namecn: '剧毒药水 I (延长)', nameen: 'Poison I (Extended)' },
        { id: 'minecraft:strong_poison', namecn: '剧毒药水 II', nameen: 'Poison II' }
    ]},
    { id: 'fire_resistance', namecn: '抗火', nameen: 'Fire Resistance', variants: [
        { id: 'minecraft:fire_resistance', namecn: '抗火药水', nameen: 'Fire Resistance' },
        { id: 'minecraft:long_fire_resistance', namecn: '抗火药水 (延长)', nameen: 'Fire Resistance (Extended)' }
    ]},
    { id: 'night_vision', namecn: '夜视', nameen: 'Night Vision', variants: [
        { id: 'minecraft:night_vision', namecn: '夜视药水', nameen: 'Night Vision' },
        { id: 'minecraft:long_night_vision', namecn: '夜视药水 (延长)', nameen: 'Night Vision (Extended)' }
    ]},
    { id: 'invisibility', namecn: '隐形', nameen: 'Invisibility', variants: [
        { id: 'minecraft:invisibility', namecn: '隐形药水', nameen: 'Invisibility' },
        { id: 'minecraft:long_invisibility', namecn: '隐形药水 (延长)', nameen: 'Invisibility (Extended)' }
    ]},
    { id: 'water_breathing', namecn: '水下呼吸', nameen: 'Water Breathing', variants: [
        { id: 'minecraft:water_breathing', namecn: '水下呼吸药水', nameen: 'Water Breathing' },
        { id: 'minecraft:long_water_breathing', namecn: '水下呼吸药水 (延长)', nameen: 'Water Breathing (Extended)' }
    ]},
    { id: 'weakness', namecn: '虚弱', nameen: 'Weakness', variants: [
        { id: 'minecraft:weakness', namecn: '虚弱药水', nameen: 'Weakness' },
        { id: 'minecraft:long_weakness', namecn: '虚弱药水 (延长)', nameen: 'Weakness (Extended)' }
    ]},
    { id: 'slow_falling', namecn: '缓降', nameen: 'Slow Falling', variants: [
        { id: 'minecraft:slow_falling', namecn: '缓降药水', nameen: 'Slow Falling' },
        { id: 'minecraft:long_slow_falling', namecn: '缓降药水 (延长)', nameen: 'Slow Falling (Extended)' }
    ]},
    { id: 'water', namecn: '基础', nameen: 'Base', variants: [
        { id: 'minecraft:water', namecn: '普通水瓶', nameen: 'Water Bottle' },
        { id: 'minecraft:awkward', namecn: '粗制药水', nameen: 'Awkward Potion' }
    ]}
];

const STATUS_EFFECTS = [
    { id: 'minecraft:speed', namecn: '速度', nameen: 'Speed' },
    { id: 'minecraft:slowness', namecn: '缓慢', nameen: 'Slowness' },
    { id: 'minecraft:haste', namecn: '急迫', nameen: 'Haste' },
    { id: 'minecraft:mining_fatigue', namecn: '挖掘疲劳', nameen: 'Mining Fatigue' },
    { id: 'minecraft:strength', namecn: '力量', nameen: 'Strength' },
    { id: 'minecraft:instant_health', namecn: '瞬间治疗', nameen: 'Instant Health' },
    { id: 'minecraft:instant_damage', namecn: '瞬间伤害', nameen: 'Instant Damage' },
    { id: 'minecraft:jump_boost', namecn: '跳跃提升', nameen: 'Jump Boost' },
    { id: 'minecraft:regeneration', namecn: '生命恢复', nameen: 'Regeneration' },
    { id: 'minecraft:resistance', namecn: '抗性提升', nameen: 'Resistance' },
    { id: 'minecraft:fire_resistance', namecn: '抗火', nameen: 'Fire Resistance' },
    { id: 'minecraft:water_breathing', namecn: '水下呼吸', nameen: 'Water Breathing' },
    { id: 'minecraft:invisibility', namecn: '隐形', nameen: 'Invisibility' },
    { id: 'minecraft:night_vision', namecn: '夜视', nameen: 'Night Vision' },
    { id: 'minecraft:weakness', namecn: '虚弱', nameen: 'Weakness' },
    { id: 'minecraft:poison', namecn: '中毒', nameen: 'Poison' },
    { id: 'minecraft:wither', namecn: '凋零', nameen: 'Wither' },
    { id: 'minecraft:health_boost', namecn: '生命值提升', nameen: 'Health Boost' },
    { id: 'minecraft:absorption', namecn: '伤害吸收', nameen: 'Absorption' },
    { id: 'minecraft:saturation', namecn: '饱和', nameen: 'Saturation' },
    { id: 'minecraft:glowing', namecn: '发光', nameen: 'Glowing' },
    { id: 'minecraft:levitation', namecn: '飘浮', nameen: 'Levitation' },
    { id: 'minecraft:slow_falling', namecn: '缓降', nameen: 'Slow Falling' },
    { id: 'minecraft:darkness', namecn: '黑暗', nameen: 'Darkness' }
];

const TABS = [
    { id: 'building_blocks', namecn: '建筑', nameen: 'Building', icon: '🧱' },
    { id: 'decorations', namecn: '装饰', nameen: 'Decoration', icon: '🌸' },
    { id: 'redstone', namecn: '红石', nameen: 'Redstone', icon: '⚡' },
    { id: 'transportation', namecn: '交通运输', nameen: 'Transport', icon: '🚂' },
    { id: 'materials', namecn: '材料', nameen: 'Materials', icon: '💎' },
    { id: 'food', namecn: '食品', nameen: 'Food', icon: '🍖' },
    { id: 'tools', namecn: '工具', nameen: 'Tools', icon: '🛠️' },
    { id: 'combat', namecn: '战斗', nameen: 'Combat', icon: '⚔️' },
    { id: 'brewing', namecn: '酿造', nameen: 'Brewing', icon: '🧪' },
    { id: 'misc', namecn: '杂项', nameen: 'Misc', icon: '📦' }
];

const VALID_CATEGORIES = new Set([
    'building_blocks', 'decorations', 'redstone', 'transportation',
    'materials', 'food', 'tools', 'combat', 'brewing', 'misc'
]);

export default {
    components: { Avatar },
    template: `
    <div :class="isFullscreen ? 'map-fullscreen-root' : 'p-4 p-md-5'">
        <div :class="isFullscreen ? '' : 'container-xxl p-0'">
            <!-- 标题栏 - 全屏时隐藏 -->
            <div v-if="!isFullscreen" class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
                <div class="d-flex align-items-center">
                    <div class="p-3 rounded-4 bg-emerald text-emerald me-3" style="background: rgba(16, 185, 129, 0.1); color: #10b981;">
                        <i class="fa-solid fa-map-location-dot fa-2x"></i>
                    </div>
                    <div>
                        <h3 class="fw-black m-0 tracking-tight">{{ store.lang === 'zh' ? '服务器交互地图' : 'Server Interactive Map' }}</h3>
                        <p class="text-muted m-0 small">{{ store.lang === 'zh' ? '基于方块实时渲染的无缝拖拽缩放地图，实时追踪玩家动态' : 'Slippy map rendered from region files with live player tracking' }}</p>
                    </div>
                </div>
                
                <div class="d-flex gap-2">
                    <button class="btn btn-sm btn-outline-secondary rounded-3 px-3 py-2" @click="resetView">
                        <i class="fa-solid fa-crosshairs me-1"></i>
                        {{ store.lang === 'zh' ? '重置视图' : 'Reset View' }}
                    </button>
                    <button class="btn btn-sm btn-outline-emerald rounded-3 px-3 py-2" @click="forceRebuild" :disabled="rendering">
                        <i class="fa-solid fa-rotate me-1" :class="{'fa-spin': rendering}"></i>
                        {{ store.lang === 'zh' ? '完整重建地图' : 'Rebuild Map' }}
                    </button>
                </div>
            </div>

            <!-- 地图与玩家列表 -->
            <div :class="isFullscreen ? '' : 'row g-4'">
                <!-- 地图主视口 -->
                <div :class="isFullscreen ? '' : 'col-12 col-xl-9'">
                    <div :class="isFullscreen ? 'map-fullscreen-card' : 'card border-0 shadow-sm rounded-4 overflow-hidden position-relative'" :style="isFullscreen ? {} : {background: 'var(--c-surface-elevated)'}">
                        <!-- 悬浮维度控制器 -->
                        <div class="dimension-selector position-absolute top-0 start-0 m-3 d-flex gap-1 p-1 rounded-3 shadow-lg" style="z-index: 1000; background: rgba(15, 23, 42, 0.65); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.08);">
                            <button v-for="dim in dimensionsList" :key="dim.id"
                                    class="btn btn-sm rounded-2 border-0 px-3 py-1.5 transition-all text-white"
                                    :class="selectedDim === dim.id ? dim.activeClass : 'bg-transparent text-muted-hover'"
                                    @click="selectedDim = dim.id">
                                <i :class="dim.icon" class="me-1"></i>
                                {{ store.lang === 'zh' ? dim.zh : dim.en }}
                            </button>
                        </div>

                        <!-- 悬浮实体筛选开关 -->
                        <div class="position-absolute top-0 end-0 m-3 d-flex gap-1 p-1 rounded-3 shadow-lg" style="z-index: 1000; background: rgba(15, 23, 42, 0.65); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.08);">
                            <button v-for="cat in entityCategories" :key="cat.id"
                                    class="btn btn-sm rounded-2 border-0 px-2.5 py-1.5 transition-all"
                                    :class="entitySettings[cat.id] ? 'text-white' : 'bg-transparent text-muted-hover'"
                                    :style="entitySettings[cat.id] ? {background: cat.color} : {}"
                                    @click="toggleEntityCategory(cat.id)">
                                <i :class="cat.icon" class="me-1"></i>
                                {{ store.lang === 'zh' ? cat.zh : cat.en }}
                                <span v-if="entityCounts[cat.id]" class="badge rounded-pill ms-1" :style="{background:'rgba(255,255,255,0.2)',fontSize:'8px',padding:'0px 5px'}">{{ entityCounts[cat.id] }}</span>
                            </button>
                        </div>

                        <!-- 地图容器 -->
                        <div id="leaflet-map" :style="isFullscreen ? 'width:100%;height:100%;background:#0b0f19;' : 'width:100%;height:620px;background:#0b0f19;'"></div>

                        <!-- 渲染中 Loading 遮罩 -->
                        <div v-if="rendering" class="position-absolute start-50 top-50 translate-middle d-flex flex-column align-items-center justify-content-center p-4 rounded-4 shadow-lg" style="z-index: 1001; background: rgba(15, 23, 42, 0.85); backdrop-filter: blur(6px); border: 1px solid rgba(255,255,255,0.15);">
                            <div class="spinner-border text-emerald mb-3" role="status"></div>
                            <span class="text-white-50 small">{{ store.lang === 'zh' ? '正在解包方块状态，生成渲染图层...' : 'Parsing block states, generating map tiles...' }}</span>
                        </div>

                        <!-- 悬浮坐标 HUD + 生物群系 -->
                        <div class="coords-hud position-absolute bottom-0 start-50 translate-middle-x mb-3 px-3 py-1.5 rounded-3 shadow-lg font-monospace text-white d-flex align-items-center gap-2" style="z-index: 1000; background: rgba(15, 23, 42, 0.75); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.1); font-size: 12px; letter-spacing: 0.5px;">
                            <span class="text-muted">X:</span> <span class="text-emerald fw-bold">{{ mouseCoords.x }}</span>
                            <span class="text-white-50">|</span>
                            <span class="text-muted">Z:</span> <span class="text-emerald fw-bold">{{ mouseCoords.z }}</span>
                            <template v-if="currentBiome">
                                <span class="text-white-50">|</span>
                                <i class="fa-solid fa-leaf text-success" style="font-size:10px;"></i>
                                <span class="text-success">{{ currentBiome }}</span>
                            </template>
                        </div>

                        <!-- 悬浮全屏按钮 - 左下角 -->
                        <button class="btn btn-sm position-absolute bottom-0 start-0 m-3 rounded-3 text-white-50" style="z-index:1000; background:rgba(15,23,42,0.65); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.08);"
                                @click="isFullscreen = !isFullscreen" :title="store.lang === 'zh' ? '全屏' : 'Fullscreen'">
                            <i class="fa-solid" :class="isFullscreen ? 'fa-compress' : 'fa-expand'"></i>
                        </button>

                        <!-- 全屏模式浮动操作按钮 -->
                        <template v-if="isFullscreen">
                            <button class="btn btn-sm position-absolute bottom-0 start-0 ms-5 mb-3 rounded-pill text-white-50 px-3" style="z-index:1000; background:rgba(15,23,42,0.65); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.08);"
                                    @click="resetView" :title="store.lang === 'zh' ? '重置视图' : 'Reset View'">
                                <i class="fa-solid fa-crosshairs me-1"></i>{{ store.lang === 'zh' ? '重置' : 'Reset' }}
                            </button>
                            <button class="btn btn-sm position-absolute bottom-0 start-0 ms-5 mb-3 rounded-pill text-white-50 px-3" style="z-index:1000; left:160px; background:rgba(15,23,42,0.65); backdrop-filter:blur(8px); border:1px solid rgba(255,255,255,0.08);"
                                    @click="forceRebuild" :disabled="rendering" :title="store.lang === 'zh' ? '完整重建地图' : 'Rebuild Map'">
                                <i class="fa-solid fa-rotate me-1" :class="{'fa-spin': rendering}"></i>{{ store.lang === 'zh' ? '重建' : 'Rebuild' }}
                            </button>
                        </template>
                    </div>
                </div>

                <!-- 玩家列表 -->
                <div v-if="!isFullscreen" class="col-12 col-xl-3">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden h-100" style="background: var(--c-surface-elevated);">
                        <div class="card-header border-bottom border-white border-opacity-10 p-3 bg-transparent d-flex align-items-center">
                            <h5 class="m-0 fw-bold d-flex align-items-center text-white-50">
                                <i class="fa-solid fa-users me-2 text-emerald opacity-75"></i>
                                {{ store.lang === 'zh' ? '玩家雷达' : 'Player Radar' }}
                                <span class="badge bg-emerald bg-opacity-10 text-emerald ms-2" style="font-size: 0.75rem;">{{ players.length }}</span>
                            </h5>
                        </div>
                        <div class="card-body p-0 overflow-auto custom-scrollbar" style="max-height: 550px;">
                            <div class="list-group list-group-flush">
                                <div v-for="p in players" :key="p.uuid"
                                     class="list-group-item bg-transparent border-white border-opacity-10 p-3 d-flex align-items-center justify-content-between hover-bg-dark transition-all"
                                     @click="panToPlayer(p)">
                                    <div class="d-flex align-items-center min-w-0 cursor-pointer">
                                        <avatar :player="p.name" :size="28" class="me-2 flex-shrink-0"></avatar>
                                        <div class="min-w-0">
                                            <div class="fw-bold d-flex align-items-center gap-1 text-white">
                                                <span class="text-truncate">{{ p.name }}</span>
                                                <span v-if="isOnline(p.name)" class="badge rounded-pill bg-success bg-opacity-25 text-success" style="font-size: 7px; padding: 1px 4px;">ON</span>
                                                <span class="badge text-white" :class="getDimBadgeClass(p.dimension)" style="font-size: 9px; opacity: 0.85;">
                                                    {{ getDimName(p.dimension) }}
                                                </span>
                                            </div>
                                            <div class="font-monospace text-muted mt-0.5" style="font-size: 0.7rem;">
                                                X:{{ Math.round(p.x) }} Y:{{ Math.round(p.y) }} Z:{{ Math.round(p.z) }}
                                            </div>
                                            <div v-if="isOnline(p.name) && (p.health !== null && p.health !== undefined)" class="d-flex gap-2 mt-1 align-items-center" style="font-size: 0.65rem;">
                                                <div class="d-flex align-items-center gap-1" :title="store.lang === 'zh' ? '生命值' : 'Health'">
                                                    <i class="fa-solid fa-heart text-danger" style="font-size: 8px;"></i>
                                                    <div class="progress" style="width: 40px; height: 4px; background: rgba(255,255,255,0.1);">
                                                        <div class="progress-bar bg-danger" :style="{width: Math.min(p.health / 20 * 100, 100) + '%'}"></div>
                                                    </div>
                                                    <span class="text-white-50">{{ Math.round(p.health * 10) / 10 }}</span>
                                                </div>
                                                <div v-if="p.foodLevel !== null && p.foodLevel !== undefined" class="d-flex align-items-center gap-1" :title="store.lang === 'zh' ? '饥饿值' : 'Hunger'">
                                                    <i class="fa-solid fa-drumstick-bite" style="font-size: 8px; color: #d97706;"></i>
                                                    <div class="progress" style="width: 40px; height: 4px; background: rgba(255,255,255,0.1);">
                                                        <div class="progress-bar" style="background: #d97706;" :style="{width: Math.min(p.foodLevel / 20 * 100, 100) + '%'}"></div>
                                                    </div>
                                                    <span class="text-white-50">{{ p.foodLevel }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="btn btn-sm btn-link p-0 text-white-50 text-decoration-none small flex-shrink-0" @click.stop="showPlayerMenuFn(p, $event)">
                                        <i class="fa-solid fa-ellipsis-vertical"></i>
                                    </button>
                                </div>
                                <div v-if="!players.length" class="text-center py-5 text-muted opacity-50 small">
                                    {{ store.lang === 'zh' ? '暂未发现任何玩家数据档案' : 'No player data profiles found yet' }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 全屏模式悬浮玩家雷达 -->
                <Teleport to="body">
                    <div v-if="isFullscreen" class="position-fixed" style="top:80px;right:16px;z-index:9999;width:280px;">
                        <div class="rounded-4 shadow-lg overflow-hidden" style="background:rgba(15,23,42,0.88);backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.1);">
                            <div class="d-flex align-items-center px-3 py-2 border-bottom" style="border-color:rgba(255,255,255,0.08)!important;">
                                <i class="fa-solid fa-users me-2 text-emerald opacity-75"></i>
                                <span class="text-white-50 small fw-bold">{{ store.lang === 'zh' ? '玩家雷达' : 'Player Radar' }}</span>
                                <span class="badge bg-emerald bg-opacity-10 text-emerald ms-2" style="font-size:0.7rem;">{{ players.length }}</span>
                                <button class="btn btn-sm btn-link p-0 ms-auto text-white-50" @click="radarCollapsed = !radarCollapsed">
                                    <i class="fa-solid" :class="radarCollapsed ? 'fa-chevron-down' : 'fa-chevron-up'" style="font-size:10px;"></i>
                                </button>
                            </div>
                            <div v-if="!radarCollapsed" class="overflow-auto custom-scrollbar" style="max-height:calc(100vh - 200px);">
                                <div class="list-group list-group-flush">
                                    <div v-for="p in players" :key="'fs-'+p.uuid"
                                         class="list-group-item bg-transparent border-white border-opacity-10 p-2 d-flex align-items-center justify-content-between hover-bg-dark transition-all"
                                         @click="panToPlayer(p)">
                                        <div class="d-flex align-items-center min-w-0 cursor-pointer">
                                            <avatar :player="p.name" :size="24" class="me-2 flex-shrink-0"></avatar>
                                            <div class="min-w-0">
                                                <div class="fw-bold d-flex align-items-center gap-1 text-white" style="font-size:0.8rem;">
                                                    <span class="text-truncate">{{ p.name }}</span>
                                                    <span v-if="isOnline(p.name)" class="badge rounded-pill bg-success bg-opacity-25 text-success" style="font-size:6px;padding:0 3px;">ON</span>
                                                </div>
                                                <div class="font-monospace text-muted" style="font-size:0.6rem;">X:{{ Math.round(p.x) }} Y:{{ Math.round(p.y) }} Z:{{ Math.round(p.z) }}</div>
                                            </div>
                                        </div>
                                        <button class="btn btn-sm btn-link p-0 text-white-50 flex-shrink-0" @click.stop="showPlayerMenuFn(p, $event)">
                                            <i class="fa-solid fa-ellipsis-vertical" style="font-size:10px;"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </Teleport>
            </div>
        </div>
    </div>

    <!-- 给予物品弹窗 -->
    <Teleport to="body">
        <Transition name="modal-fade">
            <div class="modal fade show" v-if="showGiveModal" style="display: block; z-index: 1050;">
                <div class="modal-backdrop fade show" @click="closeGiveModal" style="z-index: -1;"></div>
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content border-0 shadow-lg" style="border-radius: 16px; overflow: hidden;">
                        <div class="modal-header border-bottom pb-3 pt-3 px-4 d-flex justify-content-between align-items-center">
                            <h5 class="modal-title fw-bold text-body">
                                <i class="fa-solid fa-gift me-2 text-primary"></i>
                                <span>{{ store.lang === 'zh' ? '给予物品' : 'Give Item' }}: {{ targetPlayer }}</span>
                            </h5>
                            <button type="button" class="btn-close" @click="closeGiveModal"></button>
                        </div>
                        <div class="modal-body px-4 py-3">
                            <div class="mb-3">
                                <div class="position-relative">
                                    <i class="fa-solid fa-magnifying-glass position-absolute text-muted" style="left: 14px; top: 50%; transform: translateY(-50%); z-index: 10;"></i>
                                    <input type="text" class="form-control ps-5 py-2 rounded-pill" :placeholder="store.lang === 'zh' ? '搜索物品...' : 'Search items...'" v-model="itemSearchQuery">
                                </div>
                            </div>
                            <div class="mc-tabs-container mb-3">
                                <div class="mc-tabs d-flex gap-2 overflow-auto py-1">
                                    <button v-for="tab in tabs" :key="tab.id" class="mc-tab-btn flex-shrink-0" :class="{active: activeTab === tab.id}" @click="activeTab = tab.id; itemSearchQuery=''">
                                        {{ tab.icon }} <span class="ms-1">{{ store.lang === 'zh' ? tab.namecn : tab.nameen }}</span>
                                    </button>
                                </div>
                            </div>

                            <div class="mc-slots-container mb-3">
                                <div class="mc-slots-grid">
                                    <div v-for="item in filteredItems" :key="item.no"
                                         class="mc-item-slot"
                                         :class="{active: selectedItem && selectedItem.id === item.id}"
                                         @click="selectItem(item)">
                                        <img :src="'/img/items/' + item.no + '.png'" class="mc-item-img" width="34" height="34" onerror="this.src='/img/items/0.png'">
                                        <div class="mc-item-tooltip">
                                            <div class="fw-bold">{{ store.lang === 'zh' ? item.namecn : item.nameen }}</div>
                                            <div class="small text-muted" style="font-size:0.7rem;">{{ store.lang === 'zh' ? item.nameen : item.namecn }}</div>
                                            <small class="text-primary">{{ item.id }}</small>
                                        </div>
                                    </div>
                                    <div v-for="n in emptySlotsCount" :key="'empty-'+n" class="mc-item-slot empty"></div>
                                </div>
                            </div>

                            <div v-if="selectedItem && (selectedItem.id === 'minecraft:enchanted_book' || ['minecraft:potion', 'minecraft:splash_potion', 'minecraft:lingering_potion'].includes(selectedItem.id) || isEnchantable || selectedItem.id === 'minecraft:player_head')"
                                 class="p-3 rounded-3 mb-3 border" style="background: rgba(var(--c-primary-rgb), 0.03); border-color: rgba(var(--c-primary-rgb), 0.15) !important;">
                                <div v-if="selectedItem.id === 'minecraft:player_head'" class="row g-2 align-items-center">
                                    <div class="col-12">
                                        <label class="form-label small fw-bold text-muted mb-1">{{ store.lang === 'zh' ? '皮肤拥有者' : 'Skin Owner' }}</label>
                                        <input type="text" class="form-control form-control-sm" :placeholder="store.lang === 'zh' ? '输入玩家名' : 'Player name'" v-model="skullOwner">
                                    </div>
                                </div>
                                <div v-if="isEnchantable && selectedItem.id !== 'minecraft:enchanted_book'" class="form-check form-switch mb-2">
                                    <input class="form-check-input" type="checkbox" role="switch" id="mapAttachEnch" v-model="attachEnchantment">
                                    <label class="form-check-label small fw-bold text-muted" for="mapAttachEnch">{{ store.lang === 'zh' ? '附加附魔' : 'Attach Enchantment' }}</label>
                                </div>
                                <div v-if="selectedItem.id === 'minecraft:enchanted_book' || (isEnchantable && attachEnchantment && selectedItem.id !== 'minecraft:enchanted_book')" class="row g-2 align-items-center">
                                    <div class="col-sm-6">
                                        <label class="form-label small fw-bold text-muted mb-1">{{ store.lang === 'zh' ? '附魔属性' : 'Enchantment' }}</label>
                                        <select class="form-select form-select-sm" v-model="selectedEnchantment">
                                            <option v-for="ench in ENCHANTMENTS" :key="ench.id" :value="ench.id">{{ store.lang === 'zh' ? ench.namecn : ench.nameen }}</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label small fw-bold text-muted mb-1">{{ store.lang === 'zh' ? '等级' : 'Level' }}</label>
                                        <select class="form-select form-select-sm" v-model.number="enchantmentLevel">
                                            <option v-for="lvl in currentEnchantmentLevels" :key="lvl" :value="lvl">{{ lvl }}</option>
                                        </select>
                                    </div>
                                </div>
                                <div v-if="['minecraft:potion', 'minecraft:splash_potion', 'minecraft:lingering_potion'].includes(selectedItem.id)" class="row g-2 align-items-center">
                                    <div class="col-sm-6">
                                        <label class="form-label small fw-bold text-muted mb-1">{{ store.lang === 'zh' ? '药水效果' : 'Potion Effect' }}</label>
                                        <select class="form-select form-select-sm" v-model="selectedPotionEffect">
                                            <option v-for="eff in POTION_EFFECTS" :key="eff.id" :value="eff.id">{{ store.lang === 'zh' ? eff.namecn : eff.nameen }}</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-6">
                                        <label class="form-label small fw-bold text-muted mb-1">{{ store.lang === 'zh' ? '药水类型' : 'Variant' }}</label>
                                        <select class="form-select form-select-sm" v-model="selectedPotionVariant">
                                            <option v-for="v in currentPotionVariants" :key="v.id" :value="v.id">{{ store.lang === 'zh' ? v.namecn : v.nameen }}</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="mc-selection-details p-3 rounded-3 mb-3 d-flex flex-column flex-sm-row align-items-center justify-content-between gap-3">
                                <div class="d-flex align-items-center gap-3 min-w-0 w-100">
                                    <div class="mc-selected-icon-box">
                                        <img v-if="selectedItem && selectedItem.no !== 'custom'" :src="'/img/items/' + selectedItem.no + '.png'" class="mc-item-img" width="36" height="36" onerror="this.src='/img/items/0.png'">
                                        <span v-else class="fs-3">?</span>
                                    </div>
                                    <div class="min-w-0">
                                        <label class="form-label small fw-bold text-muted mb-1">{{ store.lang === 'zh' ? '已选物品' : 'Selected' }}</label>
                                        <div class="fw-bold text-body text-truncate">{{ selectedItem ? (store.lang === 'zh' ? selectedItem.namecn : selectedItem.nameen) : (store.lang === 'zh' ? '未选择' : 'None') }}</div>
                                        <div class="text-muted small text-truncate" style="font-family: monospace; font-size: 0.72rem;">{{ selectedItem ? selectedItem.id : '-' }}</div>
                                    </div>
                                </div>
                                <div class="d-flex flex-column gap-1 w-100" style="max-width: 320px;">
                                    <label class="form-label small fw-bold text-muted mb-0">{{ store.lang === 'zh' ? '自定义物品ID' : 'Custom Item ID' }}</label>
                                    <input type="text" class="form-control form-control-sm" placeholder="e.g. minecraft:beacon" v-model="customItemId" @input="onCustomIdInput">
                                </div>
                            </div>

                            <div class="row align-items-center g-3">
                                <div class="col-sm-7">
                                    <div class="d-flex align-items-center gap-3">
                                        <label class="form-label small fw-bold text-muted mb-0" style="white-space: nowrap;">{{ store.lang === 'zh' ? '数量' : 'Qty' }}</label>
                                        <input type="range" class="form-range flex-grow-1" min="1" max="64" v-model.number="giveQuantity">
                                        <input type="number" class="form-control form-control-sm text-center fw-bold" style="width: 75px;" min="1" max="999" v-model.number="giveQuantity">
                                    </div>
                                </div>
                                <div class="col-sm-5">
                                    <div class="d-flex gap-1 justify-content-sm-end">
                                        <button class="btn btn-sm btn-outline-secondary" style="min-width: 50px;" @click="giveQuantity = 1">1</button>
                                        <button class="btn btn-sm btn-outline-secondary" style="min-width: 50px;" @click="giveQuantity = 16">16</button>
                                        <button class="btn btn-sm btn-outline-secondary" style="min-width: 50px;" @click="giveQuantity = 64">64</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top pt-3 px-4 pb-4">
                            <button class="btn btn-outline-secondary rounded-pill px-4" @click="closeGiveModal">{{ store.lang === 'zh' ? '取消' : 'Cancel' }}</button>
                            <button class="btn btn-primary rounded-pill px-4 fw-bold shadow" @click="confirmGiveItem" :disabled="!selectedItem || !giveQuantity">
                                <i class="fa-solid fa-circle-check me-1"></i> {{ store.lang === 'zh' ? '给予' : 'Give' }}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </Transition>
    </Teleport>

    <!-- 效果给予弹窗 -->
    <Teleport to="body">
        <Transition name="modal-fade">
            <div class="modal fade show" v-if="showEffectModal" style="display: block; z-index: 1050;">
                <div class="modal-backdrop fade show" @click="closeEffectModal" style="z-index: -1;"></div>
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content border-0 shadow-lg" style="border-radius: 16px; overflow: hidden;">
                        <div class="modal-header border-bottom pb-3 pt-3 px-4 d-flex justify-content-between align-items-center">
                            <h5 class="modal-title fw-bold text-body">
                                <i class="fa-solid fa-flask me-2" style="color:#a855f7"></i>
                                <span>{{ store.lang === 'zh' ? '状态效果' : 'Effect' }}: {{ effectTargetPlayer }}</span>
                            </h5>
                            <button type="button" class="btn-close" @click="closeEffectModal"></button>
                        </div>
                        <div class="modal-body px-4 py-3">
                            <div class="mb-3">
                                <label class="form-label fw-semibold text-muted small mb-1">{{ store.lang === 'zh' ? '效果类型' : 'Effect Type' }}</label>
                                <select class="form-select" v-model="selectedEffect">
                                    <option v-for="eff in STATUS_EFFECTS" :key="eff.id" :value="eff.id">{{ store.lang === 'zh' ? eff.namecn : eff.nameen }}</option>
                                </select>
                            </div>
                            <div class="row g-3 mb-3">
                                <div class="col-6">
                                    <label class="form-label fw-semibold text-muted small mb-1">{{ store.lang === 'zh' ? '持续时间' : 'Duration' }}</label>
                                    <div class="input-group input-group-sm">
                                        <input type="number" class="form-control" min="1" max="999999" v-model.number="effectDuration">
                                        <span class="input-group-text">{{ store.lang === 'zh' ? '秒' : 's' }}</span>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <label class="form-label fw-semibold text-muted small mb-1">{{ store.lang === 'zh' ? '等级' : 'Level' }}</label>
                                    <select class="form-select form-select-sm" v-model.number="effectLevel">
                                        <option v-for="l in 10" :key="l" :value="l">{{ l }}</option>
                                        <option :value="255">255 (Max)</option>
                                    </select>
                                </div>
                            </div>
                            <div class="d-flex gap-1 mb-3 flex-wrap">
                                <button class="btn btn-xs btn-outline-secondary py-1 px-2" @click="effectDuration = 30">30s</button>
                                <button class="btn btn-xs btn-outline-secondary py-1 px-2" @click="effectDuration = 60">1m</button>
                                <button class="btn btn-xs btn-outline-secondary py-1 px-2" @click="effectDuration = 300">5m</button>
                                <button class="btn btn-xs btn-outline-secondary py-1 px-2" @click="effectDuration = 1800">30m</button>
                                <button class="btn btn-xs btn-outline-secondary py-1 px-2" @click="effectDuration = 99999">{{ store.lang === 'zh' ? '永久' : 'Infinite' }}</button>
                            </div>
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="mapHideParticles" v-model="hideParticles">
                                <label class="form-check-label fw-semibold text-muted small" for="mapHideParticles">{{ store.lang === 'zh' ? '隐藏粒子' : 'Hide Particles' }}</label>
                            </div>
                        </div>
                        <div class="modal-footer border-top pt-3 px-4 pb-4 d-flex justify-content-between align-items-center">
                            <button class="btn btn-outline-danger rounded-pill px-3" @click="clearAllEffects">
                                <i class="fa-solid fa-trash me-1"></i> {{ store.lang === 'zh' ? '清除全部' : 'Clear All' }}
                            </button>
                            <div class="d-flex gap-2">
                                <button class="btn btn-outline-secondary rounded-pill px-3" @click="closeEffectModal">{{ store.lang === 'zh' ? '取消' : 'Cancel' }}</button>
                                <button class="btn btn-primary rounded-pill px-3 fw-bold shadow" @click="confirmGiveEffect">
                                    <i class="fa-solid fa-circle-check me-1"></i> {{ store.lang === 'zh' ? '确认' : 'Confirm' }}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Transition>
        </Teleport>

        <!-- 玩家菜单（右侧列表） -->
        <Teleport to="body">
            <div v-if="playerMenu.visible" class="position-fixed" :style="{left: playerMenu.x + 'px', top: playerMenu.y + 'px', zIndex: 10000}" @click.stop>
                <ul class="dropdown-menu show" style="min-width: 200px; box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                    <li class="px-3 py-2 text-white-50 small fw-bold border-bottom border-white border-opacity-10">
                        <i class="fa-solid fa-user me-1"></i> {{ playerMenu.player?.name }}
                    </li>
                    <li><a class="dropdown-item" @click="askTeleport(playerMenu.player)"><i class="fa-solid fa-location-dot me-2 text-primary"></i>{{ store.lang === 'zh' ? '传送' : 'Teleport' }}</a></li>
                    <li><a class="dropdown-item" @click="askGamemode(playerMenu.player)"><i class="fa-solid fa-gamepad me-2 text-info"></i>{{ store.lang === 'zh' ? '游戏模式' : 'Gamemode' }}</a></li>
                    <li><a class="dropdown-item" @click="askGiveItem(playerMenu.player)"><i class="fa-solid fa-gift me-2 text-success"></i>{{ store.lang === 'zh' ? '给予物品' : 'Give Item' }}</a></li>
                    <li><a class="dropdown-item" @click="askEffect(playerMenu.player)"><i class="fa-solid fa-flask me-2 text-purple"></i>{{ store.lang === 'zh' ? '状态效果' : 'Effect' }}</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" @click="sendCmdToPlayer(playerMenu.player, 'clear')"><i class="fa-solid fa-broom me-2 text-warning"></i>{{ store.lang === 'zh' ? '清空背包' : 'Clear Inv' }}</a></li>
                    <li><a class="dropdown-item" @click="sendCmdToPlayer(playerMenu.player, 'kill')"><i class="fa-solid fa-skull me-2 text-danger"></i>{{ store.lang === 'zh' ? '击杀' : 'Kill' }}</a></li>
                </ul>
            </div>
        </Teleport>

        <!-- 地图点击菜单 -->
        <Teleport to="body">
            <div v-if="mapClickMenu.visible" class="position-fixed" :style="{left: mapClickMenu.x + 'px', top: mapClickMenu.y + 'px', zIndex: 10000}" @click.stop>
                <ul class="dropdown-menu show" style="min-width: 200px; box-shadow: 0 8px 24px rgba(0,0,0,0.4);">
                    <li class="px-3 py-2 text-white-50 small fw-bold border-bottom border-white border-opacity-10">
                        <i class="fa-solid fa-crosshairs me-1"></i> {{ mapClickMenu.coords?.x }}, {{ mapClickMenu.coords?.z }}<span v-if="mapClickMenu.coords?.y !== undefined && mapClickMenu.coords?.y !== null">, Y:{{ Math.round(mapClickMenu.coords.y) }}</span>
                    </li>
                    <li><a class="dropdown-item" @click="openShareLocationModal"><i class="fa-solid fa-share-from-square me-2 text-info"></i>{{ store.lang === 'zh' ? '分享位置坐标' : 'Share Location' }}</a></li>
                    <li><a class="dropdown-item" @click="openTeleportModal"><i class="fa-solid fa-location-dot me-2 text-primary"></i>{{ store.lang === 'zh' ? '传送到这里' : 'Teleport Here' }}</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" @click="rebuildCurrentChunk" @mouseenter="hoveredRebuildChunk=true; updateChunkHighlight(mapClickMenu.coords.x, mapClickMenu.coords.z)" @mouseleave="hoveredRebuildChunk=false; removeChunkHighlight()">
                        <i class="fa-solid fa-cube me-2 text-warning"></i>{{ store.lang === 'zh' ? '重建当前区块' : 'Rebuild Chunk' }}
                    </a></li>
                </ul>
            </div>
        </Teleport>

        <!-- 分享位置弹窗 -->
        <Teleport to="body">
            <Transition name="modal-fade">
                <div class="modal fade show" v-if="showShareModal" style="display: block; z-index: 1050;">
                    <div class="modal-backdrop fade show" @click="closeShareModal" style="z-index: -1;"></div>
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content border-0 shadow-lg" style="border-radius: 16px; overflow: hidden;">
                            <div class="modal-header border-bottom pb-3 pt-3 px-4">
                                <h5 class="modal-title fw-bold text-body">
                                    <i class="fa-solid fa-share-from-square me-2 text-info"></i>
                                    {{ store.lang === 'zh' ? '分享位置坐标' : 'Share Location' }}
                                </h5>
                                <button type="button" class="btn-close" @click="closeShareModal"></button>
                            </div>
                            <div class="modal-body px-4 py-3">
                                <div class="mb-3">
                                    <label class="form-label small text-muted mb-1">{{ store.lang === 'zh' ? '坐标位置' : 'Coordinates' }}</label>
                                    <input type="text" class="form-control bg-dark border-secondary text-white-50" :value="shareCoords" readonly>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small text-muted mb-1">{{ store.lang === 'zh' ? '附加信息' : 'Message (Optional)' }}</label>
                                    <input type="text" class="form-control bg-dark border-secondary text-white" v-model="shareMessage" :placeholder="store.lang === 'zh' ? '例如：我在这里发现了钻石！' : 'e.g., Found diamonds here!'">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small text-muted mb-1">{{ store.lang === 'zh' ? '接收者' : 'Recipient' }}</label>
                                    <select class="form-select bg-dark border-secondary text-white" v-model="shareRecipient">
                                        <option value="@a">{{ store.lang === 'zh' ? '所有玩家' : 'All Players' }}</option>
                                        <option v-for="p in onlinePlayersList" :key="p" :value="p">{{ p }}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer border-top pt-3 px-4 pb-4">
                                <button class="btn btn-outline-secondary rounded-pill px-4" @click="closeShareModal">{{ store.lang === 'zh' ? '取消' : 'Cancel' }}</button>
                                <button class="btn btn-info rounded-pill px-4 fw-bold shadow" @click="confirmShareLocation">
                                    <i class="fa-solid fa-paper-plane me-1"></i> {{ store.lang === 'zh' ? '发送' : 'Send' }}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </Transition>
        </Teleport>

        <!-- 传送弹窗 -->
        <Teleport to="body">
            <Transition name="modal-fade">
                <div class="modal fade show" v-if="showTeleportModal" style="display: block; z-index: 1050;">
                    <div class="modal-backdrop fade show" @click="closeTeleportModal" style="z-index: -1;"></div>
                    <div class="modal-dialog modal-dialog-centered modal-sm">
                        <div class="modal-content border-0 shadow-lg" style="border-radius: 16px; overflow: hidden;">
                            <div class="modal-header border-bottom pb-3 pt-3 px-4">
                                <h5 class="modal-title fw-bold text-body">
                                    <i class="fa-solid fa-location-dot me-2 text-primary"></i>
                                    {{ store.lang === 'zh' ? '传送到这里' : 'Teleport Here' }}
                                </h5>
                                <button type="button" class="btn-close" @click="closeTeleportModal"></button>
                            </div>
                            <div class="modal-body px-4 py-3">
                                <div class="mb-3">
                                    <label class="form-label small text-muted mb-1">{{ store.lang === 'zh' ? '目标坐标' : 'Coordinates' }}</label>
                                    <input type="text" class="form-control bg-dark border-secondary text-white-50" :value="teleportCoords" readonly>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small text-muted mb-1">{{ store.lang === 'zh' ? '传送玩家' : 'Player' }}</label>
                                    <select class="form-select bg-dark border-secondary text-white" v-model="teleportTarget">
                                        <option v-for="p in onlinePlayersList" :key="p" :value="p">{{ p }}</option>
                                    </select>
                                    <div v-if="!onlinePlayersList.length" class="small text-muted mt-1">
                                        {{ store.lang === 'zh' ? '暂无在线玩家' : 'No players online' }}
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer border-top pt-3 px-4 pb-4">
                                <button class="btn btn-outline-secondary rounded-pill px-4" @click="closeTeleportModal">{{ store.lang === 'zh' ? '取消' : 'Cancel' }}</button>
                                <button class="btn btn-primary rounded-pill px-4 fw-bold shadow" @click="confirmTeleport" :disabled="!teleportTarget || !onlinePlayersList.length">
                                    <i class="fa-solid fa-bolt me-1"></i> {{ store.lang === 'zh' ? '传送' : 'Teleport' }}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </Transition>
        </Teleport>
    `,
    setup() {
        const instanceId = computed(() => store.currentInstanceId || 'default');
        const selectedDim = ref('minecraft:overworld');
        const regions = ref([]);
        const players = ref([]);
        const rendering = ref(false);
        const autoRefresh = ref(true);
        const mouseCoords = ref({ x: 0, z: 0 });
        let refreshInterval = null;
        let regionRefreshInterval = null;
        let docClickHandler = null;

        // Entity state
        const entitySettings = ref({ friendly: true, neutral: false, hostile: false });
        const entityData = ref({ categories: {} });
        const entityNamesMap = ref({});
        const entityCounts = computed(() => {
            const counts = {};
            for (const [cat, data] of Object.entries(entityData.value.categories || {})) {
                counts[cat] = data.entities?.length || 0;
            }
            return counts;
        });
        const entityCategories = [
            { id: 'friendly', zh: '友好', en: 'Friend', icon: 'fa-solid fa-dove', color: '#10b981' },
            { id: 'neutral', zh: '中立', en: 'Neutral', icon: 'fa-solid fa-shield-halved', color: '#f59e0b' },
            { id: 'hostile', zh: '敌对', en: 'Hostile', icon: 'fa-solid fa-skull-crossbones', color: '#ef4444' }
        ];

        const dimensionsList = [
            { id: 'minecraft:overworld', zh: '主世界', en: 'Overworld', icon: 'fa-solid fa-earth-americas', activeClass: 'bg-success' },
            { id: 'minecraft:the_nether', zh: '下界', en: 'Nether', icon: 'fa-solid fa-fire-flame-curved', activeClass: 'bg-danger' },
            { id: 'minecraft:the_end', zh: '末地', en: 'The End', icon: 'fa-solid fa-circle-nodes', activeClass: 'bg-warning text-dark' }
        ];

        let map = null;
        let overlays = {};
        let overlayMtimes = {};
        let playerMarkers = {};
        let entityMarkers = []; // [{marker, category, key}]
        let clickMarker = null; // Click position marker
        let styleEl = null;

        // ---- Player menu state (sidebar list) ----
        const playerMenu = ref({ visible: false, player: null, x: 0, y: 0 });

        // ---- Map click menu state ----
        const mapClickMenu = ref({ visible: false, x: 0, y: 0, coords: { x: 0, z: 0 } });

        // ---- Chunk highlight state ----
        let chunkHighlightRect = null;
        const hoveredRebuildChunk = ref(false);

        // ---- Fullscreen state ----
        const isFullscreen = ref(false);
        const radarCollapsed = ref(false);

        // ---- Biome state ----
        const currentBiome = ref('');
        const currentBiomeRaw = ref('');

        const BIOME_NAMES = {
            'ocean': { zh: '海洋', en: 'Ocean' },
            'deep_ocean': { zh: '深海', en: 'Deep Ocean' },
            'frozen_ocean': { zh: '冻洋', en: 'Frozen Ocean' },
            'deep_frozen_ocean': { zh: '冻洋深处', en: 'Deep Frozen Ocean' },
            'cold_ocean': { zh: '冷水海洋', en: 'Cold Ocean' },
            'deep_cold_ocean': { zh: '冷水深海', en: 'Deep Cold Ocean' },
            'lukewarm_ocean': { zh: '温水海洋', en: 'Lukewarm Ocean' },
            'deep_lukewarm_ocean': { zh: '温水深海', en: 'Deep Lukewarm Ocean' },
            'warm_ocean': { zh: '暖水海洋', en: 'Warm Ocean' },
            'deep_warm_ocean': { zh: '暖水深海', en: 'Deep Warm Ocean' },
            'river': { zh: '河流', en: 'River' },
            'frozen_river': { zh: '冻河', en: 'Frozen River' },
            'beach': { zh: '沙滩', en: 'Beach' },
            'snowy_beach': { zh: '积雪沙滩', en: 'Snowy Beach' },
            'stony_shore': { zh: '石岸', en: 'Stony Shore' },
            'plains': { zh: '平原', en: 'Plains' },
            'sunflower_plains': { zh: '向日葵平原', en: 'Sunflower Plains' },
            'snowy_plains': { zh: '积雪平原', en: 'Snowy Plains' },
            'ice_spikes': { zh: '冰刺之地', en: 'Ice Spikes' },
            'desert': { zh: '沙漠', en: 'Desert' },
            'forest': { zh: '森林', en: 'Forest' },
            'flower_forest': { zh: '繁花森林', en: 'Flower Forest' },
            'birch_forest': { zh: '桦木森林', en: 'Birch Forest' },
            'old_growth_birch_forest': { zh: '原始桦木森林', en: 'Old Growth Birch Forest' },
            'dark_forest': { zh: '黑森林', en: 'Dark Forest' },
            'old_growth_pine_taiga': { zh: '原始松树针叶林', en: 'Old Growth Pine Taiga' },
            'old_growth_spruce_taiga': { zh: '原始云杉针叶林', en: 'Old Growth Spruce Taiga' },
            'taiga': { zh: '针叶林', en: 'Taiga' },
            'snowy_taiga': { zh: '积雪针叶林', en: 'Snowy Taiga' },
            'grove': { zh: '树林', en: 'Grove' },
            'snowy_slopes': { zh: '积雪山坡', en: 'Snowy Slopes' },
            'jagged_peaks': { zh: '尖峭山峰', en: 'Jagged Peaks' },
            'frozen_peaks': { zh: '冰封山峰', en: 'Frozen Peaks' },
            'stony_peaks': { zh: '石头山峰', en: 'Stony Peaks' },
            'meadow': { zh: '草甸', en: 'Meadow' },
            'cherry_grove': { zh: '樱花树林', en: 'Cherry Grove' },
            'mushroom_fields': { zh: '蘑菇岛', en: 'Mushroom Fields' },
            'swamp': { zh: '沼泽', en: 'Swamp' },
            'mangrove_swamp': { zh: '红树林沼泽', en: 'Mangrove Swamp' },
            'jungle': { zh: '丛林', en: 'Jungle' },
            'sparse_jungle': { zh: '稀疏丛林', en: 'Sparse Jungle' },
            'bamboo_jungle': { zh: '竹林', en: 'Bamboo Jungle' },
            'badlands': { zh: '恶地', en: 'Badlands' },
            'eroded_badlands': { zh: '风蚀恶地', en: 'Eroded Badlands' },
            'wooded_badlands': { zh: '繁茂恶地', en: 'Wooded Badlands' },
            'savanna': { zh: '热带草原', en: 'Savanna' },
            'savanna_plateau': { zh: '热带高原', en: 'Savanna Plateau' },
            'windswept_hills': { zh: '风蚀丘陵', en: 'Windswept Hills' },
            'windswept_gravelly_hills': { zh: '风蚀砂砾丘陵', en: 'Windswept Gravelly Hills' },
            'windswept_forest': { zh: '风蚀森林', en: 'Windswept Forest' },
            'windswept_savanna': { zh: '风蚀热带草原', en: 'Windswept Savanna' },
            'dripstone_caves': { zh: '溶洞', en: 'Dripstone Caves' },
            'lush_caves': { zh: '繁茂洞穴', en: 'Lush Caves' },
            'deep_dark': { zh: '深暗之域', en: 'Deep Dark' },
            'nether_wastes': { zh: '下界荒地', en: 'Nether Wastes' },
            'soul_sand_valley': { zh: '灵魂沙峡谷', en: 'Soul Sand Valley' },
            'crimson_forest': { zh: '绯红森林', en: 'Crimson Forest' },
            'warped_forest': { zh: '诡异森林', en: 'Warped Forest' },
            'basalt_deltas': { zh: '玄武岩三角洲', en: 'Basalt Deltas' },
            'the_end': { zh: '末地', en: 'The End' },
            'end_midlands': { zh: '末地中部', en: 'End Midlands' },
            'end_highlands': { zh: '末地高地', en: 'End Highlands' },
            'end_barrens': { zh: '末地荒地', en: 'End Barrens' },
            'small_end_islands': { zh: '末地小岛', en: 'Small End Islands' }
        };

        // ---- Share location state ----
        const showShareModal = ref(false);
        const shareMessage = ref('');
        const shareRecipient = ref('@a');
        const shareCoords = ref('');

        // ---- Teleport modal state ----
        const showTeleportModal = ref(false);
        const teleportTarget = ref('');
        const teleportCoords = ref('');

        // ---- Online players list for share ----
        const onlinePlayersList = computed(() => {
            return players.value.filter(p => isOnline(p.name)).map(p => p.name);
        });

        // ---- Give item state ----
        const showGiveModal = ref(false);
        const targetPlayer = ref('');
        const selectedItem = ref(null);
        const giveQuantity = ref(64);
        const itemSearchQuery = ref('');
        const activeTab = ref('building_blocks');
        const customItemId = ref('');
        const creativeItems = ref([]);
        const selectedEnchantment = ref('minecraft:protection');
        const enchantmentLevel = ref(1);
        const selectedPotionEffect = ref('healing');
        const selectedPotionVariant = ref('minecraft:healing');
        const skullOwner = ref('');
        const attachEnchantment = ref(false);

        // ---- Effect state ----
        const showEffectModal = ref(false);
        const effectTargetPlayer = ref('');
        const selectedEffect = ref('minecraft:speed');
        const effectDuration = ref(600);
        const effectLevel = ref(1);
        const hideParticles = ref(false);

        // ---- Give item computed ----
        const isEnchantable = computed(() => {
            if (!selectedItem.value) return false;
            const id = selectedItem.value.id;
            if (id === 'minecraft:enchanted_book') return true;
            const keywords = ['sword', 'pickaxe', 'axe', 'shovel', 'hoe', 'helmet', 'chestplate', 'leggings', 'boots', 'bow', 'crossbow', 'trident', 'shield', 'elytra', 'fishing_rod', 'shears', 'flint_and_steel', 'brush', 'mace'];
            return keywords.some(k => id.includes(k));
        });

        const currentEnchantmentLevels = computed(() => {
            const ench = ENCHANTMENTS.find(e => e.id === selectedEnchantment.value);
            if (!ench) return [1];
            return Array.from({ length: ench.maxLvl }, (_, i) => i + 1);
        });

        const currentPotionVariants = computed(() => {
            const effect = POTION_EFFECTS.find(e => e.id === selectedPotionEffect.value);
            return effect ? effect.variants : [];
        });

        const filteredItems = computed(() => {
            const query = itemSearchQuery.value.toLowerCase().trim();
            let list = creativeItems.value.filter(item => !UNGIVEABLE_IDS.has(item.id));
            if (query) {
                return list.filter(item => item.namecn.toLowerCase().includes(query) || item.nameen.toLowerCase().includes(query) || item.id.toLowerCase().includes(query));
            }
            // 杂项分类显示所有不在有效分类中的物品
            if (activeTab.value === 'misc') {
                return list.filter(item => !VALID_CATEGORIES.has(item.category));
            }
            return list.filter(item => item.category === activeTab.value);
        });

        const emptySlotsCount = computed(() => {
            const count = filteredItems.value.length;
            const minSlots = 27;
            if (count < minSlots) return minSlots - count;
            const remainder = count % 9;
            return remainder === 0 ? 0 : 9 - remainder;
        });

        // ---- Load Leaflet ----
        const loadLeaflet = () => {
            return new Promise((resolve) => {
                if (window.L) { resolve(); return; }
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
                document.head.appendChild(link);
                const script = document.createElement('script');
                script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
                script.onload = () => resolve();
                document.head.appendChild(script);
            });
        };

        // ---- Initialize Map (reduced zoom sensitivity) ----
        const initMap = () => {
            if (map) return;
            map = L.map('leaflet-map', {
                crs: L.CRS.Simple,
                minZoom: -5,
                maxZoom: 3,
                zoom: -2,
                center: [0, 0],
                zoomControl: false,
                attributionControl: false,
                wheelPxPerZoomLevel: 150,
                zoomSnap: 0.5
            });
            L.control.zoom({ position: 'bottomright' }).addTo(map);
            map.on('mousemove', (e) => {
                mouseCoords.value.x = Math.round(e.latlng.lng);
                mouseCoords.value.z = Math.round(-e.latlng.lat);
                fetchBiome(mouseCoords.value.x, mouseCoords.value.z);
                // Show chunk boundary when hovering "rebuild chunk" button
                if (hoveredRebuildChunk.value) updateChunkHighlight(mouseCoords.value.x, mouseCoords.value.z);
            });
            // Map click for empty area - show share/teleport menu
            map.on('click', (e) => {
                hideMapClickMenu();
                const x = Math.round(e.latlng.lng);
                const z = Math.round(-e.latlng.lat);

                // Remove old click marker
                if (clickMarker) map.removeLayer(clickMarker);

                // Add new click marker
                const clickIcon = L.divIcon({
                    className: 'leaflet-click-marker',
                    html: `<div style="
                        width: 16px; height: 16px;
                        border: 2px solid #fff;
                        border-radius: 50%;
                        background: rgba(59, 130, 246, 0.8);
                        box-shadow: 0 0 8px rgba(59, 130, 246, 0.5);
                    "></div>`,
                    iconSize: [16, 16],
                    iconAnchor: [8, 8]
                });
                clickMarker = L.marker([-z, x], { icon: clickIcon, interactive: false }).addTo(map);

                // Use client coordinates for menu position
                mapClickMenu.value = {
                    visible: true,
                    x: e.originalEvent.clientX,
                    y: e.originalEvent.clientY,
                    coords: { x, z }
                };
            });
        };

        // ---- Draw map overlays ----
        const drawMapOverlays = async (force = false) => {
            if (!map) return;
            if (force) rendering.value = true;
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-map/regions', {
                    params: { instanceId: instanceId.value, dimension: selectedDim.value }
                });
                regions.value = res.data || [];
                const activeFiles = regions.value.map(r => r.file);
                // Remove overlays for deleted region files
                for (const file of Object.keys(overlays)) {
                    if (!activeFiles.includes(file) || force) {
                        map.removeLayer(overlays[file]);
                        delete overlays[file];
                        delete overlayMtimes[file];
                    }
                }
                for (const r of regions.value) {
                    const needsUpdate = force || !overlays[r.file] || (r.mtime && overlayMtimes[r.file] !== r.mtime);
                    if (needsUpdate) {
                        const cacheBuster = (force ? '&force=true' : '') + '&t=' + Date.now();
                        const imageUrl = `/api/plugins/mc-panel-plugin-map/render?instanceId=${instanceId.value}&dimension=${selectedDim.value}&region=${r.file}${cacheBuster}`;
                        const bounds = [[-(r.z + 1) * 512, r.x * 512], [-r.z * 512, (r.x + 1) * 512]];
                        const newOverlay = L.imageOverlay(imageUrl, bounds).addTo(map);
                        const oldOverlay = overlays[r.file];
                        // Wait for new image to load before removing old one (prevents flicker)
                        const img = new Image();
                        img.onload = () => {
                            if (oldOverlay && map) {
                                try { map.removeLayer(oldOverlay); } catch(e) {}
                            }
                        };
                        img.onerror = () => {
                            if (oldOverlay && map) {
                                try { map.removeLayer(oldOverlay); } catch(e) {}
                            }
                        };
                        img.src = imageUrl;
                        overlays[r.file] = newOverlay;
                        if (r.mtime) overlayMtimes[r.file] = r.mtime;
                    }
                }
            } catch (e) { console.error(e); }
            finally { if (force) rendering.value = false; }
        };

        // ---- Biome fetch (debounced) ----
        let biomeTimer = null;
        const fetchBiome = (x, z) => {
            if (biomeTimer) clearTimeout(biomeTimer);
            biomeTimer = setTimeout(async () => {
                try {
                    const res = await api.get('/api/plugins/mc-panel-plugin-map/biome', {
                        params: { instanceId: instanceId.value, dimension: selectedDim.value, x, z }
                    });
                    const raw = res.data?.biome || '';
                    const key = raw.replace('minecraft:', '');
                    currentBiomeRaw.value = key;
                    const lang = store.lang === 'zh' ? 'zh' : 'en';
                    currentBiome.value = BIOME_NAMES[key]?.[lang] || key.replace(/_/g, ' ');
                } catch { currentBiome.value = ''; }
            }, 300);
        };

        // ---- Chunk highlight (show boundary on hover) ----
        const updateChunkHighlight = (x, z) => {
            if (!map) return;
            const cx = Math.floor(x / 16) * 16;
            const cz = Math.floor(z / 16) * 16;
            const bounds = [[-(cz + 16), cx], [-cz, cx + 16]];
            if (chunkHighlightRect) {
                chunkHighlightRect.setBounds(bounds);
            } else {
                chunkHighlightRect = L.rectangle(bounds, {
                    color: '#3b82f6', weight: 2, fill: true,
                    fillColor: '#3b82f6', fillOpacity: 0.15, dashArray: '6,4'
                }).addTo(map);
            }
        };

        const removeChunkHighlight = () => {
            if (chunkHighlightRect) { map?.removeLayer(chunkHighlightRect); chunkHighlightRect = null; }
        };

        // ---- Rebuild single chunk ----
        const rebuildCurrentChunk = async () => {
            const { x, z } = mapClickMenu.value.coords;
            const chunkX = Math.floor(x / 16);
            const chunkZ = Math.floor(z / 16);
            rendering.value = true;
            try {
                await api.get('/api/plugins/mc-panel-plugin-map/chunk-render', {
                    params: { instanceId: instanceId.value, dimension: selectedDim.value, chunkX, chunkZ, force: true }
                });
                // Re-render the containing region overlay
                const regionX = Math.floor(chunkX / 32);
                const regionZ = Math.floor(chunkZ / 32);
                const regionFile = `r.${regionX}.${regionZ}.mca`;
                if (overlays[regionFile]) {
                    map.removeLayer(overlays[regionFile]);
                    delete overlays[regionFile];
                }
                await drawMapOverlays();
                showToast(store.lang === 'zh' ? `区块 (${chunkX}, ${chunkZ}) 已重建` : `Chunk (${chunkX}, ${chunkZ}) rebuilt`);
            } catch (e) {
                showToast(store.lang === 'zh' ? '区块重建失败' : 'Chunk rebuild failed', 'error');
            } finally {
                rendering.value = false;
            }
            hideMapClickMenu();
            removeChunkHighlight();
        };

        // ---- Update player markers (with avatar + click handler) ----
        const updatePlayerMarkers = () => {
            if (!map) return;
            const activeUUIDs = [];
            for (const p of players.value) {
                // Skip offline players - only show online players on the map
                if (!isOnline(p.name)) {
                    if (playerMarkers[p.uuid]) { map.removeLayer(playerMarkers[p.uuid]); delete playerMarkers[p.uuid]; }
                    continue;
                }
                if (p.dimension !== selectedDim.value) {
                    if (playerMarkers[p.uuid]) { map.removeLayer(playerMarkers[p.uuid]); delete playerMarkers[p.uuid]; }
                    continue;
                }
                activeUUIDs.push(p.uuid);
                const latlng = [-p.z, p.x];
                const online = isOnline(p.name);

                if (playerMarkers[p.uuid]) {
                    playerMarkers[p.uuid].setLatLng(latlng);
                    const element = playerMarkers[p.uuid].getElement();
                    if (element) {
                        const img = element.querySelector('.player-avatar-img');
                        const ring = element.querySelector('.pulse-ring');
                        if (img) img.style.borderColor = online ? '#198754' : '#6c757d';
                        if (ring) ring.className = `pulse-ring ${online ? 'bg-success' : 'bg-secondary'}`;
                    }
                } else {
                    const borderColor = online ? '#198754' : '#6c757d';
                    const playerIcon = L.divIcon({
                        className: 'leaflet-player-marker',
                        html: `
                            <div class="player-marker-wrapper">
                                <span class="pulse-ring ${online ? 'bg-success' : 'bg-secondary'}"></span>
                                <img src="https://minotar.net/helm/${encodeURIComponent(p.name)}/24"
                                     class="player-avatar-img"
                                     style="width:26px;height:26px;image-rendering:pixelated;border-radius:50%;border:2.5px solid ${borderColor};box-shadow:0 2px 8px rgba(0,0,0,0.6);background:#1a1a2e;position:relative;z-index:2;cursor:pointer;"
                                     onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
                                <div class="marker-dot-fallback" style="display:none;width:26px;height:26px;border-radius:50%;border:2.5px solid ${borderColor};background:${online ? '#198754' : '#6c757d'};align-items:center;justify-content:center;color:#fff;font-size:10px;font-weight:bold;box-shadow:0 2px 8px rgba(0,0,0,0.6);position:relative;z-index:2;cursor:pointer;">
                                    ${p.name[0].toUpperCase()}
                                </div>
                                <div class="marker-label">
                                    ${p.name} <span class="badge bg-black text-emerald" style="font-size:8px;">Y:${Math.round(p.y)}</span>
                                </div>
                            </div>
                        `,
                        iconSize: [30, 30],
                        iconAnchor: [15, 15]
                    });

                    const marker = L.marker(latlng, { icon: playerIcon }).addTo(map);
                    marker.on('click', (e) => {
                        L.DomEvent.stopPropagation(e);
                        // Click on player → show map click menu with player's Y
                        hideMapClickMenu();
                        if (clickMarker) { map.removeLayer(clickMarker); clickMarker = null; }
                        // Add click marker at player position
                        const clickIcon = L.divIcon({
                            className: 'leaflet-click-marker',
                            html: `<div style="width:16px;height:16px;border:2px solid #fff;border-radius:50%;background:rgba(59,130,246,0.8);box-shadow:0 0 8px rgba(59,130,246,0.5);"></div>`,
                            iconSize: [16, 16], iconAnchor: [8, 8]
                        });
                        clickMarker = L.marker([-p.z, p.x], { icon: clickIcon, interactive: false }).addTo(map);
                        mapClickMenu.value = {
                            visible: true,
                            x: e.originalEvent.clientX,
                            y: e.originalEvent.clientY,
                            coords: { x: Math.round(p.x), z: Math.round(p.z), y: p.y }
                        };
                    });
                    playerMarkers[p.uuid] = marker;
                }
            }
            for (const uuid of Object.keys(playerMarkers)) {
                if (!activeUUIDs.includes(uuid)) { map.removeLayer(playerMarkers[uuid]); delete playerMarkers[uuid]; }
            }
        };

        // ---- Fetch players ----
        const fetchPlayers = async () => {
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-map/players', {
                    params: { instanceId: instanceId.value }
                });
                players.value = res.data || [];
                updatePlayerMarkers();
            } catch (e) { console.error(e); }
        };

        // ---- Entity category toggle ----
        const toggleEntityCategory = async (catId) => {
            entitySettings.value[catId] = !entitySettings.value[catId];
            try {
                await api.post('/api/plugins/mc-panel-plugin-map/entity-settings', entitySettings.value);
            } catch (e) { console.error(e); }
            if (!entitySettings.value[catId]) {
                // Remove markers for this category immediately
                entityMarkers = entityMarkers.filter(em => {
                    if (em.category === catId) { map.removeLayer(em.marker); return false; }
                    return true;
                });
            }
        };

        // ---- Fetch entities ----
        const fetchEntities = async () => {
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-map/entities', {
                    params: { instanceId: instanceId.value }
                });
                entityData.value = res.data || { categories: {} };
                updateEntityMarkers();
            } catch (e) { console.error(e); }
        };

        // ---- Update entity markers on map ----
        const updateEntityMarkers = () => {
            if (!map) return;
            // Remove old entity markers
            for (const em of entityMarkers) map.removeLayer(em.marker);
            entityMarkers = [];

            for (const [category, catData] of Object.entries(entityData.value.categories || {})) {
                if (!entitySettings.value[category]) continue;
                const color = catData.color || '#fff';
                for (const ent of (catData.entities || [])) {
                    const latlng = [-ent.z, ent.x];
                    const key = `${category}_${ent.type}_${Math.round(ent.x)}_${Math.round(ent.z)}`;
                    // Use translated entity name
                    const entityName = getEntityName(ent.type);

                    const entityIcon = L.divIcon({
                        className: 'leaflet-entity-marker',
                        html: `<div class="entity-dot" style="
                            width:8px;height:8px;border-radius:50%;
                            background:${color};border:1.5px solid rgba(255,255,255,0.5);
                            box-shadow:0 0 6px ${color}88;cursor:pointer;
                        " title="${entityName}"></div>`,
                        iconSize: [8, 8],
                        iconAnchor: [4, 4]
                    });

                    const marker = L.marker(latlng, { icon: entityIcon, interactive: true }).addTo(map);
                    marker.on('click', (e) => {
                        L.DomEvent.stopPropagation(e);
                        // Click on entity → show map click menu with entity's Y
                        hideMapClickMenu();
                        if (clickMarker) { map.removeLayer(clickMarker); clickMarker = null; }
                        const clickIcon = L.divIcon({
                            className: 'leaflet-click-marker',
                            html: `<div style="width:16px;height:16px;border:2px solid #fff;border-radius:50%;background:rgba(59,130,246,0.8);box-shadow:0 0 8px rgba(59,130,246,0.5);"></div>`,
                            iconSize: [16, 16], iconAnchor: [8, 8]
                        });
                        clickMarker = L.marker([-ent.z, ent.x], { icon: clickIcon, interactive: false }).addTo(map);
                        mapClickMenu.value = {
                            visible: true,
                            x: e.originalEvent.clientX,
                            y: e.originalEvent.clientY,
                            coords: { x: Math.round(ent.x), z: Math.round(ent.z), y: ent.y }
                        };
                    });
                    entityMarkers.push({ marker, category, key });
                }
            }
        };

        // ---- Get translated entity name ----
        const getEntityName = (type) => {
            const names = entityNamesMap.value[type];
            if (names) {
                return store.lang === 'zh' ? names.zh : names.en;
            }
            // Fallback: capitalize first letter
            return type.charAt(0).toUpperCase() + type.slice(1);
        };

        // ---- Pan to player ----
        const panToPlayer = (player) => {
            if (!map) return;
            selectedDim.value = player.dimension;
            setTimeout(() => { map.setView([-player.z, player.x], 1); }, 100);
        };

        // ---- Reset view ----
        const resetView = () => {
            if (!map) return;
            if (players.value.length) { panToPlayer(players.value[0]); }
            else if (regions.value.length) {
                const r = regions.value[0];
                map.setView([-(r.z * 512 + 256), r.x * 512 + 256], -1);
            } else { map.setView([0, 0], -1); }
        };

        const forceRebuild = () => { drawMapOverlays(true); };

        // ---- Is player online ----
        const isOnline = (name) => store.onlinePlayers.includes(name);

        // ---- Dimension helpers ----
        const getDimName = (dim) => {
            if (dim === 'minecraft:the_nether') return store.lang === 'zh' ? '下界' : 'Nether';
            if (dim === 'minecraft:the_end') return store.lang === 'zh' ? '末地' : 'The End';
            return store.lang === 'zh' ? '主世界' : 'Overworld';
        };
        const getDimBadgeClass = (dim) => {
            if (dim === 'minecraft:the_nether') return 'bg-danger';
            if (dim === 'minecraft:the_end') return 'bg-warning text-dark';
            return 'bg-success';
        };

        // ==================== Send Command ====================
        const sendCmd = async (c) => {
            if (!store.isRunning) { showToast(store.lang === 'zh' ? '服务器未运行' : 'Server offline', 'warning'); return; }
            await api.post('/api/server/command', { command: c });
            showToast(store.lang === 'zh' ? '命令已发送' : 'Command sent');
            hidePlayerMenu();
        };

        // ==================== Player Actions ====================
        const askTeleport = (player) => {
            hidePlayerMenu();
            openModal({
                title: `${store.lang === 'zh' ? '传送' : 'Teleport'} ${player.name}`,
                message: store.lang === 'zh' ? '坐标 (x y z) 或玩家名:' : 'Coords (x y z) or Player:',
                mode: 'input', inputValue: '~ ~ ~',
                callback: (val) => sendCmd(`tp ${player.name} ${val}`)
            });
        };
        const askGamemode = (player) => {
            hidePlayerMenu();
            openModal({
                title: `${store.lang === 'zh' ? '游戏模式' : 'Gamemode'} ${player.name}`,
                message: store.lang === 'zh' ? '选择模式:' : 'Mode:',
                mode: 'select', inputValue: 'survival',
                options: [
                    { label: 'Survival', value: 'survival' },
                    { label: 'Creative', value: 'creative' },
                    { label: 'Adventure', value: 'adventure' },
                    { label: 'Spectator', value: 'spectator' }
                ],
                callback: (val) => sendCmd(`gamemode ${val} ${player.name}`)
            });
        };

        // ---- Give Item ----
        const loadCreativeItems = async () => {
            try {
                const response = await fetch('/js/items.json');
                creativeItems.value = await response.json();
            } catch (e) { console.error('Failed to load items.json:', e); }
        };
        const askGiveItem = (player) => {
            hidePlayerMenu();
            targetPlayer.value = player.name;
            if (creativeItems.value.length > 0) {
                const firstBuilding = creativeItems.value.find(i => i.category === 'building_blocks') || creativeItems.value[0];
                selectedItem.value = firstBuilding;
                customItemId.value = firstBuilding.id;
            } else { selectedItem.value = null; customItemId.value = ''; }
            giveQuantity.value = 64;
            itemSearchQuery.value = '';
            activeTab.value = 'building_blocks';
            skullOwner.value = '';
            attachEnchantment.value = false;
            showGiveModal.value = true;
        };
        const closeGiveModal = () => { showGiveModal.value = false; };
        const selectItem = (item) => { selectedItem.value = item; customItemId.value = item.id; };
        const onCustomIdInput = () => {
            const val = customItemId.value.trim().toLowerCase();
            if (val) {
                const found = creativeItems.value.find(i => i.id === val);
                selectedItem.value = found || { id: val, namecn: '自定义物品', nameen: 'Custom Item', no: 'custom' };
            } else { selectedItem.value = null; }
        };
        const confirmGiveItem = async () => {
            if (!selectedItem.value || !giveQuantity.value) return;
            const itemId = selectedItem.value.id.trim();
            const qty = giveQuantity.value;
            let isLegacy = false, isModernComponent = false;
            const versionStr = store.stats.version ? (store.stats.version.mc || store.stats.version) : '';
            if (versionStr && typeof versionStr === 'string') {
                const match = versionStr.match(/^(\d+)\.(\d+)(?:\.(\d+))?/);
                if (match) {
                    const major = parseInt(match[1]), minor = parseInt(match[2]), patch = match[3] ? parseInt(match[3]) : 0;
                    if (major < 1 || (major === 1 && minor < 13)) isLegacy = true;
                    if (major > 1 || (major === 1 && (minor > 20 || (minor === 20 && patch >= 5)))) isModernComponent = true;
                }
            }
            let giveCmd = '';
            if (itemId === 'minecraft:enchanted_book') {
                const shortEnch = selectedEnchantment.value.replace('minecraft:', '');
                const lvl = enchantmentLevel.value;
                if (isModernComponent) giveCmd = `give ${targetPlayer.value} minecraft:enchanted_book[stored_enchantments={${shortEnch}:${lvl}}] ${qty}`;
                else if (isLegacy) giveCmd = `give ${targetPlayer.value} minecraft:enchanted_book ${qty} 0 {StoredEnchantments:[{id:"${selectedEnchantment.value}",lvl:${lvl}s}]}`;
                else giveCmd = `give ${targetPlayer.value} minecraft:enchanted_book{StoredEnchantments:[{id:"${selectedEnchantment.value}",lvl:${lvl}s}]} ${qty}`;
            } else if (['minecraft:potion', 'minecraft:splash_potion', 'minecraft:lingering_potion'].includes(itemId)) {
                const pot = selectedPotionVariant.value;
                if (isModernComponent) giveCmd = `give ${targetPlayer.value} ${itemId}[potion_contents={potion:"${pot}"}] ${qty}`;
                else if (isLegacy) giveCmd = `give ${targetPlayer.value} ${itemId} ${qty} 0 {Potion:"${pot}"}`;
                else giveCmd = `give ${targetPlayer.value} ${itemId}{Potion:"${pot}"} ${qty}`;
            } else if (itemId === 'minecraft:player_head') {
                const owner = skullOwner.value.trim();
                if (owner) {
                    if (isModernComponent) giveCmd = `give ${targetPlayer.value} minecraft:player_head[profile="${owner}"] ${qty}`;
                    else if (isLegacy) giveCmd = `give ${targetPlayer.value} minecraft:skull ${qty} 3 {SkullOwner:"${owner}"}`;
                    else giveCmd = `give ${targetPlayer.value} minecraft:player_head{SkullOwner:"${owner}"} ${qty}`;
                } else {
                    giveCmd = isLegacy ? `give ${targetPlayer.value} minecraft:skull ${qty} 3` : `give ${targetPlayer.value} minecraft:player_head ${qty}`;
                }
            } else if (attachEnchantment.value && isEnchantable.value) {
                const shortEnch = selectedEnchantment.value.replace('minecraft:', '');
                const lvl = enchantmentLevel.value;
                if (isModernComponent) giveCmd = `give ${targetPlayer.value} ${itemId}[enchantments={${shortEnch}:${lvl}}] ${qty}`;
                else if (isLegacy) {
                    const mapped = LEGACY_ITEMS[itemId];
                    giveCmd = `give ${targetPlayer.value} ${mapped ? mapped.id : itemId} ${qty} ${mapped ? mapped.data : 0} {ench:[{id:"${selectedEnchantment.value}",lvl:${lvl}s}]}`;
                } else giveCmd = `give ${targetPlayer.value} ${itemId}{Enchantments:[{id:"${selectedEnchantment.value}",lvl:${lvl}s}]} ${qty}`;
            } else {
                if (isLegacy) {
                    const mapped = LEGACY_ITEMS[itemId];
                    giveCmd = mapped ? `give ${targetPlayer.value} ${mapped.id} ${qty} ${mapped.data}` : `give ${targetPlayer.value} ${itemId} ${qty}`;
                } else giveCmd = `give ${targetPlayer.value} ${itemId} ${qty}`;
            }
            await sendCmd(giveCmd);
            showGiveModal.value = false;
        };

        // ---- Player menu (sidebar list) ----
        const showPlayerMenuFn = (player, event) => {
            hidePlayerMenu();
            // Adjust menu position to prevent overflow
            const menuWidth = 200;
            const menuHeight = 280;
            let x = event.clientX;
            let y = event.clientY;
            if (x + menuWidth > window.innerWidth) x = window.innerWidth - menuWidth - 10;
            if (y + menuHeight > window.innerHeight) y = window.innerHeight - menuHeight - 10;
            playerMenu.value = {
                visible: true,
                player,
                x,
                y
            };
        };
        const hidePlayerMenu = () => { playerMenu.value.visible = false; };
        const sendCmdToPlayer = (player, cmd) => {
            hidePlayerMenu();
            sendCmd(`${cmd} ${player.name}`);
        };

        // ---- Map click menu ----
        const hideMapClickMenu = () => {
            mapClickMenu.value.visible = false;
            hoveredRebuildChunk.value = false;
            removeChunkHighlight();
            // Remove click marker when menu closes
            if (clickMarker && map) {
                map.removeLayer(clickMarker);
                clickMarker = null;
            }
        };
        const openShareLocationModal = () => {
            hideMapClickMenu();
            shareCoords.value = `${mapClickMenu.value.coords.x}, ${mapClickMenu.value.coords.z}`;
            shareMessage.value = '';
            shareRecipient.value = '@a';
            showShareModal.value = true;
        };
        const closeShareModal = () => { showShareModal.value = false; };
        const confirmShareLocation = async () => {
            const coords = shareCoords.value;
            const msg = shareMessage.value ? ` (${shareMessage.value})` : '';
            const fullMsg = `[${coords}]${msg}`;
            await sendCmd(`tellraw ${shareRecipient.value} {"text":"${fullMsg}","color":"aqua"}`);
            showShareModal.value = false;
        };
        const openTeleportModal = () => {
            hideMapClickMenu();
            const { x, z, y } = mapClickMenu.value.coords;
            if (y !== undefined && y !== null) {
                teleportCoords.value = `X: ${x}  Y: ${Math.round(y)}  Z: ${z}`;
            } else {
                teleportCoords.value = `X: ${x}  Z: ${z}  (Y: ~)`;
            }
            teleportTarget.value = onlinePlayersList.value[0] || '';
            showTeleportModal.value = true;
        };
        const closeTeleportModal = () => { showTeleportModal.value = false; };
        const confirmTeleport = async () => {
            if (!teleportTarget.value) return;
            const { x, z, y } = mapClickMenu.value.coords;
            if (y !== undefined && y !== null) {
                // 点击玩家/实体 → 使用其Y坐标
                await sendCmd(`tp ${teleportTarget.value} ${x} ${Math.round(y)} ${z}`);
            } else {
                // 点击空白区域 → 使用 spreadplayers 自动寻找安全地面
                await sendCmd(`spreadplayers ${x} ${z} 0 1 false ${teleportTarget.value}`);
            }
            showTeleportModal.value = false;
        };

        // ---- Effect ----
        const askEffect = (player) => {
            hidePlayerMenu();
            effectTargetPlayer.value = player.name;
            selectedEffect.value = 'minecraft:speed';
            effectDuration.value = 600;
            effectLevel.value = 1;
            hideParticles.value = false;
            showEffectModal.value = true;
        };
        const closeEffectModal = () => { showEffectModal.value = false; };
        const confirmGiveEffect = async () => {
            if (!effectTargetPlayer.value) return;
            const amp = Math.max(0, effectLevel.value - 1);
            const hide = hideParticles.value ? 'true' : 'false';
            await sendCmd(`effect give ${effectTargetPlayer.value} ${selectedEffect.value} ${effectDuration.value || 600} ${amp} ${hide}`);
            showEffectModal.value = false;
        };
        const clearAllEffects = async () => {
            if (!effectTargetPlayer.value) return;
            await sendCmd(`effect clear ${effectTargetPlayer.value}`);
            showEffectModal.value = false;
        };

        // ---- Other actions ----
        const askExperience = (player) => {
            hidePlayerMenu();
            openModal({
                title: `${store.lang === 'zh' ? '经验' : 'Experience'} ${player.name}`,
                message: store.lang === 'zh' ? '经验值:' : 'Amount:',
                mode: 'input', inputValue: '100',
                callback: (val) => sendCmd(`experience add ${player.name} ${val}`)
            });
        };
        const askTitle = (player) => {
            hidePlayerMenu();
            openModal({
                title: `${store.lang === 'zh' ? '标题' : 'Title'} ${player.name}`,
                message: store.lang === 'zh' ? '标题内容:' : 'Title text:',
                mode: 'input', inputValue: 'Hello!',
                callback: (val) => sendCmd(`title ${player.name} title "${val.replace(/"/g, '\\"')}"`)
            });
        };
        const askMessage = (player) => {
            hidePlayerMenu();
            openModal({
                title: `${store.lang === 'zh' ? '私信' : 'Message'} ${player.name}`,
                message: store.lang === 'zh' ? '消息内容:' : 'Message:',
                mode: 'input', inputValue: '',
                callback: (val) => sendCmd(`msg ${player.name} ${val}`)
            });
        };
        const askWhitelist = (player) => { sendCmd(`whitelist add ${player.name}`); };
        const askOp = (player) => { sendCmd(`op ${player.name}`); };
        const askDeop = (player) => { sendCmd(`deop ${player.name}`); };
        const askBan = (player) => {
            hidePlayerMenu();
            openModal({
                title: `${store.lang === 'zh' ? '封禁' : 'Ban'} ${player.name}`,
                message: store.lang === 'zh' ? '封禁原因 (可选):' : 'Reason (optional):',
                mode: 'input', inputValue: '',
                callback: (val) => sendCmd(`ban ${player.name}${val ? ' ' + val : ''}`)
            });
        };
        const askBanIp = (player) => {
            hidePlayerMenu();
            openModal({
                title: `${store.lang === 'zh' ? 'IP封禁' : 'Ban IP'} ${player.name}`,
                message: store.lang === 'zh' ? '封禁原因 (可选):' : 'Reason (optional):',
                mode: 'input', inputValue: '',
                callback: (val) => sendCmd(`ban-ip ${player.name}${val ? ' ' + val : ''}`)
            });
        };

        // ---- Watchers ----
        watch(selectedDim, () => { drawMapOverlays().then(() => resetView()); });
        watch(isFullscreen, () => { nextTick(() => { if (map) map.invalidateSize(); }); });
        watch(selectedEnchantment, (v) => {
            const ench = ENCHANTMENTS.find(e => e.id === v);
            if (ench && enchantmentLevel.value > ench.maxLvl) enchantmentLevel.value = ench.maxLvl;
        });
        watch(selectedPotionEffect, (v) => {
            const effect = POTION_EFFECTS.find(e => e.id === v);
            if (effect && effect.variants.length) selectedPotionVariant.value = effect.variants[0].id;
        });

        // ---- Polling ----
        let entityRefreshInterval = null;
        const startPolling = () => {
            stopPolling();
            fetchPlayers();
            fetchEntities();
            // Load entity names for i18n
            api.get('/api/plugins/mc-panel-plugin-map/entity-names').then(res => {
                if (res.data) entityNamesMap.value = res.data;
            }).catch(() => {});
            // Load initial entity settings
            api.get('/api/plugins/mc-panel-plugin-map/entity-settings').then(res => {
                if (res.data) Object.assign(entitySettings.value, res.data);
            }).catch(() => {});
            refreshInterval = setInterval(fetchPlayers, 3000);
            entityRefreshInterval = setInterval(fetchEntities, 5000);
            // Auto-refresh regions every 15s to detect new area files
            regionRefreshInterval = setInterval(() => drawMapOverlays(false), 15000);
        };
        const stopPolling = () => {
            if (refreshInterval) { clearInterval(refreshInterval); refreshInterval = null; }
            if (entityRefreshInterval) { clearInterval(entityRefreshInterval); entityRefreshInterval = null; }
            if (regionRefreshInterval) { clearInterval(regionRefreshInterval); regionRefreshInterval = null; }
        };

        // ---- Lifecycle ----
        onMounted(() => {
            styleEl = document.createElement('style');
            styleEl.id = 'map-plugin-leaflet-styles';
            styleEl.textContent = `
                #leaflet-map { cursor: crosshair; }
                .leaflet-player-marker { background: transparent; border: none; }
                .player-marker-wrapper {
                    position: relative;
                    width: 30px; height: 30px;
                    display: flex; align-items: center; justify-content: center;
                }
                .player-marker-wrapper .pulse-ring {
                    position: absolute; top: 50%; left: 50%;
                    transform: translate(-50%, -50%);
                    width: 34px; height: 34px; border-radius: 50%;
                    opacity: 0.4;
                    animation: radar-pulse 1.8s infinite ease-out;
                    pointer-events: none;
                }
                .player-marker-wrapper .pulse-ring.bg-success { border: 2px solid #198754; }
                .player-marker-wrapper .pulse-ring.bg-secondary { border: 2px solid #6c757d; }
                .player-marker-wrapper .marker-label {
                    position: absolute; top: 100%; left: 50%;
                    transform: translateX(-50%) translateY(4px);
                    background: rgba(0,0,0,0.9);
                    border: 1px solid rgba(255,255,255,0.15);
                    color: #fff; font-size: 9px; padding: 2px 6px;
                    border-radius: 4px; pointer-events: none;
                    opacity: 0; transition: opacity 0.2s;
                    white-space: nowrap; box-shadow: 0 4px 6px rgba(0,0,0,0.3);
                    z-index: 100;
                }
                .player-marker-wrapper:hover .marker-label { opacity: 1; }
                .hover-bg-dark:hover { background-color: rgba(255,255,255,0.03) !important; }
                .leaflet-entity-marker { background: transparent; border: none; }
                .entity-dot { transition: transform 0.15s ease; }
                .entity-dot:hover { transform: scale(1.8); }
                .animate-ping { animation: ping 1.2s cubic-bezier(0, 0, 0.2, 1) infinite; }
                @keyframes radar-pulse {
                    0% { transform: translate(-50%, -50%) scale(0.4); opacity: 0.8; }
                    100% { transform: translate(-50%, -50%) scale(1.6); opacity: 0; }
                }
                @keyframes ping {
                    75%, 100% { transform: scale(2); opacity: 0; }
                }
                .leaflet-container img.leaflet-image-layer { image-rendering: pixelated; }
                .map-fullscreen-root { position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 9998; background: #0b0f19; padding: 0; margin: 0; }
                .map-fullscreen-card { width: 100%; height: 100vh; position: relative; overflow: hidden; background: #0b0f19; }
            `;
            document.head.appendChild(styleEl);

            // Creative inventory CSS
            if (!document.getElementById('map-plugin-creative-inv-style')) {
                const invStyle = document.createElement('style');
                invStyle.id = 'map-plugin-creative-inv-style';
                invStyle.innerHTML = `
                    .mc-tabs-container { width: 100%; }
                    .mc-tabs { background: var(--c-bg-base); border: 1px solid var(--c-border); border-radius: 8px; padding: 4px; display: flex; gap: 6px; overflow-x: auto; white-space: nowrap; width: 100%; }
                    .mc-tabs::-webkit-scrollbar { height: 4px; }
                    .mc-tabs::-webkit-scrollbar-track { background: transparent; }
                    .mc-tabs::-webkit-scrollbar-thumb { background: var(--c-border); border-radius: 2px; }
                    .mc-tab-btn { background: transparent; border: none; color: var(--c-text-secondary); padding: 6px 12px; border-radius: 6px; font-weight: 600; font-size: 0.85rem; transition: all 0.15s ease; white-space: nowrap; }
                    .mc-tab-btn:hover { color: var(--c-text-primary); background: rgba(var(--c-primary-rgb), 0.05); }
                    .mc-tab-btn.active { background: var(--c-primary) !important; color: #fff !important; box-shadow: var(--focus-ring); }
                    .mc-slots-container { background: var(--c-bg-base) !important; border: 1px solid var(--c-border) !important; border-radius: 12px; padding: 10px; height: 290px; overflow-y: auto; }
                    .mc-slots-grid { display: grid; grid-template-columns: repeat(9, 1fr); gap: 8px; }
                    .mc-item-slot { aspect-ratio: 1; background: var(--c-surface); border: 1px solid var(--c-border); display: flex; align-items: center; justify-content: center; cursor: pointer; position: relative; transition: all 0.15s ease; border-radius: 8px; }
                    .mc-item-slot:hover { background: var(--c-bg-base); border-color: var(--c-primary); transform: translateY(-2px); }
                    .mc-item-slot.active { background: var(--c-primary-subtle) !important; border-color: var(--c-primary) !important; border-width: 2px !important; }
                    .mc-item-slot.empty { cursor: default; background: transparent; border: 1px dashed var(--c-border); opacity: 0.25; }
                    .mc-item-slot.empty:hover { background: transparent; transform: none; border-color: var(--c-border); }
                    .mc-item-img { object-fit: contain; image-rendering: pixelated; image-rendering: crisp-edges; user-select: none; filter: drop-shadow(1px 2px 1px rgba(0,0,0,0.3)); transition: transform 0.15s ease, filter 0.15s ease; }
                    .mc-item-slot:hover .mc-item-img { transform: scale(1.12) translateY(-1px); filter: drop-shadow(2px 3px 2px rgba(0,0,0,0.4)); }
                    .mc-item-slot .mc-item-tooltip { visibility: hidden; background: var(--c-surface-elevated); border: 1px solid var(--c-border); color: var(--c-text-primary); text-align: center; border-radius: 8px; padding: 8px 12px; position: absolute; z-index: 1100; bottom: 125%; left: 50%; transform: translateX(-50%); white-space: nowrap; box-shadow: var(--card-shadow-hover); font-size: 0.75rem; line-height: 1.4; }
                    .mc-item-slot:hover .mc-item-tooltip { visibility: visible; }
                    .mc-selection-details { background: var(--c-bg-base) !important; border: 1px solid var(--c-border) !important; border-radius: 12px; }
                    .mc-selected-icon-box { width: 50px; height: 50px; background: var(--c-surface); border: 1px solid var(--c-border); border-radius: 8px; display: flex; align-items: center; justify-content: center; }
                    @media (max-width: 768px) { .mc-slots-grid { grid-template-columns: repeat(6, 1fr); } }
                    @media (max-width: 480px) { .mc-slots-grid { grid-template-columns: repeat(4, 1fr); } }
                `;
                document.head.appendChild(invStyle);
            }

            loadCreativeItems();

            // Start backend tracking when component mounts
            api.post('/api/plugins/mc-panel-plugin-map/start-tracking').catch(() => {});

            // Document-level click listener to close all menus
            docClickHandler = (e) => {
                const menuEl = e.target.closest('.dropdown-menu');
                // Close player menu (sidebar list)
                if (playerMenu.value.visible && !menuEl) hidePlayerMenu();
                // Close map click menu
                if (mapClickMenu.value.visible && !menuEl) hideMapClickMenu();
            };
            document.addEventListener('click', docClickHandler, true);

            loadLeaflet().then(() => {
                initMap();
                drawMapOverlays().then(() => resetView());
                startPolling();
            });
        });

        onUnmounted(() => {
            stopPolling();
            if (biomeTimer) clearTimeout(biomeTimer);
            // Stop backend tracking when component unmounts
            api.post('/api/plugins/mc-panel-plugin-map/stop-tracking').catch(() => {});
            if (docClickHandler) document.removeEventListener('click', docClickHandler, true);
            if (styleEl && styleEl.parentNode) styleEl.parentNode.removeChild(styleEl);
            const invStyle = document.getElementById('map-plugin-creative-inv-style');
            if (invStyle) invStyle.remove();
            // Clean up entity markers
            removeChunkHighlight();
            for (const em of entityMarkers) { try { map?.removeLayer(em.marker); } catch(e){} }
            entityMarkers = [];
            if (map) { map.remove(); map = null; }
        });

        return {
            store, selectedDim, regions, players, rendering, autoRefresh, mouseCoords, dimensionsList,
            forceRebuild, panToPlayer, resetView, isOnline, getDimName, getDimBadgeClass,
            currentBiome, isFullscreen, radarCollapsed,
            // Entity
            entitySettings, entityData, entityCounts, entityCategories, toggleEntityCategory, getEntityName,
            // Player menu (sidebar list)
            playerMenu, showPlayerMenuFn, hidePlayerMenu, sendCmdToPlayer,
            // Map click menu
            mapClickMenu, hideMapClickMenu, openShareLocationModal, openTeleportModal,
            hoveredRebuildChunk, rebuildCurrentChunk, updateChunkHighlight, removeChunkHighlight,
            // Share location
            showShareModal, shareMessage, shareRecipient, shareCoords, onlinePlayersList, closeShareModal, confirmShareLocation,
            // Teleport
            showTeleportModal, teleportTarget, teleportCoords, closeTeleportModal, confirmTeleport,
            // Actions
            sendCmd, askTeleport, askGamemode, askGiveItem, askEffect,
            askExperience, askTitle, askMessage, askWhitelist, askOp, askDeop, askBan, askBanIp,
            // Give item
            showGiveModal, targetPlayer, selectedItem, giveQuantity, itemSearchQuery,
            activeTab, customItemId, tabs: TABS, filteredItems, emptySlotsCount,
            closeGiveModal, selectItem, onCustomIdInput, confirmGiveItem,
            selectedEnchantment, enchantmentLevel, selectedPotionEffect, selectedPotionVariant,
            ENCHANTMENTS, POTION_EFFECTS, currentEnchantmentLevels, currentPotionVariants,
            skullOwner, attachEnchantment, isEnchantable,
            // Effect
            STATUS_EFFECTS, showEffectModal, effectTargetPlayer, selectedEffect,
            effectDuration, effectLevel, hideParticles, closeEffectModal, confirmGiveEffect, clearAllEffects
        };
    }
};
