const path = require('path');
const fs = require('fs-extra');
const express = require('express');
const zlib = require('zlib');
const util = require('util');

const gunzipAsync = util.promisify(zlib.gunzip);
const inflateAsync = util.promisify(zlib.inflate);

// Custom NBT Binary Reader (dependency-free)
class NBTReader {
    constructor(buffer) {
        this.buffer = buffer;
        this.offset = 0;
    }

    readTag() {
        if (this.offset >= this.buffer.length) return { type: 0, name: '', value: null };
        const type = this.buffer[this.offset++];
        if (type === 0) return { type, name: '', value: null };
        const nameLen = this.buffer.readUInt16BE(this.offset);
        this.offset += 2;
        const name = this.buffer.toString('utf8', this.offset, this.offset + nameLen);
        this.offset += nameLen;
        const value = this.readValue(type);
        return { type, name, value };
    }

    readValue(type) {
        switch (type) {
            case 1: return this.buffer.readInt8(this.offset++);
            case 2: { const s = this.buffer.readInt16BE(this.offset); this.offset += 2; return s; }
            case 3: { const i = this.buffer.readInt32BE(this.offset); this.offset += 4; return i; }
            case 4: { const l = this.buffer.readBigInt64BE(this.offset); this.offset += 8; return l; }
            case 5: { const f = this.buffer.readFloatBE(this.offset); this.offset += 4; return f; }
            case 6: { const d = this.buffer.readDoubleBE(this.offset); this.offset += 8; return d; }
            case 7: {
                const baLen = this.buffer.readInt32BE(this.offset); this.offset += 4;
                const ba = this.buffer.subarray(this.offset, this.offset + baLen); this.offset += baLen; return ba;
            }
            case 8: {
                const strLen = this.buffer.readUInt16BE(this.offset); this.offset += 2;
                const str = this.buffer.toString('utf8', this.offset, this.offset + strLen); this.offset += strLen; return str;
            }
            case 9: {
                const elemType = this.buffer[this.offset++];
                const listLen = this.buffer.readInt32BE(this.offset); this.offset += 4;
                const list = [];
                for (let k = 0; k < listLen; k++) list.push(this.readValue(elemType));
                return { type: elemType, value: list };
            }
            case 10: {
                const comp = {};
                while (true) { const tag = this.readTag(); if (tag.type === 0) break; comp[tag.name] = tag.value; }
                return comp;
            }
            case 11: {
                const iaLen = this.buffer.readInt32BE(this.offset); this.offset += 4;
                const ia = [];
                for (let k = 0; k < iaLen; k++) { ia.push(this.buffer.readInt32BE(this.offset)); this.offset += 4; }
                return ia;
            }
            case 12: {
                const laLen = this.buffer.readInt32BE(this.offset); this.offset += 4;
                const la = [];
                for (let k = 0; k < laLen; k++) { la.push(this.buffer.readBigInt64BE(this.offset)); this.offset += 8; }
                return la;
            }
            default: throw new Error('Unknown NBT type ' + type + ' at offset ' + this.offset);
        }
    }
}

function unpackHeightmap(longs) {
    if (!longs || longs.length < 37) return new Array(256).fill(0);
    const values = [];
    const bitsPerValue = 9;
    const mask = (1n << BigInt(bitsPerValue)) - 1n;
    const valPerLong = Math.floor(64 / bitsPerValue);
    for (let i = 0; i < 256; i++) {
        const longIdx = Math.floor(i / valPerLong);
        const valIdx = i % valPerLong;
        const bitOffset = valIdx * bitsPerValue;
        const longVal = BigInt(longs[longIdx]);
        values.push(Number((longVal >> BigInt(bitOffset)) & mask));
    }
    return values;
}

function getBlockName(palette, data, index) {
    if (!palette || !palette.length) return 'minecraft:air';
    if (palette.length === 1) return palette[0].Name || 'minecraft:air';
    if (!data) return palette[0].Name || 'minecraft:air';
    const bitsPerValue = Math.max(4, Math.ceil(Math.log2(palette.length)));
    const valPerLong = Math.floor(64 / bitsPerValue);
    const longIdx = Math.floor(index / valPerLong);
    const valIdx = index % valPerLong;
    const bitOffset = valIdx * bitsPerValue;
    if (longIdx >= data.length) return 'minecraft:air';
    const longVal = BigInt(data[longIdx]);
    const val = (longVal >> BigInt(bitOffset)) & ((1n << BigInt(bitsPerValue)) - 1n);
    const palEntry = palette[Number(val)];
    return palEntry ? palEntry.Name : 'minecraft:air';
}

const BLOCK_COLORS = {
    'minecraft:grass_block': [94, 157, 52], 'minecraft:dirt': [134, 96, 67],
    'minecraft:coarse_dirt': [120, 85, 58], 'minecraft:podzol': [90, 63, 44],
    'minecraft:sand': [219, 211, 160], 'minecraft:sandstone': [216, 203, 155],
    'minecraft:red_sand': [169, 88, 33], 'minecraft:red_sandstone': [169, 88, 33],
    'minecraft:stone': [120, 120, 120], 'minecraft:deepslate': [70, 70, 70],
    'minecraft:cobblestone': [110, 110, 110], 'minecraft:mossy_cobblestone': [90, 110, 80],
    'minecraft:gravel': [136, 126, 125], 'minecraft:clay': [162, 166, 182],
    'minecraft:snow_block': [245, 245, 245], 'minecraft:snow': [245, 245, 245],
    'minecraft:ice': [160, 210, 245], 'minecraft:packed_ice': [140, 190, 240],
    'minecraft:blue_ice': [120, 170, 230], 'minecraft:water': [46, 110, 203],
    'minecraft:lava': [225, 90, 10],
    'minecraft:oak_leaves': [50, 100, 30], 'minecraft:spruce_leaves': [40, 80, 25],
    'minecraft:birch_leaves': [70, 120, 40], 'minecraft:jungle_leaves': [50, 110, 30],
    'minecraft:acacia_leaves': [60, 110, 30], 'minecraft:dark_oak_leaves': [35, 70, 20],
    'minecraft:mangrove_leaves': [45, 95, 28], 'minecraft:cherry_leaves': [235, 170, 190],
    'minecraft:azalea_leaves': [75, 125, 35], 'minecraft:flowering_azalea_leaves': [115, 135, 65],
    'minecraft:oak_planks': [162, 130, 86], 'minecraft:spruce_planks': [100, 78, 51],
    'minecraft:birch_planks': [192, 175, 121], 'minecraft:jungle_planks': [160, 115, 85],
    'minecraft:acacia_planks': [168, 97, 58], 'minecraft:dark_oak_planks': [66, 43, 22],
    'minecraft:cherry_planks': [220, 160, 150], 'minecraft:mangrove_planks': [118, 58, 56],
    'minecraft:bamboo_planks': [180, 165, 90],
    'minecraft:coal_ore': [100, 100, 100], 'minecraft:iron_ore': [130, 120, 110],
    'minecraft:gold_ore': [140, 130, 90], 'minecraft:redstone_ore': [140, 100, 100],
    'minecraft:lapis_ore': [90, 100, 130], 'minecraft:diamond_ore': [100, 130, 130],
    'minecraft:emerald_ore': [100, 130, 100], 'minecraft:copper_ore': [120, 110, 100]
};

function getFallbackColor(name) {
    if (!name) return [94, 157, 52];
    if (name.includes('leaves') || name.includes('sapling') || name.includes('vine')) {
        return name.includes('cherry') ? [235, 170, 190] : [50, 100, 30];
    }
    if (name.includes('grass') || name.includes('moss') || name.includes('fern')) return [94, 157, 52];
    if (name.includes('water')) return [46, 110, 203];
    if (name.includes('lava')) return [225, 90, 10];
    if (name.includes('wood') || name.includes('log') || name.includes('planks') || name.includes('fence') || name.includes('door') || name.includes('stairs') || name.includes('slab')) return [134, 96, 67];
    if (name.includes('sand')) return name.includes('red') ? [169, 88, 33] : [219, 211, 160];
    if (name.includes('stone') || name.includes('cobble') || name.includes('andesite') || name.includes('diorite') || name.includes('granite') || name.includes('ore') || name.includes('basalt') || name.includes('obsidian') || name.includes('tuff')) return (name.includes('redstone') || name.includes('copper')) ? [140, 100, 100] : [120, 120, 120];
    if (name.includes('terracotta') || name.includes('clay')) return [150, 110, 90];
    if (name.includes('wool') || name.includes('concrete') || name.includes('shulker_box')) {
        const colorMap = { white: [220,220,220], orange: [220,120,40], magenta: [180,70,180], light_blue: [100,170,220], yellow: [220,200,40], lime: [110,200,40], pink: [220,140,180], gray: [80,80,80], light_gray: [150,150,150], cyan: [20,120,130], purple: [120,40,160], blue: [40,60,160], brown: [100,60,40], green: [60,100,40], red: [160,40,40], black: [20,20,20] };
        for (const [k, v] of Object.entries(colorMap)) { if (name.includes(k)) return v; }
        return [180, 180, 180];
    }
    if (name.includes('snow') || name.includes('ice')) return [245, 245, 245];
    if (name.includes('air') || name.includes('void')) return null;
    return [100, 140, 80];
}

function generateBMP(width, height, pixelData) {
    const rowSize = Math.floor((24 * width + 31) / 32) * 4;
    const pixelDataSize = rowSize * height;
    const fileSize = 54 + pixelDataSize;
    const fileHeader = Buffer.alloc(14);
    fileHeader.write('BM', 0); fileHeader.writeUInt32LE(fileSize, 2); fileHeader.writeUInt32LE(54, 10);
    const dibHeader = Buffer.alloc(40);
    dibHeader.writeUInt32LE(40, 0); dibHeader.writeInt32LE(width, 4); dibHeader.writeInt32LE(height, 8);
    dibHeader.writeUInt16LE(1, 12); dibHeader.writeUInt16LE(24, 14);
    dibHeader.writeUInt32LE(0, 16); dibHeader.writeUInt32LE(pixelDataSize, 20);
    dibHeader.writeInt32LE(2835, 24); dibHeader.writeInt32LE(2835, 28);
    const buf = Buffer.alloc(fileSize);
    fileHeader.copy(buf, 0); dibHeader.copy(buf, 14);
    let offset = 54;
    for (let y = height - 1; y >= 0; y--) {
        for (let x = 0; x < width; x++) {
            const pixelIdx = (y * width + x) * 3;
            buf[offset++] = pixelData[pixelIdx + 2];
            buf[offset++] = pixelData[pixelIdx + 1];
            buf[offset++] = pixelData[pixelIdx];
        }
        offset += rowSize - (width * 3);
    }
    return buf;
}

module.exports = (api) => {
    // 异步安全读取 levelName 缓存
    const levelNameCache = new Map(); // instanceDir -> levelName
    function getLevelName(instanceDir) {
        if (levelNameCache.has(instanceDir)) return levelNameCache.get(instanceDir);
        try {
            const propPath = path.join(instanceDir, 'server.properties');
            if (fs.existsSync(propPath)) {
                for (const line of fs.readFileSync(propPath, 'utf8').split('\n')) {
                    if (line.trim().startsWith('level-name=')) {
                        const val = line.split('=')[1].trim();
                        levelNameCache.set(instanceDir, val);
                        return val;
                    }
                }
            }
        } catch (e) {}
        levelNameCache.set(instanceDir, 'world');
        return 'world';
    }

    function getRegionPath(instanceDir, dimension) {
        const levelName = getLevelName(instanceDir);
        if (dimension === 'minecraft:the_nether') return path.join(instanceDir, levelName, 'DIM-1', 'region');
        if (dimension === 'minecraft:the_end') return path.join(instanceDir, levelName, 'DIM1', 'region');
        return path.join(instanceDir, levelName, 'region');
    }

    // 纯异步、非阻塞获取区块数据
    async function getChunkNBTAsync(mcaPath, chunkX, chunkZ) {
        let fileHandle;
        try {
            if (!await fs.pathExists(mcaPath)) return null;
            fileHandle = await fs.promises.open(mcaPath, 'r');
            const header = Buffer.alloc(4);
            await fileHandle.read(header, 0, 4, 4 * (chunkX + chunkZ * 32));
            const offset = (header[0] << 16) | (header[1] << 8) | header[2];
            if (offset === 0) return null;
            const lengthBuf = Buffer.alloc(4);
            await fileHandle.read(lengthBuf, 0, 4, offset * 4096);
            const length = lengthBuf.readUInt32BE(0);
            if (length <= 1) return null;
            const meta = Buffer.alloc(1);
            await fileHandle.read(meta, 0, 1, offset * 4096 + 4);
            const compressedData = Buffer.alloc(length - 1);
            await fileHandle.read(compressedData, 0, length - 1, offset * 4096 + 5);
            if (meta[0] === 1) return await gunzipAsync(compressedData);
            if (meta[0] === 2) return await inflateAsync(compressedData);
            return null;
        } catch (e) {
            return null;
        } finally {
            if (fileHandle) {
                try { await fileHandle.close(); } catch (err) {}
            }
        }
    }

    // ==================== Entity Categories ====================
    const ENTITY_CATEGORIES = {
        friendly: {
            zh: '友好生物', en: 'Friendly', color: '#10b981',
            types: ['cow', 'sheep', 'pig', 'chicken', 'rabbit', 'villager', 'horse', 'donkey', 'mule', 'fox', 'bee', 'cat', 'parrot', 'axolotl', 'goat', 'frog', 'allay', 'armadillo', 'dolphin', 'squid', 'glow_squid', 'turtle', 'mooshroom', 'llama', 'panda', 'strider', 'tadpole', 'sniffer', 'camel']
        },
        neutral: {
            zh: '中立生物', en: 'Neutral', color: '#f59e0b',
            types: ['wolf', 'enderman', 'iron_golem', 'snow_golem', 'piglin', 'zombified_piglin', 'dolphin', 'llama', 'trader_llama', 'polar_bear', 'bee', 'fox', 'goat', 'panda', 'spider', 'cave_spider']
        },
        hostile: {
            zh: '敌对生物', en: 'Hostile', color: '#ef4444',
            types: ['zombie', 'skeleton', 'creeper', 'witch', 'slime', 'phantom', 'blaze', 'ghast', 'magma_cube', 'wither_skeleton', 'stray', 'husk', 'drowned', 'pillager', 'vindicator', 'ravager', 'evoker', 'guardian', 'elder_guardian', 'shulker', 'silverfish', 'endermite', 'bogged', 'breeze', 'warden', 'hoglin', 'piglin_brute', 'creaking']
        }
    };

    // ==================== Entity Names i18n ====================
    const ENTITY_NAMES = {
        // Friendly
        'cow': { zh: '牛', en: 'Cow' },
        'sheep': { zh: '羊', en: 'Sheep' },
        'pig': { zh: '猪', en: 'Pig' },
        'chicken': { zh: '鸡', en: 'Chicken' },
        'rabbit': { zh: '兔子', en: 'Rabbit' },
        'villager': { zh: '村民', en: 'Villager' },
        'horse': { zh: '马', en: 'Horse' },
        'donkey': { zh: '驴', en: 'Donkey' },
        'mule': { zh: '骡', en: 'Mule' },
        'fox': { zh: '狐狸', en: 'Fox' },
        'bee': { zh: '蜜蜂', en: 'Bee' },
        'cat': { zh: '猫', en: 'Cat' },
        'parrot': { zh: '鹦鹉', en: 'Parrot' },
        'axolotl': { zh: '美西螈', en: 'Axolotl' },
        'goat': { zh: '山羊', en: 'Goat' },
        'frog': { zh: '青蛙', en: 'Frog' },
        'allay': { zh: '悦灵', en: 'Allay' },
        'armadillo': { zh: '犰狳', en: 'Armadillo' },
        'dolphin': { zh: '海豚', en: 'Dolphin' },
        'squid': { zh: '鱿鱼', en: 'Squid' },
        'glow_squid': { zh: '发光鱿鱼', en: 'Glow Squid' },
        'turtle': { zh: '海龟', en: 'Turtle' },
        'mooshroom': { zh: '哞菇', en: 'Mooshroom' },
        'llama': { zh: '羊驼', en: 'Llama' },
        'panda': { zh: '熊猫', en: 'Panda' },
        'strider': { zh: '炽足兽', en: 'Strider' },
        'tadpole': { zh: '蝌蚪', en: 'Tadpole' },
        'sniffer': { zh: '嗅探兽', en: 'Sniffer' },
        'camel': { zh: '骆驼', en: 'Camel' },
        // Neutral
        'wolf': { zh: '狼', en: 'Wolf' },
        'enderman': { zh: '末影人', en: 'Enderman' },
        'iron_golem': { zh: '铁傀儡', en: 'Iron Golem' },
        'snow_golem': { zh: '雪傀儡', en: 'Snow Golem' },
        'piglin': { zh: '猪灵', en: 'Piglin' },
        'zombified_piglin': { zh: '僵尸猪灵', en: 'Zombified Piglin' },
        'trader_llama': { zh: '行商羊驼', en: 'Trader Llama' },
        'polar_bear': { zh: '北极熊', en: 'Polar Bear' },
        'spider': { zh: '蜘蛛', en: 'Spider' },
        'cave_spider': { zh: '洞穴蜘蛛', en: 'Cave Spider' },
        // Hostile
        'zombie': { zh: '僵尸', en: 'Zombie' },
        'skeleton': { zh: '骷髅', en: 'Skeleton' },
        'creeper': { zh: '爬行者', en: 'Creeper' },
        'witch': { zh: '女巫', en: 'Witch' },
        'slime': { zh: '史莱姆', en: 'Slime' },
        'phantom': { zh: '幻翼', en: 'Phantom' },
        'blaze': { zh: '烈焰人', en: 'Blaze' },
        'ghast': { zh: '恶魂', en: 'Ghast' },
        'magma_cube': { zh: '岩浆怪', en: 'Magma Cube' },
        'wither_skeleton': { zh: '凋零骷髅', en: 'Wither Skeleton' },
        'stray': { zh: '流浪者', en: 'Stray' },
        'husk': { zh: '尸壳', en: 'Husk' },
        'drowned': { zh: '溺尸', en: 'Drowned' },
        'pillager': { zh: '掠夺者', en: 'Pillager' },
        'vindicator': { zh: '卫道士', en: 'Vindicator' },
        'ravager': { zh: '劫掠兽', en: 'Ravager' },
        'evoker': { zh: '唤魔者', en: 'Evoker' },
        'guardian': { zh: '守卫者', en: 'Guardian' },
        'elder_guardian': { zh: '远古守卫者', en: 'Elder Guardian' },
        'shulker': { zh: '潜影贝', en: 'Shulker' },
        'silverfish': { zh: '蠹虫', en: 'Silverfish' },
        'endermite': { zh: '末影螨', en: 'Endermite' },
        'bogged': { zh: '沼骸', en: 'Bogged' },
        'breeze': { zh: '旋风人', en: 'Breeze' },
        'warden': { zh: '监守者', en: 'Warden' },
        'hoglin': { zh: '疣猪兽', en: 'Hoglin' },
        'piglin_brute': { zh: '猪灵蛮兵', en: 'Piglin Brute' },
        'creaking': { zh: '嘎枝', en: 'Creaking' }
    };

    // ==================== Real-time Position Tracking ====================
    const positionCache = new Map(); // name -> { x, y, z, dimension, health, foodLevel, timestamp }
    let positionQueryInterval = null;
    let unsubscribeLog = null;

    // Entity position tracking
    const entityCache = new Map(); // category -> [{ type, x, y, z, timestamp }]
    let entityQueryInterval = null;
    const entitySettings = { friendly: true, neutral: false, hostile: false };

    // 内存缓存: 玩家数据 (.dat 文件 mtime 缓存)
    const playerDataCache = new Map(); // uuid -> { mtime, data }
    const userCacheMemory = { mtime: 0, mapping: {} };

    // 内存缓存: 生物群系 (instanceId_dim_chunkX_chunkZ -> biome)
    const biomeCache = new Map();
    const MAX_BIOME_CACHE = 2000;

    // 渲染并发控制队列 (限制同时仅处理 1 个区域渲染，避免挤爆 CPU)
    let activeRenders = 0;
    const MAX_CONCURRENT_RENDERS = 1;
    const renderQueue = [];
    const inProgressRenders = new Map(); // key -> Promise

    function acquireRenderSlot() {
        return new Promise((resolve) => {
            if (activeRenders < MAX_CONCURRENT_RENDERS) {
                activeRenders++;
                resolve();
            } else {
                renderQueue.push(resolve);
            }
        });
    }

    function releaseRenderSlot() {
        if (renderQueue.length > 0) {
            const next = renderQueue.shift();
            next();
        } else {
            activeRenders = Math.max(0, activeRenders - 1);
        }
    }

    const startPositionTracking = () => {
        if (positionQueryInterval) return;

        const lastHealthTime = new Map(); // name -> timestamp

        // 监听控制台日志（加入快速前缀过滤，避免无谓正则计算）
        unsubscribeLog = api.onLog((instanceId, msg) => {
            if (!msg || typeof msg !== 'string' || !msg.includes('has the following entity data:')) return;

            let onlineNames = [];
            try { onlineNames = api.getOnlinePlayers(instanceId); } catch (e) {}
            const onlineSet = new Set(onlineNames);

            // Match position: "Name has the following entity data: [1.5d, 64.0d, 100.3d]"
            const posMatch = msg.match(/([\w:]+)\s+has the following entity data:\s*\[(-?[\d.]+)d,\s*(-?[\d.]+)d,\s*(-?[\d.]+)d\]/);
            if (posMatch) {
                const name = posMatch[1];
                const x = parseFloat(posMatch[2]);
                const y = parseFloat(posMatch[3]);
                const z = parseFloat(posMatch[4]);

                if (onlineSet.has(name)) {
                    const cached = positionCache.get(name) || {};
                    positionCache.set(name, {
                        x, y, z,
                        dimension: cached.dimension || 'minecraft:overworld',
                        health: cached.health ?? null,
                        foodLevel: cached.foodLevel ?? null,
                        timestamp: Date.now()
                    });
                } else {
                    const typeName = name.includes(':') ? name.split(':')[1].toLowerCase() : name.toLowerCase();
                    let category = null;
                    for (const [cat, def] of Object.entries(ENTITY_CATEGORIES)) {
                        if (def.types.includes(typeName)) { category = cat; break; }
                    }
                    if (category) {
                        if (!entityCache.has(category)) entityCache.set(category, []);
                        const list = entityCache.get(category);
                        list.push({ type: typeName, x, y, z, timestamp: Date.now() });
                        if (list.length > 100) list.splice(0, list.length - 100);
                    }
                }
            }

            // Match Health: "PlayerName has the following entity data: 20.0f"
            const healthMatch = msg.match(/(\w+)\s+has the following entity data:\s*([\d.]+)f\b/);
            if (healthMatch && onlineSet.has(healthMatch[1])) {
                const name = healthMatch[1];
                const health = parseFloat(healthMatch[2]);
                const cached = positionCache.get(name);
                if (cached) {
                    cached.health = health;
                    lastHealthTime.set(name, Date.now());
                }
            }

            // Match foodLevel: "PlayerName has the following entity data: 20"
            const foodMatch = msg.match(/(\w+)\s+has the following entity data:\s*(\d+)\s*$/);
            if (foodMatch && onlineSet.has(foodMatch[1])) {
                const name = foodMatch[1];
                const value = parseInt(foodMatch[2], 10);
                if (value >= 0 && value <= 20 && lastHealthTime.has(name) && Date.now() - lastHealthTime.get(name) < 3000) {
                    const cached = positionCache.get(name);
                    if (cached) cached.foodLevel = value;
                }
            }

            // Match dimension: "PlayerName has the following entity data: 'minecraft:overworld'"
            const dimMatch = msg.match(/(\w+)\s+has the following entity data:\s*'?(minecraft:\w+)'?/);
            if (dimMatch) {
                const name = dimMatch[1];
                const dim = dimMatch[2];
                const cached = positionCache.get(name);
                if (cached) cached.dimension = dim;
            }
        });

        // 适度轮询玩家坐标 (5s)
        positionQueryInterval = setInterval(() => {
            const instanceId = api.getActiveInstanceId();
            try {
                const onlinePlayers = api.getOnlinePlayers(instanceId);
                if (!onlinePlayers.length) return;
                let delay = 0;
                for (const player of onlinePlayers) {
                    setTimeout(() => { api.sendCommand(instanceId, `data get entity ${player} Pos`); }, delay);
                    setTimeout(() => { api.sendCommand(instanceId, `data get entity ${player} Health`); }, delay + 100);
                    setTimeout(() => { api.sendCommand(instanceId, `data get entity ${player} foodLevel`); }, delay + 200);
                    delay += 400;
                }
            } catch (e) {}
        }, 5000);

        // 实体轮询 (10s)
        entityQueryInterval = setInterval(() => {
            const instanceId = api.getActiveInstanceId();
            try {
                for (const [cat] of entityCache) entityCache.set(cat, []);
                let delay = 0;
                for (const [category, def] of Object.entries(ENTITY_CATEGORIES)) {
                    if (!entitySettings[category]) continue;
                    const typesToQuery = def.types.slice(0, 5);
                    for (const type of typesToQuery) {
                        setTimeout(() => {
                            const cmd = `execute as @e[type=minecraft:${type},limit=16] run data get entity @s Pos`;
                            api.sendCommand(instanceId, cmd);
                        }, delay);
                        delay += 150;
                    }
                }
            } catch (e) {}
        }, 10000);
    };

    // ==================== Routes ====================
    const router = express.Router();

    // 异步获取 region 列表
    router.get('/regions', async (req, res) => {
        try {
            const instanceId = req.query.instanceId || api.getActiveInstanceId();
            const instanceDir = api.getInstanceDir(instanceId);
            const regionPath = getRegionPath(instanceDir, req.query.dimension || 'minecraft:overworld');
            if (!await fs.pathExists(regionPath)) return res.json([]);
            const files = await fs.readdir(regionPath);
            const mcaFiles = files.filter(f => /^r\.-?\d+\.-?\d+\.mca$/.test(f));

            const list = await Promise.all(mcaFiles.map(async (f) => {
                const parts = f.split('.');
                const stat = await fs.stat(path.join(regionPath, f)).catch(() => ({ mtimeMs: 0 }));
                return { file: f, x: parseInt(parts[1], 10), z: parseInt(parts[2], 10), mtime: stat.mtimeMs };
            }));
            res.json(list);
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // 异步分片 + 队列渲染 512x512 区域地图
    router.get('/render', async (req, res) => {
        try {
            const instanceId = req.query.instanceId || api.getActiveInstanceId();
            const dimension = req.query.dimension || 'minecraft:overworld';
            const region = req.query.region;
            if (!region) return res.status(400).send('Missing region parameter');

            const instanceDir = api.getInstanceDir(instanceId);
            const mcaPath = path.join(getRegionPath(instanceDir, dimension), region);
            if (!await fs.pathExists(mcaPath)) return res.status(404).send('Region file not found');

            const cacheDir = path.join(api.getDataDir(), 'map_cache');
            await fs.ensureDir(cacheDir);
            const stat = await fs.stat(mcaPath);
            const mcaMtime = stat.mtimeMs;
            const cacheFile = path.join(cacheDir, `${instanceId}_${dimension.replace(/:/g, '_')}_${region}.bmp`);

            // 优先直接命中磁盘缓存
            if (await fs.pathExists(cacheFile) && !req.query.force) {
                const cacheStat = await fs.stat(cacheFile);
                if (cacheStat.mtimeMs >= mcaMtime) {
                    return res.sendFile(cacheFile);
                }
            }

            const renderKey = `${instanceId}_${dimension}_${region}_${req.query.force ? Date.now() : ''}`;
            if (inProgressRenders.has(renderKey)) {
                const bmpBuffer = await inProgressRenders.get(renderKey);
                res.setHeader('Content-Type', 'image/bmp');
                return res.send(bmpBuffer);
            }

            const renderPromise = (async () => {
                await acquireRenderSlot();
                try {
                    // 二次检查缓存
                    if (await fs.pathExists(cacheFile) && !req.query.force) {
                        const cacheStat = await fs.stat(cacheFile);
                        if (cacheStat.mtimeMs >= mcaMtime) {
                            return await fs.readFile(cacheFile);
                        }
                    }

                    const size = 512;
                    const heightMap = new Array(size * size).fill(62);
                    const colorMap = new Array(size * size).fill(null);

                    for (let cz = 0; cz < 32; cz++) {
                        for (let cx = 0; cx < 32; cx++) {
                            const decompressed = await getChunkNBTAsync(mcaPath, cx, cz);
                            if (!decompressed) continue;
                            try {
                                const nbt = new NBTReader(decompressed).readTag().value;
                                if (!nbt) continue;
                                const heightmaps = nbt.Heightmaps || nbt.Level?.Heightmaps;
                                if (!heightmaps) continue;
                                const longs = heightmaps.WORLD_SURFACE || heightmaps.MOTION_BLOCKING;
                                if (!longs) continue;
                                const unpacked = unpackHeightmap(longs);
                                const sections = nbt.sections || nbt.Level?.Sections || nbt.Sections;
                                const sectionsMap = {};
                                if (sections?.value) for (const sec of sections.value) sectionsMap[Number(sec.Y)] = sec;

                                for (let z = 0; z < 16; z++) {
                                    for (let x = 0; x < 16; x++) {
                                        const globalX = cx * 16 + x;
                                        const globalZ = cz * 16 + z;
                                        const indexInMap = globalZ * size + globalX;
                                        const rawH = unpacked[z * 16 + x];
                                        const hasNeg = Object.keys(sectionsMap).some(y => parseInt(y, 10) < 0);
                                        const Y = rawH - 1 - (hasNeg ? 64 : 0);
                                        heightMap[indexInMap] = Y;

                                        let finalColor = [46, 110, 203];
                                        for (let depth = 0; depth < 16; depth++) {
                                            const currentY = Y - depth;
                                            if (currentY < -64) break;
                                            const secY = Math.floor(currentY / 16);
                                            const yOffset = ((currentY % 16) + 16) % 16;
                                            const sec = sectionsMap[secY];
                                            if (sec?.block_states) {
                                                const palette = sec.block_states.palette?.value || sec.block_states.palette;
                                                const data = sec.block_states.data;
                                                const idx = yOffset * 256 + z * 16 + x;
                                                const blockName = getBlockName(palette, data, idx);
                                                if (blockName !== 'minecraft:air' && blockName !== 'minecraft:cave_air' && blockName !== 'minecraft:void_air') {
                                                    const c = BLOCK_COLORS[blockName] || getFallbackColor(blockName);
                                                    if (c) { finalColor = c; break; }
                                                }
                                            }
                                        }
                                        colorMap[indexInMap] = finalColor;
                                    }
                                }
                            } catch (err) {}
                        }
                        // 每行让出一次 Node.js 事件循环，确保主线程不阻塞
                        await new Promise(resolve => setImmediate(resolve));
                    }

                    const pixelData = Buffer.alloc(size * size * 3);
                    for (let z = 0; z < size; z++) {
                        for (let x = 0; x < size; x++) {
                            const idx = z * size + x;
                            const y = heightMap[idx];
                            const yLeft = x > 0 ? heightMap[z * size + (x - 1)] : y;
                            let baseColor = colorMap[idx] || [0, 0, 0];
                            const slope = (y - yLeft) * 8;
                            const r = Math.max(0, Math.min(255, baseColor[0] + slope));
                            const g = Math.max(0, Math.min(255, baseColor[1] + slope));
                            const b = Math.max(0, Math.min(255, baseColor[2] + slope));
                            const pixelIdx = idx * 3;
                            pixelData[pixelIdx] = r; pixelData[pixelIdx + 1] = g; pixelData[pixelIdx + 2] = b;
                        }
                    }

                    const bmpBuffer = generateBMP(size, size, pixelData);
                    await fs.writeFile(cacheFile, bmpBuffer);
                    return bmpBuffer;
                } finally {
                    releaseRenderSlot();
                }
            })();

            inProgressRenders.set(renderKey, renderPromise);
            try {
                const bmpBuffer = await renderPromise;
                res.setHeader('Content-Type', 'image/bmp');
                res.send(bmpBuffer);
            } finally {
                inProgressRenders.delete(renderKey);
            }
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // 异步渲染单个区块 (16x16)
    router.get('/chunk-render', async (req, res) => {
        try {
            const instanceId = req.query.instanceId || api.getActiveInstanceId();
            const dimension = req.query.dimension || 'minecraft:overworld';
            const chunkX = parseInt(req.query.chunkX, 10);
            const chunkZ = parseInt(req.query.chunkZ, 10);
            if (isNaN(chunkX) || isNaN(chunkZ)) return res.status(400).send('Missing or invalid chunkX/chunkZ parameters');

            const regionX = Math.floor(chunkX / 32);
            const regionZ = Math.floor(chunkZ / 32);
            const localCX = ((chunkX % 32) + 32) % 32;
            const localCZ = ((chunkZ % 32) + 32) % 32;
            const regionFile = `r.${regionX}.${regionZ}.mca`;

            const instanceDir = api.getInstanceDir(instanceId);
            const mcaPath = path.join(getRegionPath(instanceDir, dimension), regionFile);
            if (!await fs.pathExists(mcaPath)) return res.status(404).send('Region file not found');

            const cacheDir = path.join(api.getDataDir(), 'map_cache');
            await fs.ensureDir(cacheDir);
            const stat = await fs.stat(mcaPath);
            const mcaMtime = stat.mtimeMs;
            const cacheFile = path.join(cacheDir, `${instanceId}_${dimension.replace(/:/g, '_')}_${chunkX}_${chunkZ}.bmp`);

            if (await fs.pathExists(cacheFile) && !req.query.force) {
                const cacheStat = await fs.stat(cacheFile);
                if (cacheStat.mtimeMs >= mcaMtime) {
                    return res.sendFile(cacheFile);
                }
            }

            const decompressed = await getChunkNBTAsync(mcaPath, localCX, localCZ);
            if (!decompressed) return res.status(404).send('Chunk data not found');

            const size = 16;
            const heightMap = new Array(size * size).fill(62);
            const colorMap = new Array(size * size).fill(null);

            try {
                const nbt = new NBTReader(decompressed).readTag().value;
                if (!nbt) return res.status(404).send('Chunk NBT parse failed');
                const heightmaps = nbt.Heightmaps || nbt.Level?.Heightmaps;
                if (!heightmaps) return res.status(404).send('No heightmap data');
                const longs = heightmaps.WORLD_SURFACE || heightmaps.MOTION_BLOCKING;
                if (!longs) return res.status(404).send('No heightmap longs');
                const unpacked = unpackHeightmap(longs);
                const sections = nbt.sections || nbt.Level?.Sections || nbt.Sections;
                const sectionsMap = {};
                if (sections?.value) for (const sec of sections.value) sectionsMap[Number(sec.Y)] = sec;

                for (let z = 0; z < 16; z++) {
                    for (let x = 0; x < 16; x++) {
                        const indexInMap = z * size + x;
                        const rawH = unpacked[z * 16 + x];
                        const hasNeg = Object.keys(sectionsMap).some(y => parseInt(y, 10) < 0);
                        const Y = rawH - 1 - (hasNeg ? 64 : 0);
                        heightMap[indexInMap] = Y;

                        let finalColor = [46, 110, 203];
                        for (let depth = 0; depth < 16; depth++) {
                            const currentY = Y - depth;
                            if (currentY < -64) break;
                            const secY = Math.floor(currentY / 16);
                            const yOffset = ((currentY % 16) + 16) % 16;
                            const sec = sectionsMap[secY];
                            if (sec?.block_states) {
                                const palette = sec.block_states.palette?.value || sec.block_states.palette;
                                const data = sec.block_states.data;
                                const idx = yOffset * 256 + z * 16 + x;
                                const blockName = getBlockName(palette, data, idx);
                                if (blockName !== 'minecraft:air' && blockName !== 'minecraft:cave_air' && blockName !== 'minecraft:void_air') {
                                    const c = BLOCK_COLORS[blockName] || getFallbackColor(blockName);
                                    if (c) { finalColor = c; break; }
                                }
                            }
                        }
                        colorMap[indexInMap] = finalColor;
                    }
                }
            } catch (err) {
                return res.status(500).json({ error: 'Chunk render failed: ' + err.message });
            }

            const pixelData = Buffer.alloc(size * size * 3);
            for (let z = 0; z < size; z++) {
                for (let x = 0; x < size; x++) {
                    const idx = z * size + x;
                    const y = heightMap[idx];
                    const yLeft = x > 0 ? heightMap[z * size + (x - 1)] : y;
                    let baseColor = colorMap[idx] || [0, 0, 0];
                    const slope = (y - yLeft) * 8;
                    const r = Math.max(0, Math.min(255, baseColor[0] + slope));
                    const g = Math.max(0, Math.min(255, baseColor[1] + slope));
                    const b = Math.max(0, Math.min(255, baseColor[2] + slope));
                    const pixelIdx = idx * 3;
                    pixelData[pixelIdx] = r; pixelData[pixelIdx + 1] = g; pixelData[pixelIdx + 2] = b;
                }
            }

            const bmpBuffer = generateBMP(size, size, pixelData);
            await fs.writeFile(cacheFile, bmpBuffer);
            res.setHeader('Content-Type', 'image/bmp');
            res.send(bmpBuffer);
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // 带内存缓存的生物群系提取
    router.get('/biome', async (req, res) => {
        try {
            const instanceId = req.query.instanceId || api.getActiveInstanceId();
            const dimension = req.query.dimension || 'minecraft:overworld';
            const x = parseInt(req.query.x, 10);
            const z = parseInt(req.query.z, 10);
            if (isNaN(x) || isNaN(z)) return res.status(400).send('Missing or invalid x/z parameters');

            const chunkX = Math.floor(x / 16);
            const chunkZ = Math.floor(z / 16);
            const localX = ((x % 16) + 16) % 16;
            const localZ = ((z % 16) + 16) % 16;

            const cacheKey = `${instanceId}_${dimension}_${chunkX}_${chunkZ}`;
            if (biomeCache.has(cacheKey)) {
                return res.json({ biome: biomeCache.get(cacheKey) });
            }

            const regionX = Math.floor(chunkX / 32);
            const regionZ = Math.floor(chunkZ / 32);
            const localCX = ((chunkX % 32) + 32) % 32;
            const localCZ = ((chunkZ % 32) + 32) % 32;
            const regionFile = `r.${regionX}.${regionZ}.mca`;

            const instanceDir = api.getInstanceDir(instanceId);
            const mcaPath = path.join(getRegionPath(instanceDir, dimension), regionFile);
            if (!await fs.pathExists(mcaPath)) return res.status(404).json({ error: 'Region file not found' });

            const decompressed = await getChunkNBTAsync(mcaPath, localCX, localCZ);
            if (!decompressed) return res.status(404).json({ error: 'Chunk data not found' });

            try {
                const nbt = new NBTReader(decompressed).readTag().value;
                if (!nbt) return res.status(404).json({ error: 'Chunk NBT parse failed' });

                const sections = nbt.sections || nbt.Level?.Sections || nbt.Level?.Sections;
                let foundBiome = null;

                if (sections?.value) {
                    const heightmaps = nbt.Heightmaps || nbt.Level?.Heightmaps;
                    let surfaceY = 0;
                    if (heightmaps) {
                        const longs = heightmaps.WORLD_SURFACE || heightmaps.MOTION_BLOCKING;
                        if (longs) {
                            const unpacked = unpackHeightmap(longs);
                            surfaceY = unpacked[localZ * 16 + localX] - 1;
                            const sectionsMap = {};
                            for (const sec of sections.value) sectionsMap[Number(sec.Y)] = sec;
                            const hasNeg = Object.keys(sectionsMap).some(y => parseInt(y, 10) < 0);
                            if (hasNeg) surfaceY -= 64;
                        }
                    }

                    const secY = Math.floor(surfaceY / 16);
                    for (let offset = 0; offset < 40; offset++) {
                        const candidates = [secY - offset];
                        if (offset > 0) candidates.push(secY + offset);
                        for (const testSecY of candidates) {
                            const sec = sections.value.find(s => Number(s.Y) === testSecY);
                            if (sec?.biomes) {
                                const palette = sec.biomes.palette;
                                const paletteArr = palette?.value || palette;
                                if (paletteArr && paletteArr.length > 0) {
                                    if (paletteArr.length === 1) {
                                        foundBiome = paletteArr[0];
                                        break;
                                    }
                                    const data = sec.biomes.data;
                                    if (data) {
                                        const bx = Math.floor(localX / 4);
                                        const bz = Math.floor(localZ / 4);
                                        const by = Math.floor(((surfaceY % 16) + 16) % 16 / 4);
                                        const biomeBitsPerValue = Math.max(1, Math.ceil(Math.log2(paletteArr.length)));
                                        const biomeValPerLong = Math.floor(64 / biomeBitsPerValue);
                                        const biomeIdx = by * 16 + bz * 4 + bx;
                                        const longIdx = Math.floor(biomeIdx / biomeValPerLong);
                                        const valIdx = biomeIdx % biomeValPerLong;
                                        const bitOffset = valIdx * biomeBitsPerValue;
                                        if (longIdx < data.length) {
                                            const longVal = BigInt(data[longIdx]);
                                            const val = Number((longVal >> BigInt(bitOffset)) & ((1n << BigInt(biomeBitsPerValue)) - 1n));
                                            if (val < paletteArr.length) {
                                                foundBiome = paletteArr[val];
                                                break;
                                            }
                                        }
                                    }
                                    foundBiome = paletteArr[0];
                                    break;
                                }
                            }
                        }
                        if (foundBiome) break;
                    }
                }

                if (!foundBiome) {
                    const levelBiomes = nbt.Level?.Biomes || nbt.Biomes;
                    if (levelBiomes) {
                        if (Array.isArray(levelBiomes) && levelBiomes.length >= 256) {
                            const biomeId = levelBiomes[localZ * 16 + localX];
                            const BIOME_ID_MAP = {
                                0: 'minecraft:ocean', 1: 'minecraft:plains', 2: 'minecraft:desert',
                                3: 'minecraft:mountains', 4: 'minecraft:forest', 5: 'minecraft:taiga',
                                6: 'minecraft:swamp', 7: 'minecraft:river', 8: 'minecraft:nether_wastes',
                                9: 'minecraft:the_end', 10: 'minecraft:frozen_ocean', 11: 'minecraft:frozen_river',
                                12: 'minecraft:snowy_tundra', 13: 'minecraft:snowy_mountains',
                                14: 'minecraft:mushroom_fields', 15: 'minecraft:mushroom_field_shore',
                                16: 'minecraft:beach', 17: 'minecraft:desert_hills', 18: 'minecraft:wooded_hills',
                                19: 'minecraft:taiga_hills', 20: 'minecraft:mountain_edge', 21: 'minecraft:jungle',
                                22: 'minecraft:jungle_hills', 23: 'minecraft:jungle_edge', 24: 'minecraft:deep_ocean',
                                25: 'minecraft:stone_shore', 26: 'minecraft:snowy_beach', 27: 'minecraft:birch_forest',
                                28: 'minecraft:birch_forest_hills', 29: 'minecraft:dark_forest',
                                30: 'minecraft:snowy_taiga', 31: 'minecraft:snowy_taiga_hills',
                                32: 'minecraft:giant_tree_taiga', 33: 'minecraft:giant_tree_taiga_hills',
                                34: 'minecraft:wooded_mountains', 35: 'minecraft:savanna',
                                36: 'minecraft:savanna_plateau', 37: 'minecraft:badlands',
                                38: 'minecraft:wooded_badlands_plateau', 39: 'minecraft:badlands_plateau',
                                40: 'minecraft:small_end_islands', 41: 'minecraft:end_midlands',
                                42: 'minecraft:end_highlands', 43: 'minecraft:end_barrens',
                                44: 'minecraft:warm_ocean', 45: 'minecraft:lukewarm_ocean',
                                46: 'minecraft:cold_ocean', 47: 'minecraft:deep_warm_ocean',
                                48: 'minecraft:deep_lukewarm_ocean', 49: 'minecraft:deep_cold_ocean',
                                50: 'minecraft:deep_frozen_ocean', 127: 'minecraft:the_void',
                                129: 'minecraft:sunflower_plains', 130: 'minecraft:desert_lakes',
                                131: 'minecraft:gravelly_mountains', 132: 'minecraft:flower_forest',
                                133: 'minecraft:taiga_mountains', 134: 'minecraft:swamp_hills',
                                140: 'minecraft:ice_spikes', 149: 'minecraft:modified_jungle',
                                151: 'minecraft:modified_jungle_edge', 155: 'minecraft:tall_birch_forest',
                                156: 'minecraft:tall_birch_hills', 157: 'minecraft:dark_forest_hills',
                                158: 'minecraft:snowy_taiga_mountains', 160: 'minecraft:giant_spruce_taiga',
                                161: 'minecraft:giant_spruce_taiga_hills', 163: 'minecraft:shattered_savanna',
                                164: 'minecraft:shattered_savanna_plateau', 165: 'minecraft:eroded_badlands',
                                166: 'minecraft:modified_wooded_badlands_plateau', 167: 'minecraft:modified_badlands_plateau'
                            };
                            foundBiome = BIOME_ID_MAP[biomeId] || `unknown_biome_id_${biomeId}`;
                        }
                    }
                }

                if (foundBiome) {
                    if (biomeCache.size >= MAX_BIOME_CACHE) {
                        const firstKey = biomeCache.keys().next().value;
                        biomeCache.delete(firstKey);
                    }
                    biomeCache.set(cacheKey, foundBiome);
                    return res.json({ biome: foundBiome });
                }

                res.json({ biome: null, error: 'No biome data found in chunk' });
            } catch (err) {
                res.status(500).json({ error: 'Biome extraction failed: ' + err.message });
            }
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // 内存 mtime 缓存优化玩家数据接口
    router.get('/players', async (req, res) => {
        try {
            const instanceId = req.query.instanceId || api.getActiveInstanceId();
            const instanceDir = api.getInstanceDir(instanceId);
            const levelName = getLevelName(instanceDir);
            const playerdataDir = path.join(instanceDir, levelName, 'playerdata');
            const userCacheFile = path.join(instanceDir, 'usercache.json');

            let uuidToName = {};
            if (await fs.pathExists(userCacheFile)) {
                try {
                    const uStat = await fs.stat(userCacheFile);
                    if (userCacheMemory.mtime === uStat.mtimeMs) {
                        uuidToName = userCacheMemory.mapping;
                    } else {
                        const list = await fs.readJson(userCacheFile);
                        const map = {};
                        for (const entry of list) {
                            if (entry.uuid && entry.name) map[entry.uuid] = entry.name;
                        }
                        userCacheMemory.mtime = uStat.mtimeMs;
                        userCacheMemory.mapping = map;
                        uuidToName = map;
                    }
                } catch (e) {}
            }

            const datPlayers = [];
            if (await fs.pathExists(playerdataDir)) {
                const files = await fs.readdir(playerdataDir);
                for (const file of files) {
                    if (!file.endsWith('.dat')) continue;
                    const uuid = file.slice(0, -4);
                    const filePath = path.join(playerdataDir, file);
                    try {
                        const stat = await fs.stat(filePath);
                        const cached = playerDataCache.get(uuid);
                        if (cached && cached.mtime === stat.mtimeMs) {
                            datPlayers.push(cached.data);
                            continue;
                        }

                        const raw = await fs.readFile(filePath);
                        const data = await gunzipAsync(raw);
                        const nbt = new NBTReader(data).readTag().value;
                        if (nbt) {
                            const name = uuidToName[uuid] || uuid;
                            let x = 0, y = 0, z = 0;
                            if (nbt.Pos?.value?.length === 3) { x = nbt.Pos.value[0]; y = nbt.Pos.value[1]; z = nbt.Pos.value[2]; }
                            const pObj = {
                                uuid, name,
                                x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10, z: Math.round(z * 10) / 10,
                                dimension: nbt.Dimension || 'minecraft:overworld',
                                health: nbt.Health ?? null,
                                foodLevel: nbt.foodLevel ?? null
                            };
                            playerDataCache.set(uuid, { mtime: stat.mtimeMs, data: pObj });
                            datPlayers.push(pObj);
                        }
                    } catch (err) {}
                }
            }

            let onlineNames = [];
            try { onlineNames = api.getOnlinePlayers(instanceId); } catch (e) {}

            const seen = new Set();
            const players = [];

            for (const name of onlineNames) {
                if (seen.has(name)) continue;
                seen.add(name);
                const cached = positionCache.get(name);
                if (cached && Date.now() - cached.timestamp < 30000) {
                    players.push({
                        uuid: datPlayers.find(p => p.name === name)?.uuid || name,
                        name,
                        x: Math.round(cached.x * 10) / 10,
                        y: Math.round(cached.y * 10) / 10,
                        z: Math.round(cached.z * 10) / 10,
                        dimension: cached.dimension || 'minecraft:overworld',
                        health: cached.health ?? null,
                        foodLevel: cached.foodLevel ?? null,
                        online: true
                    });
                } else {
                    const datP = datPlayers.find(p => p.name === name);
                    if (datP) players.push({ ...datP, online: true });
                    else players.push({ uuid: name, name, x: 0, y: 0, z: 0, dimension: 'minecraft:overworld', health: null, foodLevel: null, online: true });
                }
            }

            for (const p of datPlayers) {
                if (!seen.has(p.name)) {
                    seen.add(p.name);
                    players.push({ ...p, online: false });
                }
            }

            res.json(players);
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Fetch entities for enabled categories
    router.get('/entities', async (req, res) => {
        try {
            const result = { categories: {} };
            for (const [category, def] of Object.entries(ENTITY_CATEGORIES)) {
                if (!entitySettings[category]) continue;
                const entities = entityCache.get(category) || [];
                const fresh = entities.filter(e => Date.now() - e.timestamp < 15000);
                if (fresh.length > 0) {
                    result.categories[category] = {
                        zh: def.zh, en: def.en, color: def.color,
                        entities: fresh
                    };
                }
            }
            res.json(result);
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Get/set entity display settings
    router.get('/entity-settings', (req, res) => {
        res.json(entitySettings);
    });
    router.post('/entity-settings', (req, res) => {
        try {
            const { friendly, neutral, hostile } = req.body;
            if (typeof friendly === 'boolean') entitySettings.friendly = friendly;
            if (typeof neutral === 'boolean') entitySettings.neutral = neutral;
            if (typeof hostile === 'boolean') entitySettings.hostile = hostile;
            for (const [cat] of entityCache) {
                if (!entitySettings[cat]) entityCache.set(cat, []);
            }
            res.json(entitySettings);
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Get entity names for i18n
    router.get('/entity-names', (req, res) => {
        res.json(ENTITY_NAMES);
    });

    // Tracking control - only start when user opens map view
    let trackingStarted = false;
    router.post('/start-tracking', (req, res) => {
        if (!trackingStarted) {
            startPositionTracking();
            trackingStarted = true;
        }
        res.json({ success: true });
    });
    router.post('/stop-tracking', (req, res) => {
        if (positionQueryInterval) {
            clearInterval(positionQueryInterval);
            positionQueryInterval = null;
        }
        if (entityQueryInterval) {
            clearInterval(entityQueryInterval);
            entityQueryInterval = null;
        }
        if (unsubscribeLog) {
            unsubscribeLog();
            unsubscribeLog = null;
        }
        positionCache.clear();
        entityCache.clear();
        playerDataCache.clear();
        biomeCache.clear();
        trackingStarted = false;
        res.json({ success: true });
    });

    api.registerRoutes('/', router);
    api.registerSidebarItem({ id: 'server-map', view: 'server-map-view', labelKey: '服务器地图', icon: 'fa-map-location-dot', color: '#10b981', location: 'instance' });
    api.registerComponent('server-map-view', 'component/MainView.js');

    console.log('[Map Plugin] Backend initialized with non-blocking async rendering and caching.');
};
