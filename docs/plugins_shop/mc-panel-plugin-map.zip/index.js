const path = require('path');
const fs = require('fs-extra');
const express = require('express');
const zlib = require('zlib');

// ==================== High-Speed RGBA PNG Encoder ====================
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    crcTable[n] = c;
}

function crc32(buf) {
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < buf.length; i++) crc = crcTable[(crc ^ buf[i]) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
}

function makePngChunk(type, data) {
    const len = data ? data.length : 0;
    const buf = Buffer.alloc(4 + 4 + len + 4);
    buf.writeUInt32BE(len, 0);
    buf.write(type, 4, 4, 'ascii');
    if (data) data.copy(buf, 8);
    buf.writeUInt32BE(crc32(buf.subarray(4, 8 + len)), 8 + len);
    return buf;
}

function encodeRGBAPNG(width, height, rgbaBuffer) {
    const signature = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
    const ihdr = Buffer.alloc(13);
    ihdr.writeUInt32BE(width, 0);
    ihdr.writeUInt32BE(height, 4);
    ihdr[8] = 8; // bit depth: 8
    ihdr[9] = 6; // color type: RGBA (6)
    const ihdrChunk = makePngChunk('IHDR', ihdr);

    const scanlineLength = 1 + width * 4;
    const rawData = Buffer.alloc(scanlineLength * height);
    for (let y = 0; y < height; y++) {
        const offset = y * scanlineLength;
        rawData[offset] = 0; // Filter type 0 (None)
        rgbaBuffer.copy(rawData, offset + 1, y * width * 4, (y + 1) * width * 4);
    }

    const compressed = zlib.deflateSync(rawData, { level: 4 });
    const idatChunk = makePngChunk('IDAT', compressed);
    const iendChunk = makePngChunk('IEND', null);
    return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

// ==================== Fast Selective NBT Reader ====================
class FastNBTReader {
    constructor(buffer) {
        this.buffer = buffer;
        this.offset = 0;
    }

    readTag(wantedKeys = null) {
        if (this.offset >= this.buffer.length) return { type: 0, name: '', value: null };
        const type = this.buffer[this.offset++];
        if (type === 0) return { type, name: '', value: null };
        const nameLen = this.buffer.readUInt16BE(this.offset);
        this.offset += 2;
        const name = this.buffer.toString('utf8', this.offset, this.offset + nameLen);
        this.offset += nameLen;
        const value = this.readValue(type, wantedKeys);
        return { type, name, value };
    }

    readValue(type, wantedKeys = null) {
        switch (type) {
            case 1: return this.buffer.readInt8(this.offset++);
            case 2: { const s = this.buffer.readInt16BE(this.offset); this.offset += 2; return s; }
            case 3: { const i = this.buffer.readInt32BE(this.offset); this.offset += 4; return i; }
            case 4: { const l = this.buffer.readBigInt64BE(this.offset); this.offset += 8; return l; }
            case 5: { const f = this.buffer.readFloatBE(this.offset); this.offset += 4; return f; }
            case 6: { const d = this.buffer.readDoubleBE(this.offset); this.offset += 8; return d; }
            case 7: {
                const len = this.buffer.readInt32BE(this.offset); this.offset += 4;
                const ba = this.buffer.subarray(this.offset, this.offset + len); this.offset += len; return ba;
            }
            case 8: {
                const len = this.buffer.readUInt16BE(this.offset); this.offset += 2;
                const str = this.buffer.toString('utf8', this.offset, this.offset + len); this.offset += len; return str;
            }
            case 9: {
                const elemType = this.buffer[this.offset++];
                const listLen = this.buffer.readInt32BE(this.offset); this.offset += 4;
                const list = [];
                for (let k = 0; k < listLen; k++) list.push(this.readValue(elemType));
                return list;
            }
            case 10: {
                const comp = {};
                while (true) {
                    if (this.offset >= this.buffer.length) break;
                    const tagType = this.buffer[this.offset++];
                    if (tagType === 0) break;
                    const nameLen = this.buffer.readUInt16BE(this.offset);
                    this.offset += 2;
                    const name = this.buffer.toString('utf8', this.offset, this.offset + nameLen);
                    this.offset += nameLen;
                    if (wantedKeys && !wantedKeys.has(name)) {
                        this.skipValue(tagType);
                    } else {
                        comp[name] = this.readValue(tagType);
                    }
                }
                return comp;
            }
            case 11: {
                const len = this.buffer.readInt32BE(this.offset); this.offset += 4;
                const ia = [];
                for (let k = 0; k < len; k++) { ia.push(this.buffer.readInt32BE(this.offset)); this.offset += 4; }
                return ia;
            }
            case 12: {
                const len = this.buffer.readInt32BE(this.offset); this.offset += 4;
                const la = [];
                for (let k = 0; k < len; k++) { la.push(this.buffer.readBigInt64BE(this.offset)); this.offset += 8; }
                return la;
            }
            default: throw new Error('Unknown NBT type ' + type + ' at offset ' + this.offset);
        }
    }

    skipValue(type) {
        switch (type) {
            case 1: this.offset += 1; break;
            case 2: this.offset += 2; break;
            case 3: case 5: this.offset += 4; break;
            case 4: case 6: this.offset += 8; break;
            case 7: { const len = this.buffer.readInt32BE(this.offset); this.offset += 4 + len; break; }
            case 8: { const len = this.buffer.readUInt16BE(this.offset); this.offset += 2 + len; break; }
            case 9: {
                const elemType = this.buffer[this.offset++];
                const listLen = this.buffer.readInt32BE(this.offset); this.offset += 4;
                for (let k = 0; k < listLen; k++) this.skipValue(elemType);
                break;
            }
            case 10: {
                while (true) {
                    if (this.offset >= this.buffer.length) break;
                    const subType = this.buffer[this.offset++];
                    if (subType === 0) break;
                    const nameLen = this.buffer.readUInt16BE(this.offset);
                    this.offset += 2 + nameLen;
                    this.skipValue(subType);
                }
                break;
            }
            case 11: { const len = this.buffer.readInt32BE(this.offset); this.offset += 4 + len * 4; break; }
            case 12: { const len = this.buffer.readInt32BE(this.offset); this.offset += 4 + len * 8; break; }
        }
    }
}

// 9-bit Heightmap unpacker (indexed by z * 16 + x)
function unpackHeightmap(longs) {
    if (!longs || longs.length < 37) return null;
    const values = new Int16Array(256);
    const bitsPerValue = 9;
    const mask = (1n << BigInt(bitsPerValue)) - 1n;
    const valPerLong = Math.floor(64 / bitsPerValue);
    for (let i = 0; i < 256; i++) {
        const longIdx = Math.floor(i / valPerLong);
        const valIdx = i % valPerLong;
        const bitOffset = valIdx * bitsPerValue;
        const longVal = BigInt(longs[longIdx]);
        values[i] = Number((longVal >> BigInt(bitOffset)) & mask);
    }
    return values;
}

// Palette Block Decoder
function getBlockName(palette, data, index) {
    if (!palette || !palette.length) return 'minecraft:air';
    if (palette.length === 1) return palette[0].Name || 'minecraft:air';
    if (!data) return palette[0].Name || 'minecraft:air';
    const bitsPerValue = Math.max(4, Math.ceil(Math.log2(palette.length)));
    const valPerLong = Math.floor(64 / bitsPerValue);
    const longIdx = Math.floor(index / valPerLong);
    const valIdx = index % valPerLong;
    const bitOffset = valIdx * bitsPerValue;
    if (longIdx >= data.length) return 'minecraft:air';
    const longVal = BigInt(data[longIdx]);
    const val = (longVal >> BigInt(bitOffset)) & ((1n << BigInt(bitsPerValue)) - 1n);
    const palEntry = palette[Number(val)];
    return palEntry ? palEntry.Name : 'minecraft:air';
}

// Per-section 4x4 Biome extractor
function getBiomeAt(sec, x, z, y) {
    if (!sec?.biomes) return null;
    const pal = sec.biomes.palette?.value || sec.biomes.palette;
    if (!pal || !pal.length) return null;
    if (pal.length === 1) return (typeof pal[0] === 'string') ? pal[0] : (pal[0]?.value || pal[0]?.Name || pal[0]);
    const data = sec.biomes.data;
    if (!data) return pal[0];
    const bx = Math.floor(x / 4);
    const bz = Math.floor(z / 4);
    const by = Math.floor((((y % 16) + 16) % 16) / 4);
    const bits = Math.max(1, Math.ceil(Math.log2(pal.length)));
    const valPerLong = Math.floor(64 / bits);
    const idx = (by * 4 + bz) * 4 + bx;
    const longIdx = Math.floor(idx / valPerLong);
    const valIdx = idx % valPerLong;
    if (longIdx >= data.length) return pal[0];
    const longVal = BigInt(data[longIdx]);
    const val = Number((longVal >> BigInt(valIdx * bits)) & ((1n << BigInt(bits)) - 1n));
    const entry = pal[val] || pal[0];
    return (typeof entry === 'string') ? entry : (entry?.value || entry?.Name || entry);
}

// Non-solid ground-cover blocks (transparent foliage that doesn't form elevation cliffs)
const NON_SOLID_PLANTS = new Set([
    'minecraft:short_grass', 'minecraft:grass', 'minecraft:tall_grass',
    'minecraft:fern', 'minecraft:large_fern', 'minecraft:dead_bush',
    'minecraft:dandelion', 'minecraft:poppy', 'minecraft:blue_orchid',
    'minecraft:allium', 'minecraft:azure_bluet', 'minecraft:red_tulip',
    'minecraft:orange_tulip', 'minecraft:white_tulip', 'minecraft:pink_tulip',
    'minecraft:oxeye_daisy', 'minecraft:cornflower', 'minecraft:lily_of_the_valley',
    'minecraft:sunflower', 'minecraft:lilac', 'minecraft:rose_bush', 'minecraft:peony',
    'minecraft:torch', 'minecraft:wall_torch', 'minecraft:redstone_torch',
    'minecraft:redstone_wire', 'minecraft:repeater', 'minecraft:comparator',
    'minecraft:lever', 'minecraft:tripwire_hook', 'minecraft:tripwire',
    'minecraft:string', 'minecraft:vine', 'minecraft:glow_lichen',
    'minecraft:hanging_roots', 'minecraft:spore_blossom', 'minecraft:big_dripleaf_stem',
    'minecraft:sculk_vein', 'minecraft:leaf_litter',
    'somemoreblocks:leaf_litter', 'somemoreblocks:clover'
]);

// Biome grass color tints
const BIOME_GRASS_COLORS = {
    'savanna': [185, 175, 75],
    'savanna_plateau': [180, 170, 70],
    'windswept_savanna': [175, 165, 65],
    'plains': [125, 175, 65],
    'sunflower_plains': [130, 180, 70],
    'forest': [110, 160, 55],
    'flower_forest': [115, 165, 60],
    'birch_forest': [120, 168, 70],
    'old_growth_birch_forest': [120, 168, 70],
    'dark_forest': [70, 120, 45],
    'taiga': [100, 145, 80],
    'snowy_taiga': [110, 140, 95],
    'old_growth_pine_taiga': [95, 135, 75],
    'old_growth_spruce_taiga': [95, 135, 75],
    'jungle': [85, 175, 30],
    'sparse_jungle': [95, 170, 40],
    'bamboo_jungle': [100, 180, 35],
    'swamp': [95, 105, 55],
    'mangrove_swamp': [105, 115, 50],
    'badlands': [160, 115, 60],
    'eroded_badlands': [160, 115, 60],
    'wooded_badlands': [155, 120, 65],
    'desert': [195, 175, 105],
    'meadow': [115, 175, 80],
    'cherry_grove': [160, 190, 110],
    'snowy_plains': [115, 150, 100],
    'snowy_slopes': [115, 150, 100],
    'ocean': [120, 165, 65],
    'river': [120, 165, 65]
};

const BASE_BLOCK_COLORS = {
    // Terrain
    'minecraft:dirt': [134, 96, 67], 'minecraft:coarse_dirt': [120, 85, 58],
    'minecraft:podzol': [90, 63, 44], 'minecraft:farmland': [118, 77, 45],
    'minecraft:dirt_path': [175, 138, 78], 'minecraft:mycelium': [110, 98, 110],
    'minecraft:moss_block': [89, 130, 45], 'minecraft:moss_carpet': [89, 130, 45],
    'minecraft:sand': [218, 208, 155], 'minecraft:sandstone': [216, 203, 155],
    'minecraft:red_sand': [170, 88, 33], 'minecraft:red_sandstone': [170, 88, 33],
    'minecraft:gravel': [136, 126, 125], 'minecraft:clay': [162, 166, 182],
    'minecraft:mud': [60, 57, 60], 'minecraft:packed_mud': [142, 106, 79],
    'minecraft:mud_bricks': [137, 103, 80],

    // Stone & Underground
    'minecraft:stone': [125, 125, 125], 'minecraft:granite': [150, 105, 85],
    'minecraft:diorite': [180, 180, 180], 'minecraft:andesite': [130, 130, 130],
    'minecraft:deepslate': [70, 70, 70], 'minecraft:cobbled_deepslate': [65, 65, 65],
    'minecraft:cobblestone': [115, 115, 115], 'minecraft:mossy_cobblestone': [95, 115, 85],
    'minecraft:smooth_stone': [160, 160, 160], 'minecraft:tuff': [108, 109, 102],
    'minecraft:calcite': [225, 225, 220], 'minecraft:dripstone_block': [132, 105, 93],
    'minecraft:obsidian': [20, 15, 30], 'minecraft:crying_obsidian': [45, 20, 60],
    'minecraft:bedrock': [45, 45, 45],

    // Liquids & Ice
    'minecraft:water': [42, 95, 175], 'minecraft:lava': [225, 90, 10],
    'minecraft:ice': [160, 210, 245], 'minecraft:packed_ice': [140, 190, 240],
    'minecraft:blue_ice': [120, 170, 230], 'minecraft:snow_block': [245, 245, 245],
    'minecraft:snow': [245, 245, 245], 'minecraft:powder_snow': [250, 250, 250],

    // Foliage (Specific natural leaves colors)
    'minecraft:oak_leaves': [75, 135, 45], 'minecraft:spruce_leaves': [55, 95, 65],
    'minecraft:birch_leaves': [110, 165, 60], 'minecraft:jungle_leaves': [70, 145, 40],
    'minecraft:acacia_leaves': [135, 155, 45], 'minecraft:dark_oak_leaves': [45, 85, 25],
    'minecraft:mangrove_leaves': [75, 125, 38], 'minecraft:cherry_leaves': [238, 175, 195],
    'minecraft:azalea_leaves': [85, 135, 45], 'minecraft:flowering_azalea_leaves': [125, 145, 75],

    // Wood & Planks
    'minecraft:oak_log': [110, 85, 55], 'minecraft:spruce_log': [60, 42, 25],
    'minecraft:birch_log': [210, 210, 205], 'minecraft:jungle_log': [90, 68, 42],
    'minecraft:acacia_log': [105, 98, 90], 'minecraft:dark_oak_log': [45, 33, 20],
    'minecraft:mangrove_log': [90, 40, 40], 'minecraft:cherry_log': [60, 35, 42],
    'minecraft:oak_planks': [162, 130, 86], 'minecraft:spruce_planks': [100, 78, 51],
    'minecraft:birch_planks': [192, 175, 121], 'minecraft:jungle_planks': [160, 115, 85],
    'minecraft:acacia_planks': [168, 97, 58], 'minecraft:dark_oak_planks': [66, 43, 22],
    'minecraft:cherry_planks': [220, 160, 150], 'minecraft:mangrove_planks': [118, 58, 56],
    'minecraft:bamboo_planks': [180, 165, 90],

    // Nether & End
    'minecraft:netherrack': [110, 40, 40], 'minecraft:crimson_nylium': [140, 25, 30],
    'minecraft:warped_nylium': [40, 115, 110], 'minecraft:soul_sand': [80, 60, 50],
    'minecraft:soul_soil': [75, 55, 45], 'minecraft:basalt': [80, 80, 85],
    'minecraft:blackstone': [40, 35, 40], 'minecraft:glowstone': [220, 180, 100],
    'minecraft:magma_block': [180, 70, 20], 'minecraft:end_stone': [220, 225, 165],
    'minecraft:purpur_block': [170, 125, 170],

    // Ores
    'minecraft:coal_ore': [90, 90, 90], 'minecraft:iron_ore': [135, 120, 110],
    'minecraft:copper_ore': [125, 110, 95], 'minecraft:gold_ore': [145, 130, 80],
    'minecraft:redstone_ore': [150, 80, 80], 'minecraft:lapis_ore': [75, 95, 140],
    'minecraft:diamond_ore': [95, 145, 145], 'minecraft:emerald_ore': [80, 140, 95],

    // Modded & Decorative
    'supplementaries:urn': [170, 130, 95], 'minecraft:brick': [155, 75, 60],
    'minecraft:bricks': [155, 75, 60], 'minecraft:terracotta': [150, 92, 66]
};

function getSmartBlockColor(name, biomeName) {
    if (!name) return null;
    if (name.includes('air') || name.includes('void')) return null;

    if (name === 'minecraft:grass_block') {
        if (biomeName) {
            const shortBio = biomeName.replace('minecraft:', '');
            if (BIOME_GRASS_COLORS[shortBio]) return BIOME_GRASS_COLORS[shortBio];
        }
        return [125, 175, 65];
    }

    if (BASE_BLOCK_COLORS[name]) return BASE_BLOCK_COLORS[name];

    // Fuzzy deduction
    if (name.includes('leaves')) {
        if (name.includes('cherry')) return [238, 175, 195];
        if (name.includes('acacia')) return [135, 155, 45];
        if (name.includes('birch')) return [110, 165, 60];
        if (name.includes('spruce')) return [55, 95, 65];
        return [75, 135, 45];
    }
    if (name.includes('grass') || name.includes('moss') || name.includes('clover')) {
        if (biomeName?.includes('savanna')) return [185, 175, 75];
        return [120, 170, 60];
    }
    if (name.includes('water')) return [42, 95, 175];
    if (name.includes('lava') || name.includes('fire')) return [225, 90, 10];
    if (name.includes('log') || name.includes('wood') || name.includes('stem')) return [105, 80, 50];
    if (name.includes('planks') || name.includes('fence') || name.includes('door') || name.includes('stairs') || name.includes('slab')) return [155, 120, 80];
    if (name.includes('sand')) return name.includes('red') ? [170, 88, 33] : [218, 208, 155];
    if (name.includes('stone') || name.includes('cobble') || name.includes('andesite') || name.includes('diorite') || name.includes('granite') || name.includes('tuff')) return [125, 125, 125];
    if (name.includes('deepslate')) return [70, 70, 70];
    if (name.includes('wool') || name.includes('concrete') || name.includes('terracotta')) return [180, 180, 180];
    return [130, 145, 110];
}

// ==================== Main Plugin Module ====================
module.exports = (api) => {
    const levelNameCache = new Map();
    function getLevelName(instanceDir) {
        if (levelNameCache.has(instanceDir)) return levelNameCache.get(instanceDir);
        try {
            const propPath = path.join(instanceDir, 'server.properties');
            if (fs.existsSync(propPath)) {
                for (const line of fs.readFileSync(propPath, 'utf8').split('\n')) {
                    if (line.trim().startsWith('level-name=')) {
                        const val = line.split('=')[1].trim();
                        levelNameCache.set(instanceDir, val);
                        return val;
                    }
                }
            }
        } catch (e) {}
        levelNameCache.set(instanceDir, 'world');
        return 'world';
    }

    function getRegionPath(instanceDir, dimension) {
        const levelName = getLevelName(instanceDir);
        if (dimension === 'minecraft:the_nether') return path.join(instanceDir, levelName, 'DIM-1', 'region');
        if (dimension === 'minecraft:the_end') return path.join(instanceDir, levelName, 'DIM1', 'region');
        return path.join(instanceDir, levelName, 'region');
    }

    function extractChunkFromBuffer(mcaBuf, cx, cz) {
        const idx = 4 * (cx + cz * 32);
        if (idx + 4 > mcaBuf.length) return null;
        const offset = (mcaBuf[idx] << 16) | (mcaBuf[idx + 1] << 8) | mcaBuf[idx + 2];
        if (offset === 0) return null;
        const pos = offset * 4096;
        if (pos + 5 > mcaBuf.length) return null;
        const length = mcaBuf.readUInt32BE(pos);
        if (length <= 1) return null;
        const compressionType = mcaBuf[pos + 4];
        const compressedData = mcaBuf.subarray(pos + 5, pos + 4 + length);

        try {
            if (compressionType === 2) return zlib.inflateSync(compressedData);
            if (compressionType === 1) return zlib.gunzipSync(compressedData);
        } catch (e) {
            return null;
        }
        return null;
    }

    // ==================== Entity Definitions & State ====================
    const ENTITY_CATEGORIES = {
        friendly: {
            zh: '友好生物', en: 'Friendly', color: '#10b981', icon: 'fa-paw',
            types: ['cow', 'sheep', 'pig', 'chicken', 'rabbit', 'villager', 'horse', 'donkey', 'mule', 'fox', 'bee', 'cat', 'parrot', 'axolotl', 'goat', 'frog', 'allay', 'armadillo', 'dolphin', 'squid', 'glow_squid', 'turtle', 'mooshroom', 'llama', 'panda', 'strider', 'tadpole', 'sniffer', 'camel']
        },
        neutral: {
            zh: '中立生物', en: 'Neutral', color: '#f59e0b', icon: 'fa-shield-halved',
            types: ['wolf', 'enderman', 'iron_golem', 'snow_golem', 'piglin', 'zombified_piglin', 'dolphin', 'llama', 'trader_llama', 'polar_bear', 'bee', 'fox', 'goat', 'panda', 'spider', 'cave_spider']
        },
        hostile: {
            zh: '敌对生物', en: 'Hostile', color: '#ef4444', icon: 'fa-skull',
            types: ['zombie', 'skeleton', 'creeper', 'witch', 'slime', 'phantom', 'blaze', 'ghast', 'magma_cube', 'wither_skeleton', 'stray', 'husk', 'drowned', 'pillager', 'vindicator', 'ravager', 'evoker', 'guardian', 'elder_guardian', 'shulker', 'silverfish', 'endermite', 'bogged', 'breeze', 'warden', 'hoglin', 'piglin_brute', 'creaking']
        }
    };

    const ENTITY_NAMES = {
        'cow': { zh: '牛', en: 'Cow' }, 'sheep': { zh: '羊', en: 'Sheep' }, 'pig': { zh: '猪', en: 'Pig' },
        'chicken': { zh: '鸡', en: 'Chicken' }, 'rabbit': { zh: '兔子', en: 'Rabbit' }, 'villager': { zh: '村民', en: 'Villager' },
        'horse': { zh: '马', en: 'Horse' }, 'wolf': { zh: '狼', en: 'Wolf' }, 'enderman': { zh: '末影人', en: 'Enderman' },
        'iron_golem': { zh: '铁傀儡', en: 'Iron Golem' }, 'zombie': { zh: '僵尸', en: 'Zombie' },
        'skeleton': { zh: '骷髅', en: 'Skeleton' }, 'creeper': { zh: '苦力怕', en: 'Creeper' },
        'spider': { zh: '蜘蛛', en: 'Spider' }, 'slime': { zh: '史莱姆', en: 'Slime' }
    };

    const positionCache = new Map();
    const entitySettings = { friendly: false, neutral: false, hostile: false };
    const playerDataCache = new Map();
    const userCacheMemory = { mtime: 0, mapping: {} };
    const biomeCache = new Map();

    // ==================== Heartbeat & Quiet Mode ====================
    let lastHeartbeat = 0;
    let isTracking = false;
    let positionQueryInterval = null;
    let unsubscribeLog = null;

    function ensureTracking() {
        lastHeartbeat = Date.now();
        if (isTracking) return;
        isTracking = true;

        if (!unsubscribeLog) {
            unsubscribeLog = api.onLog((instanceId, msg) => {
                if (!msg || typeof msg !== 'string' || !msg.includes('has the following entity data:')) return;

                let onlineNames = [];
                try { onlineNames = api.getOnlinePlayers(instanceId); } catch (e) {}
                const onlineSet = new Set(onlineNames);

                const posMatch = msg.match(/([\w:]+)\s+has the following entity data:\s*\[(-?[\d.]+)d,\s*(-?[\d.]+)d,\s*(-?[\d.]+)d\]/);
                if (posMatch) {
                    const name = posMatch[1];
                    const x = parseFloat(posMatch[2]);
                    const y = parseFloat(posMatch[3]);
                    const z = parseFloat(posMatch[4]);
                    if (onlineSet.has(name)) {
                        const cached = positionCache.get(name) || {};
                        positionCache.set(name, {
                            x, y, z,
                            dimension: cached.dimension || 'minecraft:overworld',
                            health: cached.health ?? null,
                            foodLevel: cached.foodLevel ?? null,
                            timestamp: Date.now()
                        });
                    }
                }

                const healthMatch = msg.match(/(\w+)\s+has the following entity data:\s*([\d.]+)f\b/);
                if (healthMatch && onlineSet.has(healthMatch[1])) {
                    const cached = positionCache.get(healthMatch[1]);
                    if (cached) cached.health = parseFloat(healthMatch[2]);
                }

                const foodMatch = msg.match(/(\w+)\s+has the following entity data:\s*(\d+)\s*$/);
                if (foodMatch && onlineSet.has(foodMatch[1])) {
                    const cached = positionCache.get(foodMatch[1]);
                    if (cached) cached.foodLevel = parseInt(foodMatch[2], 10);
                }

                const dimMatch = msg.match(/(\w+)\s+has the following entity data:\s*'?(minecraft:\w+)'?/);
                if (dimMatch && onlineSet.has(dimMatch[1])) {
                    const cached = positionCache.get(dimMatch[1]);
                    if (cached) cached.dimension = dimMatch[2];
                }
            });
        }

        if (!positionQueryInterval) {
            positionQueryInterval = setInterval(() => {
                if (Date.now() - lastHeartbeat > 15000) {
                    stopTracking();
                    return;
                }

                const instanceId = api.getActiveInstanceId();
                try {
                    const onlinePlayers = api.getOnlinePlayers(instanceId);
                    if (!onlinePlayers || !onlinePlayers.length) return;
                    let delay = 0;
                    for (const player of onlinePlayers) {
                        setTimeout(() => { api.sendCommand(instanceId, `data get entity ${player} Pos`); }, delay);
                        setTimeout(() => { api.sendCommand(instanceId, `data get entity ${player} Health`); }, delay + 100);
                        delay += 300;
                    }
                } catch (e) {}
            }, 4000);
        }
    }

    function stopTracking() {
        if (positionQueryInterval) {
            clearInterval(positionQueryInterval);
            positionQueryInterval = null;
        }
        if (unsubscribeLog) {
            unsubscribeLog();
            unsubscribeLog = null;
        }
        isTracking = false;
    }

    // ==================== Concurrency Control ====================
    let activeRenders = 0;
    const MAX_CONCURRENT_RENDERS = 2;
    const renderQueue = [];
    const inProgressRenders = new Map();

    function acquireRenderSlot() {
        return new Promise((resolve) => {
            if (activeRenders < MAX_CONCURRENT_RENDERS) {
                activeRenders++;
                resolve();
            } else {
                renderQueue.push(resolve);
            }
        });
    }

    function releaseRenderSlot() {
        if (renderQueue.length > 0) {
            const next = renderQueue.shift();
            next();
        } else {
            activeRenders = Math.max(0, activeRenders - 1);
        }
    }

    // ==================== Core High-Quality Region Renderer ====================
    async function renderRegionToPNG(mcaPath, dimension) {
        const mcaBuf = await fs.readFile(mcaPath);
        const size = 512;
        const heightMap = new Int16Array(size * size);
        heightMap.fill(-999);
        const colorMap = new Array(size * size).fill(null);
        const isWaterMap = new Uint8Array(size * size);

        const wantedTags = new Set(['Heightmaps', 'sections', 'yPos', 'Status']);
        const isNether = (dimension === 'minecraft:the_nether');

        for (let cz = 0; cz < 32; cz++) {
            for (let cx = 0; cx < 32; cx++) {
                const decomp = extractChunkFromBuffer(mcaBuf, cx, cz);
                if (!decomp) continue;

                try {
                    const reader = new FastNBTReader(decomp);
                    const nbt = reader.readTag(wantedTags).value;
                    if (!nbt) continue;

                    // FILTER 1: Ignore ungenerated proto-chunks (prevents fake solid green borders)
                    if (nbt.Status && nbt.Status !== 'minecraft:full' && nbt.Status !== 'full') {
                        continue;
                    }

                    const sections = nbt.sections?.value || nbt.sections || [];
                    const sectionsMap = {};
                    let hasNeg = false;

                    for (const s of sections) {
                        const y = Number(s.Y);
                        if (y < 0) hasNeg = true;
                        sectionsMap[y] = s;
                    }

                    const minY = (nbt.yPos !== undefined) ? Number(nbt.yPos) * 16 : (hasNeg ? -64 : 0);
                    const heightmaps = nbt.Heightmaps;
                    const longs = heightmaps?.WORLD_SURFACE || heightmaps?.MOTION_BLOCKING;
                    const unpacked = unpackHeightmap(longs);

                    for (let z = 0; z < 16; z++) {
                        for (let x = 0; x < 16; x++) {
                            const gx = cx * 16 + x;
                            const gz = cz * 16 + z;
                            const mapIdx = gz * size + gx;

                            let rawY = 62;
                            if (unpacked) {
                                rawY = unpacked[z * 16 + x] + minY - 1;
                            }

                            if (isNether) {
                                // Nether: penetrate bedrock ceiling (scan from Y=120 down to Y=15)
                                let netherY = -999;
                                let netherBlock = null;
                                for (let testY = 120; testY >= 15; testY--) {
                                    const secY = Math.floor(testY / 16);
                                    const sec = sectionsMap[secY];
                                    if (sec?.block_states) {
                                        const palette = sec.block_states.palette?.value || sec.block_states.palette;
                                        const data = sec.block_states.data;
                                        const yOff = ((testY % 16) + 16) % 16;
                                        const bIdx = yOff * 256 + z * 16 + x;
                                        const bName = getBlockName(palette, data, bIdx);
                                        if (bName && !bName.includes('air') && bName !== 'minecraft:bedrock') {
                                            netherY = testY;
                                            netherBlock = bName;
                                            break;
                                        }
                                    }
                                }
                                if (netherY > -999) {
                                    heightMap[mapIdx] = netherY;
                                    colorMap[mapIdx] = getSmartBlockColor(netherBlock, 'minecraft:nether_wastes') || [110, 40, 40];
                                }
                                continue;
                            }

                            // Overworld & The End:
                            // Scan down to find actual solid surface (skip non-solid grass/flower/leaf litter)
                            let solidY = -999;
                            let solidBlock = null;
                            let waterSurfaceY = null;
                            let waterDepth = 0;
                            let localBiome = null;

                            for (let depth = 0; depth < 22; depth++) {
                                const cy = rawY - depth;
                                if (cy < -64) break;
                                const secY = Math.floor(cy / 16);
                                const sec = sectionsMap[secY];
                                if (sec?.block_states) {
                                    if (!localBiome) {
                                        localBiome = getBiomeAt(sec, x, z, cy);
                                    }

                                    const palette = sec.block_states.palette?.value || sec.block_states.palette;
                                    const data = sec.block_states.data;
                                    const yOff = ((cy % 16) + 16) % 16;
                                    const bIdx = yOff * 256 + z * 16 + x;
                                    const bName = getBlockName(palette, data, bIdx);

                                    if (!bName || bName.includes('air')) continue;

                                    if (bName === 'minecraft:water') {
                                        if (waterSurfaceY === null) waterSurfaceY = cy;
                                        waterDepth++;
                                        continue;
                                    }

                                    // Skip non-solid surface flowers, tall grass, leaf litter
                                    if (NON_SOLID_PLANTS.has(bName)) {
                                        continue;
                                    }

                                    solidY = cy;
                                    solidBlock = bName;
                                    break;
                                }
                            }

                            if (solidY === -999) {
                                if (waterSurfaceY !== null) {
                                    solidY = waterSurfaceY;
                                    solidBlock = 'minecraft:water';
                                } else {
                                    continue; // transparent void
                                }
                            }

                            // Color calculation with water depth & shoreline blending
                            let finalColor;
                            if (waterSurfaceY !== null) {
                                isWaterMap[mapIdx] = 1;
                                heightMap[mapIdx] = waterSurfaceY;

                                const bedColor = getSmartBlockColor(solidBlock, localBiome) || [180, 170, 130];
                                // Depth curve: shallow water is transparent aqua, deep ocean is navy blue
                                const alpha = Math.min(0.85, 0.35 + waterDepth * 0.08);
                                const waterR = 38, waterG = 100, waterB = 185;
                                finalColor = [
                                    Math.round(bedColor[0] * (1 - alpha) + waterR * alpha),
                                    Math.round(bedColor[1] * (1 - alpha) + waterG * alpha),
                                    Math.round(bedColor[2] * (1 - alpha) + waterB * alpha)
                                ];
                            } else {
                                heightMap[mapIdx] = solidY;
                                finalColor = getSmartBlockColor(solidBlock, localBiome) || [125, 175, 65];
                            }

                            colorMap[mapIdx] = finalColor;
                        }
                    }
                } catch (err) {}
            }
        }

        // Soft photographic relief hillshading
        const rgbaBuf = Buffer.alloc(size * size * 4);
        for (let z = 0; z < size; z++) {
            for (let x = 0; x < size; x++) {
                const idx = z * size + x;
                const y = heightMap[idx];
                const pIdx = idx * 4;

                if (y === -999) {
                    // Completely transparent for ungenerated proto-chunks
                    rgbaBuf[pIdx + 3] = 0;
                    continue;
                }

                const isWater = isWaterMap[idx] === 1;
                const baseColor = colorMap[idx] || [125, 175, 65];

                let slope = 0;
                if (!isWater) {
                    // Northwest light source with soft clamping (no burned-out whites or crushed blacks)
                    const yLeft = (x > 0 && heightMap[z * size + (x - 1)] !== -999) ? heightMap[z * size + (x - 1)] : y;
                    const yTop = (z > 0 && heightMap[(z - 1) * size + x] !== -999) ? heightMap[(z - 1) * size + x] : y;
                    const diff = (y - yLeft) * 3.5 + (y - yTop) * 2.5;
                    slope = Math.max(-28, Math.min(28, Math.round(diff)));
                }

                rgbaBuf[pIdx + 0] = Math.max(0, Math.min(255, baseColor[0] + slope));
                rgbaBuf[pIdx + 1] = Math.max(0, Math.min(255, baseColor[1] + slope));
                rgbaBuf[pIdx + 2] = Math.max(0, Math.min(255, baseColor[2] + slope));
                rgbaBuf[pIdx + 3] = 255;
            }
        }

        return encodeRGBAPNG(size, size, rgbaBuf);
    }

    // ==================== Routes Setup ====================
    const router = express.Router();

    router.use('/lib', express.static(path.join(__dirname, 'lib')));

    router.post('/heartbeat', (req, res) => {
        ensureTracking();
        res.json({ ok: true });
    });

    router.get('/regions', async (req, res) => {
        try {
            const instanceId = req.query.instanceId || api.getActiveInstanceId();
            const instanceDir = api.getInstanceDir(instanceId);
            const regionPath = getRegionPath(instanceDir, req.query.dimension || 'minecraft:overworld');
            if (!await fs.pathExists(regionPath)) return res.json([]);
            const files = await fs.readdir(regionPath);
            const mcaFiles = files.filter(f => /^r\.-?\d+\.-?\d+\.mca$/.test(f));

            const list = await Promise.all(mcaFiles.map(async (f) => {
                const parts = f.split('.');
                const stat = await fs.stat(path.join(regionPath, f)).catch(() => ({ mtimeMs: 0 }));
                return { file: f, x: parseInt(parts[1], 10), z: parseInt(parts[2], 10), mtime: stat.mtimeMs };
            }));
            res.json(list);
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    router.get('/render', async (req, res) => {
        try {
            const instanceId = req.query.instanceId || api.getActiveInstanceId();
            const dimension = req.query.dimension || 'minecraft:overworld';
            const region = req.query.region;
            if (!region) return res.status(400).send('Missing region parameter');

            const instanceDir = api.getInstanceDir(instanceId);
            const mcaPath = path.join(getRegionPath(instanceDir, dimension), region);
            if (!await fs.pathExists(mcaPath)) return res.status(404).send('Region file not found');

            const cacheDir = path.join(api.getDataDir(), 'map_cache');
            await fs.ensureDir(cacheDir);
            const stat = await fs.stat(mcaPath);
            const mcaMtime = stat.mtimeMs;
            const cacheFile = path.join(cacheDir, `${instanceId}_${dimension.replace(/:/g, '_')}_${region}.png`);

            if (await fs.pathExists(cacheFile) && !req.query.force) {
                const cacheStat = await fs.stat(cacheFile);
                if (cacheStat.mtimeMs >= mcaMtime) {
                    res.setHeader('Content-Type', 'image/png');
                    res.setHeader('Cache-Control', 'public, max-age=3600');
                    return res.sendFile(cacheFile);
                }
            }

            const renderKey = `${instanceId}_${dimension}_${region}`;
            if (inProgressRenders.has(renderKey)) {
                const pngBuffer = await inProgressRenders.get(renderKey);
                res.setHeader('Content-Type', 'image/png');
                res.setHeader('Cache-Control', 'public, max-age=3600');
                return res.send(pngBuffer);
            }

            const renderPromise = (async () => {
                await acquireRenderSlot();
                try {
                    if (await fs.pathExists(cacheFile) && !req.query.force) {
                        const cacheStat = await fs.stat(cacheFile);
                        if (cacheStat.mtimeMs >= mcaMtime) {
                            return await fs.readFile(cacheFile);
                        }
                    }
                    const pngBuffer = await renderRegionToPNG(mcaPath, dimension);
                    await fs.writeFile(cacheFile, pngBuffer);
                    return pngBuffer;
                } finally {
                    releaseRenderSlot();
                }
            })();

            inProgressRenders.set(renderKey, renderPromise);
            try {
                const pngBuffer = await renderPromise;
                res.setHeader('Content-Type', 'image/png');
                res.setHeader('Cache-Control', 'public, max-age=3600');
                res.send(pngBuffer);
            } finally {
                inProgressRenders.delete(renderKey);
            }
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    router.get('/safe-surface-y', async (req, res) => {
        try {
            const instanceId = req.query.instanceId || api.getActiveInstanceId();
            const dimension = req.query.dimension || 'minecraft:overworld';
            const x = parseInt(req.query.x, 10);
            const z = parseInt(req.query.z, 10);
            if (isNaN(x) || isNaN(z)) return res.status(400).json({ error: 'Invalid coordinates' });

            const chunkX = Math.floor(x / 16);
            const chunkZ = Math.floor(z / 16);
            const localX = ((x % 16) + 16) % 16;
            const localZ = ((z % 16) + 16) % 16;

            const regionX = Math.floor(chunkX / 32);
            const regionZ = Math.floor(chunkZ / 32);
            const localCX = ((chunkX % 32) + 32) % 32;
            const localCZ = ((chunkZ % 32) + 32) % 32;

            const instanceDir = api.getInstanceDir(instanceId);
            const mcaPath = path.join(getRegionPath(instanceDir, dimension), `r.${regionX}.${regionZ}.mca`);
            if (!await fs.pathExists(mcaPath)) return res.json({ surfaceY: null });

            const mcaBuf = await fs.readFile(mcaPath);
            const decomp = extractChunkFromBuffer(mcaBuf, localCX, localCZ);
            if (!decomp) return res.json({ surfaceY: null });

            const reader = new FastNBTReader(decomp);
            const nbt = reader.readTag(new Set(['Heightmaps', 'sections', 'yPos', 'Status'])).value;
            if (!nbt) return res.json({ surfaceY: null });

            const sections = nbt.sections?.value || nbt.sections || [];
            const secMap = {};
            for (const s of sections) secMap[Number(s.Y)] = s;

            if (dimension === 'minecraft:the_nether') {
                for (let testY = 120; testY >= 15; testY--) {
                    const sec = secMap[Math.floor(testY / 16)];
                    if (sec?.block_states) {
                        const palette = sec.block_states.palette?.value || sec.block_states.palette;
                        const data = sec.block_states.data;
                        const bIdx = (((testY % 16) + 16) % 16) * 256 + localZ * 16 + localX;
                        const bName = getBlockName(palette, data, bIdx);
                        if (bName && !bName.includes('air') && bName !== 'minecraft:bedrock') {
                            return res.json({ surfaceY: testY + 1 });
                        }
                    }
                }
                return res.json({ surfaceY: 64 });
            }

            const heightmaps = nbt.Heightmaps;
            const longs = heightmaps?.WORLD_SURFACE || heightmaps?.MOTION_BLOCKING;
            const unpacked = unpackHeightmap(longs);
            if (unpacked) {
                const minY = (nbt.yPos !== undefined) ? Number(nbt.yPos) * 16 : 0;
                let rawH = unpacked[localZ * 16 + localX] + minY - 1;
                // Scan down to skip tall grass, leaf litter, etc.
                for (let d = 0; d < 10; d++) {
                    const cy = rawH - d;
                    const sec = secMap[Math.floor(cy / 16)];
                    if (sec?.block_states) {
                        const palette = sec.block_states.palette?.value || sec.block_states.palette;
                        const data = sec.block_states.data;
                        const bIdx = (((cy % 16) + 16) % 16) * 256 + localZ * 16 + localX;
                        const bName = getBlockName(palette, data, bIdx);
                        if (bName && !bName.includes('air') && !NON_SOLID_PLANTS.has(bName)) {
                            return res.json({ surfaceY: cy + 1 });
                        }
                    }
                }
                return res.json({ surfaceY: rawH + 1 });
            }

            res.json({ surfaceY: null });
        } catch (e) {
            res.status(500).json({ error: e.message });
        }
    });

    router.get('/chunk-render', async (req, res) => {
        try {
            const instanceId = req.query.instanceId || api.getActiveInstanceId();
            const dimension = req.query.dimension || 'minecraft:overworld';
            const chunkX = parseInt(req.query.chunkX, 10);
            const chunkZ = parseInt(req.query.chunkZ, 10);
            if (isNaN(chunkX) || isNaN(chunkZ)) return res.status(400).send('Missing coordinates');

            const regionX = Math.floor(chunkX / 32);
            const regionZ = Math.floor(chunkZ / 32);
            const region = `r.${regionX}.${regionZ}.mca`;

            const cacheDir = path.join(api.getDataDir(), 'map_cache');
            const cacheFile = path.join(cacheDir, `${instanceId}_${dimension.replace(/:/g, '_')}_${region}.png`);
            if (await fs.pathExists(cacheFile)) await fs.remove(cacheFile);

            res.json({ success: true, region });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    router.get('/biome', async (req, res) => {
        try {
            const instanceId = req.query.instanceId || api.getActiveInstanceId();
            const dimension = req.query.dimension || 'minecraft:overworld';
            const x = parseInt(req.query.x, 10);
            const z = parseInt(req.query.z, 10);
            if (isNaN(x) || isNaN(z)) return res.status(400).send('Missing coordinates');

            const chunkX = Math.floor(x / 16);
            const chunkZ = Math.floor(z / 16);
            const localX = ((x % 16) + 16) % 16;
            const localZ = ((z % 16) + 16) % 16;

            const cacheKey = `${instanceId}_${dimension}_${chunkX}_${chunkZ}`;
            if (biomeCache.has(cacheKey)) {
                return res.json({ biome: biomeCache.get(cacheKey) });
            }

            const regionX = Math.floor(chunkX / 32);
            const regionZ = Math.floor(chunkZ / 32);
            const localCX = ((chunkX % 32) + 32) % 32;
            const localCZ = ((chunkZ % 32) + 32) % 32;

            const instanceDir = api.getInstanceDir(instanceId);
            const mcaPath = path.join(getRegionPath(instanceDir, dimension), `r.${regionX}.${regionZ}.mca`);
            if (!await fs.pathExists(mcaPath)) return res.json({ biome: null });

            const mcaBuf = await fs.readFile(mcaPath);
            const decomp = extractChunkFromBuffer(mcaBuf, localCX, localCZ);
            if (!decomp) return res.json({ biome: null });

            const reader = new FastNBTReader(decomp);
            const nbt = reader.readTag(new Set(['sections'])).value;
            let foundBiome = null;

            if (nbt) {
                const sections = nbt.sections?.value || nbt.sections || [];
                const sec = sections.find(s => s.Y === 4 || s.Y === 5 || s.Y === 3) || sections[0];
                if (sec) {
                    foundBiome = getBiomeAt(sec, localX, localZ, 70);
                }
            }

            if (foundBiome) {
                if (biomeCache.size >= 1000) biomeCache.delete(biomeCache.keys().next().value);
                biomeCache.set(cacheKey, foundBiome);
                return res.json({ biome: foundBiome });
            }

            res.json({ biome: null });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    router.get('/players', async (req, res) => {
        try {
            ensureTracking();
            const instanceId = req.query.instanceId || api.getActiveInstanceId();
            const instanceDir = api.getInstanceDir(instanceId);
            const levelName = getLevelName(instanceDir);
            const playerdataDir = path.join(instanceDir, levelName, 'playerdata');
            const userCacheFile = path.join(instanceDir, 'usercache.json');

            let uuidToName = {};
            if (await fs.pathExists(userCacheFile)) {
                try {
                    const uStat = await fs.stat(userCacheFile);
                    if (userCacheMemory.mtime === uStat.mtimeMs) {
                        uuidToName = userCacheMemory.mapping;
                    } else {
                        const list = await fs.readJson(userCacheFile);
                        const map = {};
                        for (const entry of list) {
                            if (entry.uuid && entry.name) map[entry.uuid] = entry.name;
                        }
                        userCacheMemory.mtime = uStat.mtimeMs;
                        userCacheMemory.mapping = map;
                        uuidToName = map;
                    }
                } catch (e) {}
            }

            const datPlayers = [];
            if (await fs.pathExists(playerdataDir)) {
                const files = await fs.readdir(playerdataDir);
                for (const file of files) {
                    if (!file.endsWith('.dat')) continue;
                    const uuid = file.slice(0, -4);
                    const filePath = path.join(playerdataDir, file);
                    try {
                        const stat = await fs.stat(filePath);
                        const cached = playerDataCache.get(uuid);
                        if (cached && cached.mtime === stat.mtimeMs) {
                            datPlayers.push(cached.data);
                            continue;
                        }

                        const raw = await fs.readFile(filePath);
                        const data = zlib.gunzipSync(raw);
                        const nbt = new FastNBTReader(data).readTag(new Set(['Pos', 'Dimension', 'Health', 'foodLevel'])).value;
                        if (nbt) {
                            const name = uuidToName[uuid] || uuid;
                            let x = 0, y = 0, z = 0;
                            if (nbt.Pos && nbt.Pos.length === 3) {
                                x = nbt.Pos[0]; y = nbt.Pos[1]; z = nbt.Pos[2];
                            }
                            const pObj = {
                                uuid, name,
                                x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10, z: Math.round(z * 10) / 10,
                                dimension: nbt.Dimension || 'minecraft:overworld',
                                health: nbt.Health ?? null,
                                foodLevel: nbt.foodLevel ?? null
                            };
                            playerDataCache.set(uuid, { mtime: stat.mtimeMs, data: pObj });
                            datPlayers.push(pObj);
                        }
                    } catch (err) {}
                }
            }

            let onlineNames = [];
            try { onlineNames = api.getOnlinePlayers(instanceId); } catch (e) {}

            const seen = new Set();
            const players = [];

            for (const name of onlineNames) {
                if (seen.has(name)) continue;
                seen.add(name);
                const cached = positionCache.get(name);
                if (cached && Date.now() - cached.timestamp < 30000) {
                    players.push({
                        uuid: datPlayers.find(p => p.name === name)?.uuid || name,
                        name,
                        x: Math.round(cached.x * 10) / 10,
                        y: Math.round(cached.y * 10) / 10,
                        z: Math.round(cached.z * 10) / 10,
                        dimension: cached.dimension || 'minecraft:overworld',
                        health: cached.health ?? null,
                        foodLevel: cached.foodLevel ?? null,
                        online: true
                    });
                } else {
                    const datP = datPlayers.find(p => p.name === name);
                    if (datP) players.push({ ...datP, online: true });
                    else players.push({ uuid: name, name, x: 0, y: 0, z: 0, dimension: 'minecraft:overworld', health: null, foodLevel: null, online: true });
                }
            }

            for (const p of datPlayers) {
                if (!seen.has(p.name)) {
                    seen.add(p.name);
                    players.push({ ...p, online: false });
                }
            }

            res.json(players);
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    router.get('/entities', async (req, res) => res.json({ categories: {} }));
    router.get('/entity-settings', (req, res) => res.json(entitySettings));
    router.post('/entity-settings', (req, res) => res.json(entitySettings));
    router.get('/entity-names', (req, res) => res.json(ENTITY_NAMES));

    router.post('/start-tracking', (req, res) => {
        ensureTracking();
        res.json({ success: true });
    });

    router.post('/stop-tracking', (req, res) => {
        stopTracking();
        positionCache.clear();
        playerDataCache.clear();
        biomeCache.clear();
        res.json({ success: true });
    });

    api.registerRoutes('/', router);
    api.registerSidebarItem({ id: 'server-map', view: 'server-map-view', labelKey: '服务器地图', icon: 'fa-map-location-dot', color: '#10b981', location: 'instance' });
    api.registerComponent('server-map-view', 'component/MainView.js');

    console.log('[Map Plugin v1.1.0] High-quality rendering backend initialized.');
};
