import { ref, onMounted } from '/js/vue.esm-browser.js';

export default {
    template: `
    <div class="p-4 p-md-5">
        <div class="container-xxl p-0">
            <div class="d-flex align-items-center mb-4">
                <div class="p-3 rounded-4 bg-primary bg-opacity-10 text-primary me-3">
                    <i class="fa-solid fa-vial-circle-check fa-2x"></i>
                </div>
                <div>
                    <h3 class="fw-black m-0 tracking-tight">插件系统功能测试</h3>
                    <p class="text-muted m-0 small">验证依赖安装、公共路由及热重载机制</p>
                </div>
            </div>

            <div class="row g-4">
                <!-- Node 依赖测试 -->
                <div class="col-12 col-xl-6">
                    <div class="card border-0 shadow-sm rounded-4 h-100 overflow-hidden" style="background: var(--c-surface-elevated);">
                        <div class="card-body p-4">
                            <h5 class="fw-bold mb-3 d-flex align-items-center">
                                <i class="fa-brands fa-node-js me-2 text-success"></i>Node.js 依赖测试
                            </h5>
                            <p class="small text-muted mb-4">本插件在 <code>plugin.json</code> 中声明了 <code>lodash</code> 依赖。如果安装成功，下方将显示 lodash 版本号。</p>
                            
                            <div class="p-3 rounded-3 bg-dark bg-opacity-25 border border-white border-opacity-10 mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted small">依赖包名称:</span>
                                    <span class="badge bg-success bg-opacity-10 text-success fw-bold">lodash</span>
                                </div>
                                <hr class="my-2 opacity-10">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted small">当前状态:</span>
                                    <span v-if="lodashVersion === '尚未完成安装'" class="text-warning small animate-pulse">
                                        <i class="fa-solid fa-spinner fa-spin me-1"></i>安装中或加载失败
                                    </span>
                                    <span v-else class="text-success fw-bold">{{ lodashVersion }}</span>
                                </div>
                            </div>
                            <button @click="testPublicApi" class="btn btn-sm btn-outline-primary w-100 rounded-3 py-2">
                                <i class="fa-solid fa-rotate me-1"></i>刷新状态 (请求公共接口)
                            </button>
                        </div>
                    </div>
                </div>

                <!-- API 接口测试 -->
                <div class="col-12 col-xl-6">
                    <div class="card border-0 shadow-sm rounded-4 h-100 overflow-hidden" style="background: var(--c-surface-elevated);">
                        <div class="card-body p-4">
                            <h5 class="fw-bold mb-3 d-flex align-items-center">
                                <i class="fa-solid fa-network-wired me-2 text-info"></i>API 路由测试
                            </h5>
                            
                            <div class="mb-3">
                                <label class="small fw-bold text-muted mb-2">公共接口 (不带认证)</label>
                                <div class="input-group input-group-sm mb-2">
                                    <span class="input-group-text bg-dark border-0 text-muted font-monospace" style="font-size: 0.7rem;">GET</span>
                                    <input type="text" class="form-control bg-dark border-0 text-info font-monospace" readonly value="/api/public/plugins/mc-panel-plugin-api-test/status" style="font-size: 0.7rem;">
                                    <button @click="testPublicApi" class="btn btn-primary px-3"><i class="fa-solid fa-play"></i></button>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="small fw-bold text-muted mb-2">私有接口 (带 Session 认证)</label>
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text bg-dark border-0 text-muted font-monospace" style="font-size: 0.7rem;">GET</span>
                                    <input type="text" class="form-control bg-dark border-0 text-info font-monospace" readonly value="/api/plugins/mc-panel-plugin-api-test/hello" style="font-size: 0.7rem;">
                                    <button @click="testPrivateApi" class="btn btn-info text-white px-3"><i class="fa-solid fa-play"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 测试结果 -->
                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden" style="background: var(--c-surface-elevated);">
                        <div class="card-header bg-transparent border-bottom border-white border-opacity-10 p-4">
                            <h6 class="m-0 fw-bold d-flex align-items-center">
                                <i class="fa-solid fa-terminal me-2 opacity-50"></i>API 响应结果
                                <button @click="results = []" class="btn btn-link btn-sm ms-auto p-0 text-muted">清空</button>
                            </h6>
                        </div>
                        <div class="card-body p-0">
                            <div class="p-4 overflow-auto custom-scrollbar" style="max-height: 300px; background: #0c0c0c;">
                                <div v-for="(res, idx) in results" :key="idx" class="mb-3 border-start border-3 ps-3" :class="res.success ? 'border-success' : 'border-danger'">
                                    <div class="d-flex justify-content-between mb-1">
                                        <span class="badge" :class="res.success ? 'bg-success' : 'bg-danger'">{{ res.type }}</span>
                                        <span class="text-muted" style="font-size: 0.7rem;">{{ res.time }}</span>
                                    </div>
                                    <pre class="m-0 text-info small font-monospace" style="white-space: pre-wrap;">{{ JSON.stringify(res.data, null, 2) }}</pre>
                                </div>
                                <div v-if="results.length === 0" class="text-center py-5 text-muted small opacity-50">
                                    点击上方的播放按钮开始测试接口调用
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `,
    setup() {
        const lodashVersion = ref('尚未完成安装');
        const results = ref([]);

        const addResult = (type, success, data) => {
            results.value.unshift({
                type,
                success,
                data,
                time: new Date().toLocaleTimeString()
            });
        };

        const testPublicApi = async () => {
            try {
                // 注意：由于是公共接口，我们直接用 fetch 或 axios
                const res = await axios.get('/api/public/plugins/mc-panel-plugin-api-test/status');
                addResult('PUBLIC API', true, res.data);
                if (res.data.lodash_version) {
                    lodashVersion.value = res.data.lodash_version;
                }
            } catch (e) {
                addResult('PUBLIC API', false, e.response?.data || e.message);
            }
        };

        const testPrivateApi = async () => {
            try {
                // 私有接口通常用已经配置好 auth 的 api 工具
                const res = await axios.get('/api/plugins/mc-panel-plugin-api-test/hello');
                addResult('PRIVATE API', true, res.data);
            } catch (e) {
                addResult('PRIVATE API', false, e.response?.data || e.message);
            }
        };

        onMounted(() => {
            testPublicApi();
        });

        return {
            lodashVersion,
            results,
            testPublicApi,
            testPrivateApi
        };
    }
};
