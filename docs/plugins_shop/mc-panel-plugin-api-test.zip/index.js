const path = require('path');
const express = require('express');

module.exports = (api) => {
    // Try to load lodash initially
    let lodash = null;
    const tryLoadLodash = () => {
        try {
            lodash = require('lodash');
            console.log('[API Test Plugin] Lodash loaded successfully');
            return true;
        } catch (e) {
            console.warn('[API Test Plugin] Lodash not found yet');
            return false;
        }
    };
    
    tryLoadLodash();

    // 1. 注册公共路由 (无需认证)
    // 最终访问路径: /api/public/plugins/mc-panel-plugin-api-test/status
    const publicRouter = express.Router();
    publicRouter.get('/status', (req, res) => {
        // 动态尝试加载 lodash (如果之前失败了)
        if (!lodash) tryLoadLodash();

        res.json({
            status: 'online',
            plugin: api.id,
            time: new Date().toLocaleString(),
            lodash_version: lodash ? lodash.VERSION : '尚未完成安装',
            message: '这是一个公共 API 接口，无需登录即可从外部调用。'
        });
    });
    api.registerPublicRoutes('/', publicRouter);

    // 2. 注册私有路由 (需要认证)
    // 最终访问路径: /api/plugins/mc-panel-plugin-api-test/hello
    const privateRouter = express.Router();
    privateRouter.get('/hello', (req, res) => {
        res.json({
            message: '你好！这是一个受保护的接口，您已成功通过身份验证。',
            timestamp: Date.now()
        });
    });
    api.registerRoutes('/', privateRouter);

    // 3. 注册侧边栏项目
    api.registerSidebarItem({
        id: 'api-test',
        view: 'api-test-view',
        labelKey: '插件系统测试',
        icon: 'fa-vial-circle-check',
        color: '#8b5cf6',
        location: 'global'
    });

    // 4. 注册组件
    api.registerComponent('api-test-view', 'component/MainView.js');

    console.log('[API Test Plugin] Backend logic initialized');
};
