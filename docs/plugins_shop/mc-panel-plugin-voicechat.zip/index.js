module.exports = (api) => {
    api.registerSidebarItem({
        id: 'voicechat',
        labelKey: 'sidebar.voicechat',
        icon: 'fa-microphone',
        view: 'voicechat-view',
        location: 'instance'
    });
    api.registerComponent('voicechat-view', 'component/VoicechatView.js');
};
