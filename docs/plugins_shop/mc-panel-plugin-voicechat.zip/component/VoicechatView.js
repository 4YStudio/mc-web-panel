import { ref, reactive, onMounted, computed, getCurrentInstance } from '/js/vue.esm-browser.js';
import { api } from '/js/api.js';
import { store } from '/js/store.js';
import { showToast } from '/js/utils.js';

export default {
    template: `
    <div class="animate-in">
        <div v-if="!hasVoicechat" class="d-flex flex-column align-items-center justify-content-center py-5 text-muted">
            <i class="fa-solid fa-microphone-slash fa-4x mb-3 opacity-25"></i>
            <h4>未检测到 Simple Voice Chat 模组</h4>
            <p class="mt-2 text-center">此功能专为 <b>Simple Voice Chat (简单语音聊天)</b> 模组设计。<br>如已安装其他版本或文件名特殊的模组，您可以强制打开配置界面。</p>
            <div class="mt-4 d-flex gap-2">
                <button class="btn btn-primary px-4 rounded-pill fw-bold" @click="store.view = 'modrinth'">
                    <i class="fa-solid fa-cloud-arrow-down me-2"></i>前往下载
                </button>
                <button class="btn btn-outline-secondary px-4 rounded-pill fw-bold" @click="forceOpenConfig">
                    <i class="fa-solid fa-gear me-2"></i>{{ $t('voice.open_anyway') }}
                </button>
            </div>
        </div>

        <template v-else>
            <div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <div>
                    <h3 class="mb-1 text-nowrap">{{ $t('voice.title') }}</h3>
                    <div class="small text-muted d-flex align-items-center gap-2">
                        <i class="fa-regular fa-file-code"></i>
                        <span class="font-monospace text-truncate" style="max-width: 240px;">{{ configFilePath }}</span>
                        <span v-if="!fileExists" class="badge bg-warning-subtle text-warning border border-warning-subtle">{{ $t('voice.template_notice') }}</span>
                    </div>
                </div>
                <div class="btn-group">
                    <button class="btn btn-outline-secondary" @click="toggleEditMode">
                        <i class="fa-solid" :class="editMode==='gui'?'fa-code':'fa-sliders'"></i>
                        <span class="d-none d-md-inline ms-1">{{ editMode==='gui' ? $t('common.mode_text') : $t('common.mode_gui') }}</span>
                    </button>
                    <button class="btn btn-success" @click="saveConfig" :disabled="saving">
                        <i class="fa-solid fa-save me-0 me-md-2"></i><span class="d-none d-md-inline">{{ saving ? $t('common.saving') : $t('common.save') }}</span>
                    </button>
                </div>
            </div>

            <Transition name="fade" mode="out-in">
                <!-- 图形化编辑器 -->
                <div v-if="editMode === 'gui'" class="row g-3 pb-4" key="gui">
                    <div class="col-lg-6" v-for="(group, idx) in vcGroups" :key="idx">
                        <div class="card h-100 border-secondary shadow-sm" style="background-color: var(--c-surface) !important;">
                            <div class="card-header bg-body-tertiary fw-bold border-secondary d-flex align-items-center">
                                <i :class="group.icon" class="me-2 text-primary"></i>
                                <span>{{ group.title }}</span>
                            </div>
                            <div class="card-body">
                                <div v-for="item in group.items" :key="item.key" class="mb-3 row align-items-center">
                                    <label class="col-sm-5 col-form-label small fw-semibold text-body-secondary">{{ item.label }}</label>
                                    <div class="col-sm-7">
                                        <div v-if="item.type === 'boolean'" class="form-check form-switch m-0">
                                            <input class="form-check-input" type="checkbox" v-model="formModel[item.key]">
                                        </div>
                                        <CustomSelect v-else-if="item.type === 'select'" v-model="formModel[item.key]" :options="item.options" size="sm" />
                                        <input v-else :type="item.type" class="form-control form-control-sm" v-model="formModel[item.key]" :placeholder="item.placeholder || ''">
                                        <div v-if="item.desc" class="form-text text-muted small mt-1" style="font-size: 0.72rem; line-height: 1.2;">{{ item.desc }}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="alert alert-info py-2 d-flex align-items-center">
                            <i class="fa-solid fa-circle-info me-2 fs-5"></i>
                            <div class="small">{{ $t('voice.restart_required') }}</div>
                        </div>
                    </div>
                </div>

                <!-- 文本编辑器 -->
                <div v-else class="h-100 pb-3" key="text">
                    <div class="card h-100 shadow-sm border-secondary" style="background-color: var(--c-surface) !important;">
                        <div class="card-header bg-body-tertiary small text-muted border-secondary d-flex justify-content-between">
                            <span><i class="fa-regular fa-file-lines me-2"></i>{{ configFilePath }}</span>
                            <span class="badge bg-secondary-subtle text-secondary">{{ lineCount }} 行</span>
                        </div>
                        <textarea class="form-control border-0 rounded-0 h-100"  
                            style="font-family: var(--font-monospace, monospace); resize: none; min-height: 65vh; background: transparent; color: inherit; line-height: 1.5;" 
                            v-model="fileContent" 
                            spellcheck="false"
                        ></textarea>
                    </div>
                </div>
            </Transition>
        </template>
    </div>
    `,
    setup() {
        const editMode = ref('gui');
        const fileContent = ref('');
        const configFilePath = ref('config/voicechat/voicechat-server.properties');
        const fileExists = ref(true);
        const configLoaded = ref(false);
        const forceOpen = ref(false);
        const saving = ref(false);
        const formModel = reactive({});
        const { proxy } = getCurrentInstance();
        const $t = proxy.$t;

        const hasVoicechat = computed(() => {
            return Boolean(store.hasVoicechat || store.stats?.hasVoicechat || configLoaded.value || forceOpen.value);
        });

        const lineCount = computed(() => {
            return fileContent.value ? fileContent.value.split('\n').length : 0;
        });

        const forceOpenConfig = () => {
            forceOpen.value = true;
            loadFile();
        };

        const vcGroups = computed(() => [
            {
                title: $t('voice.network'),
                icon: 'fa-solid fa-network-wired',
                items: [
                    { key: 'port', label: $t('voice.port'), type: 'number', desc: $t('voice.port_desc'), placeholder: '24454' },
                    { key: 'voice_host', label: $t('voice.host'), type: 'text', desc: $t('voice.host_desc'), placeholder: 'example.com:24454' },
                    { key: 'bind_address', label: $t('voice.bind_address'), type: 'text', desc: $t('voice.bind_address_desc'), placeholder: '* 或留空' },
                    { key: 'allow_pings', label: $t('voice.allow_pings'), type: 'boolean', desc: $t('voice.allow_pings_desc') }
                ]
            },
            {
                title: $t('voice.quality_distance'),
                icon: 'fa-solid fa-sliders',
                items: [
                    { key: 'max_voice_distance', label: $t('voice.max_distance'), type: 'number', desc: $t('voice.max_distance_desc'), placeholder: '48.0' },
                    { key: 'whisper_distance', label: $t('voice.whisper_distance'), type: 'number', desc: $t('voice.whisper_distance_desc'), placeholder: '24.0' },
                    { key: 'broadcast_range', label: $t('voice.broadcast_range'), type: 'number', desc: $t('voice.broadcast_range_desc'), placeholder: '-1.0' },
                    { key: 'codec', label: $t('voice.codec'), type: 'select', options: ['VOIP', 'AUDIO', 'RESTRICTED_LOWDELAY'], desc: $t('voice.codec_desc') },
                    { key: 'mtu_size', label: $t('voice.mtu_size'), type: 'number', desc: $t('voice.mtu_size_desc'), placeholder: '1024' }
                ]
            },
            {
                title: $t('voice.groups_permissions'),
                icon: 'fa-solid fa-users-gear',
                items: [
                    { key: 'enable_groups', label: $t('voice.enable_groups'), type: 'boolean', desc: $t('voice.enable_groups_desc') },
                    { key: 'allow_recording', label: $t('voice.allow_recording'), type: 'boolean', desc: $t('voice.allow_recording_desc') },
                    { key: 'spectator_interaction', label: $t('voice.spectator_interaction'), type: 'boolean', desc: $t('voice.spectator_interaction_desc') },
                    { key: 'spectator_player_possession', label: $t('voice.spectator_player_possession'), type: 'boolean', desc: $t('voice.spectator_player_possession_desc') }
                ]
            },
            {
                title: $t('voice.security_performance'),
                icon: 'fa-solid fa-shield-halved',
                items: [
                    { key: 'force_voice_chat', label: $t('voice.force_voice_chat'), type: 'boolean', desc: $t('voice.force_voice_chat_desc') },
                    { key: 'login_timeout', label: $t('voice.login_timeout'), type: 'number', desc: $t('voice.login_timeout_desc'), placeholder: '10000' },
                    { key: 'tcp_rate_limit', label: $t('voice.tcp_rate_limit'), type: 'number', desc: $t('voice.tcp_rate_limit_desc'), placeholder: '16' },
                    { key: 'keep_alive', label: $t('voice.keep_alive'), type: 'number', desc: $t('voice.keep_alive_desc'), placeholder: '1000' },
                    { key: 'use_natives', label: $t('voice.use_natives'), type: 'boolean', desc: $t('voice.use_natives_desc') },
                    { key: 'threaded_server_support', label: $t('voice.threaded_server_support'), type: 'boolean', desc: $t('voice.threaded_server_support_desc') }
                ]
            }
        ]);

        const createRegex = (key) => new RegExp(`^[ \\t]*${key}[ \\t]*=[ \\t]*(.*)$`, 'm');

        const loadFile = async () => {
            try {
                const res = await api.get('/api/voicechat/config');
                fileContent.value = res.data.content || '';
                configFilePath.value = res.data.filePath || 'config/voicechat/voicechat-server.properties';
                fileExists.value = res.data.exists !== false;
                configLoaded.value = true;
                parseToGui();
            } catch (e) {
                console.error('Failed to load voicechat config:', e);
                showToast($t('common.error') + ': ' + (e.response?.data?.error || e.message), 'danger');
            }
        };

        const parseToGui = () => {
            const text = fileContent.value;
            vcGroups.value.forEach(group => {
                group.items.forEach(item => {
                    let match = text.match(createRegex(item.key));
                    // 兼容旧版或别名
                    if (!match && item.key === 'max_voice_distance') {
                        match = text.match(createRegex('voice_distance'));
                    }
                    if (match) {
                        let valStr = match[1].trim();
                        if (item.type === 'boolean') {
                            formModel[item.key] = (valStr.toLowerCase() === 'true');
                        } else if (item.type === 'number') {
                            formModel[item.key] = valStr === '' ? '' : Number(valStr);
                        } else {
                            formModel[item.key] = valStr;
                        }
                    } else {
                        if (item.type === 'boolean') formModel[item.key] = false;
                        else if (item.key === 'port') formModel[item.key] = 24454;
                        else if (item.key === 'codec') formModel[item.key] = 'VOIP';
                        else formModel[item.key] = '';
                    }
                });
            });
        };

        const syncToText = () => {
            let text = fileContent.value || '';
            vcGroups.value.forEach(group => {
                group.items.forEach(item => {
                    const val = formModel[item.key];
                    if (val !== undefined) {
                        const targetKey = item.key;
                        const valStr = String(val);
                        const mainRegex = createRegex(targetKey);
                        const legacyRegex = (targetKey === 'max_voice_distance') ? createRegex('voice_distance') : null;

                        if (mainRegex.test(text)) {
                            text = text.replace(mainRegex, `${targetKey}=${valStr}`);
                        } else if (legacyRegex && legacyRegex.test(text)) {
                            text = text.replace(legacyRegex, `${targetKey}=${valStr}`);
                        } else {
                            if (text && !text.endsWith('\n')) text += '\n';
                            text += `${targetKey}=${valStr}\n`;
                        }
                    }
                });
            });
            fileContent.value = text;
        };

        const saveConfig = async () => {
            if (editMode.value === 'gui') syncToText();
            try {
                saving.value = true;
                await api.post('/api/voicechat/save', {
                    content: fileContent.value,
                    filePath: configFilePath.value
                });
                fileExists.value = true;
                showToast($t('voice.saved'));
            } catch (e) {
                showToast($t('common.error') + ': ' + (e.response?.data?.error || e.message), 'danger');
            } finally {
                saving.value = false;
            }
        };

        const toggleEditMode = () => {
            if (editMode.value === 'text') {
                parseToGui();
                editMode.value = 'gui';
            } else {
                syncToText();
                editMode.value = 'text';
            }
        };

        onMounted(() => {
            loadFile();
        });

        return {
            store,
            hasVoicechat,
            editMode,
            fileContent,
            configFilePath,
            fileExists,
            saving,
            formModel,
            vcGroups,
            lineCount,
            forceOpenConfig,
            saveConfig,
            toggleEditMode
        };
    }
};
