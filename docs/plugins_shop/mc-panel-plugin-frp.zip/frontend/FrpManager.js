import { ref, reactive, computed, onMounted, onUnmounted, getCurrentInstance, watch, nextTick } from '/js/vue.esm-browser.js';
import { api } from '/js/api.js';
import { store } from '/js/store.js';
import { showToast, openModal } from '/js/utils.js';
import { messages } from '/js/i18n.js';

// 组件内嵌本地完整双语字典，三层加固，杜绝任何情况下显示未翻译的原始键名
const I18N_LOCAL = {
    zh: {
        title: 'FRP 内网穿透',
        switch_version: '安装/更换',
        new_config: '新建配置',
        import_config: '导入配置',
        not_installed: '未安装 FRP 客户端',
        install: '立即安装',
        config_list: '配置列表',
        running: '运行中',
        stopped: '已停止',
        uninstall: '卸载 FRP',
        uninstall_confirm: '确定要卸载 FRP 客户端吗？所有运行中的进程都将被停止。',
        no_configs: '暂无 FRP 配置文件',
        no_configs_hint: '您可以点击上方按钮手动新建或直接导入已有穿透配置',
        start: '启动',
        stop: '停止',
        restart: '重启',
        logs: '运行日志',
        version_manager: '版本管理',
        use_github_proxy: '使用 GitHub 代理加速',
        proxy_url: '代理加速地址',
        proxy_url_placeholder: '例如：https://ghfast.top/ 或 https://mirror.ghproxy.com/',
        proxy_tips: '国内网络下载慢或超时可开启代理加速',
        proxy_presets: '常用预设',
        fetch_releases: '获取版本列表中...',
        no_releases: '无法获取版本列表，请检查网络',
        latest: '最新版',
        installed: '已安装',
        edit_config: '编辑配置',
        config_name: '配置名称',
        config_name_placeholder: '例如：我的生存服穿透',
        config: '配置参数',
        config_format: '配置格式',
        format_toml: 'TOML 格式 (.toml)',
        format_ini: 'INI 格式 (.ini)',
        import_file: '导入文件',
        import_file_tip: '支持导入 .ini、.toml、.conf、.txt 等内网穿透配置文件',
        import_clipboard: '剪贴板导入',
        import_clipboard_tip: '一键粘贴来自内网穿透平台的配置内容',
        clipboard_modal_title: '从剪贴板粘贴配置',
        clipboard_modal_desc: '请将内网穿透平台（如 SakuraFrp、ME Frp、OpenFrp 等）提供的配置内容粘贴到下方：',
        clipboard_modal_confirm: '确认导入',
        import_success: '导入成功 (已识别为 {format} 格式)',
        import_fail: '导入失败：未能解析有效配置',
        clipboard_empty: '剪贴板内容为空',
        clipboard_denied: '浏览器未授予剪贴板读取权限，已打开手动粘贴输入框',
        gui_mode: '图形模式',
        text_mode: '文本模式',
        server_addr: '服务器地址',
        server_addr_desc: '填写 FRP 服务端 (frps) 的公网 IP 或域名',
        server_port: '服务器端口',
        server_port_desc: '对应服务端的通信端口 (如 7000)',
        auth_token: '认证密钥 (Token)',
        auth_token_desc: '需与服务端配置的 token 一致',
        tunnels: '隧道列表',
        add_tunnel: '添加隧道',
        tunnel_name: '隧道名称',
        tunnel_type: '协议类型',
        local_ip: '本地 IP',
        local_port: '本地端口',
        remote_port: '远程端口',
        no_tunnels: '暂无隧道，请点击上方添加',
        save_config: '保存配置',
        config_saved: '配置已保存',
        config_name_required: '请填写配置名称',
        delete_config_confirm: '确定要删除配置 "{name}" 吗？运行中的进程将被停止。',
        started_success: 'FRP 已成功启动',
        stopped_success: 'FRP 已停止',
        start_fail: '启动失败',
        format_switch_tip: '切换格式时将自动转换当前配置内容',
        cancel: '取消',
        save: '保存',
        delete: '删除',
        refresh: '刷新',
        no_data: '暂无数据',
        error: '操作失败',
        success: '操作成功'
    },
    en: {
        title: 'FRP Tunnel Manager',
        switch_version: 'Install / Switch',
        new_config: 'New Config',
        import_config: 'Import Config',
        not_installed: 'FRP Client Not Installed',
        install: 'Install Now',
        config_list: 'Configs',
        running: 'Running',
        stopped: 'Stopped',
        uninstall: 'Uninstall FRP',
        uninstall_confirm: 'Are you sure you want to uninstall FRP client? All running processes will be stopped.',
        no_configs: 'No FRP Configurations',
        no_configs_hint: 'Click above to create a new config or import an existing tunnel configuration',
        start: 'Start',
        stop: 'Stop',
        restart: 'Restart',
        logs: 'Logs',
        version_manager: 'Version Manager',
        use_github_proxy: 'Use GitHub Proxy',
        proxy_url: 'Proxy URL',
        proxy_url_placeholder: 'e.g. https://ghfast.top/ or https://mirror.ghproxy.com/',
        proxy_tips: 'Recommended if GitHub download is slow or timing out',
        proxy_presets: 'Presets',
        fetch_releases: 'Fetching releases...',
        no_releases: 'Failed to fetch releases, check network',
        latest: 'Latest',
        installed: 'Installed',
        edit_config: 'Edit Config',
        config_name: 'Config Name',
        config_name_placeholder: 'e.g. My Survival Server Tunnel',
        config: 'Parameters',
        config_format: 'Config Format',
        format_toml: 'TOML Format (.toml)',
        format_ini: 'INI Format (.ini)',
        import_file: 'Import File',
        import_file_tip: 'Supports importing .ini, .toml, .conf, .txt config files',
        import_clipboard: 'Clipboard',
        import_clipboard_tip: 'Paste tunnel config directly from clipboard',
        clipboard_modal_title: 'Paste Config from Clipboard',
        clipboard_modal_desc: 'Paste your tunnel configuration (from SakuraFrp, ME Frp, OpenFrp, etc.) below:',
        clipboard_modal_confirm: 'Confirm Import',
        import_success: 'Imported successfully (detected as {format} format)',
        import_fail: 'Import failed: Unable to parse valid config',
        clipboard_empty: 'Clipboard is empty',
        clipboard_denied: 'Clipboard access denied, opened paste dialog instead',
        gui_mode: 'GUI Mode',
        text_mode: 'Text Mode',
        server_addr: 'Server Address',
        server_addr_desc: 'Public IP or domain of frps server',
        server_port: 'Server Port',
        server_port_desc: 'Port used by frps server (e.g. 7000)',
        auth_token: 'Auth Token',
        auth_token_desc: 'Must match server token',
        tunnels: 'Tunnels',
        add_tunnel: 'Add Tunnel',
        tunnel_name: 'Name',
        tunnel_type: 'Protocol',
        local_ip: 'Local IP',
        local_port: 'Local Port',
        remote_port: 'Remote Port',
        no_tunnels: 'No tunnels yet, click above to add',
        save_config: 'Save Config',
        config_saved: 'Configuration saved',
        config_name_required: 'Please enter config name',
        delete_config_confirm: 'Delete config "{name}"? Running processes will be stopped.',
        started_success: 'FRP started successfully',
        stopped_success: 'FRP stopped',
        start_fail: 'Start failed',
        format_switch_tip: 'Configuration will be converted when switching formats',
        cancel: 'Cancel',
        save: 'Save',
        delete: 'Delete',
        refresh: 'Refresh',
        no_data: 'No Data',
        error: 'Operation Failed',
        success: 'Operation Successful'
    }
};

export default {
    template: `
    <div class="h-100 d-flex flex-column animate-in overflow-hidden">
        <!-- Header -->
        <div class="page-header d-flex justify-content-between align-items-center flex-shrink-0">
            <div class="d-flex align-items-center overflow-hidden">
                <button @click="store.view = store.prevView || 'instance-manager'" class="btn-back me-3">
                    <i class="fa-solid fa-chevron-left"></i>
                </button>
                <h3 class="m-0 fw-bold d-flex align-items-center text-truncate">
                    <i class="fa-solid fa-network-wired me-2 me-md-3 text-primary d-none d-md-inline"></i>
                    <span>{{ t('frp.title') }}</span>
                </h3>
            </div>
            <div class="d-flex gap-2 align-items-center">
                <button v-if="status.installed" class="btn btn-sm btn-outline-primary fw-bold rounded-pill px-3" @click="openReleasesModal" style="font-size: 0.75rem;">
                    <i class="fa-solid fa-rotate me-1"></i>{{ t('frp.switch_version') }}
                </button>
                <button class="btn btn-sm btn-outline-secondary fw-bold rounded-pill px-3 shadow-sm" @click="openDirectImportModal" :disabled="!status.installed" style="font-size: 0.75rem;">
                    <i class="fa-solid fa-file-arrow-up me-1"></i>{{ t('frp.import_config') }}
                </button>
                <button class="btn btn-sm btn-primary fw-bold rounded-pill px-3 shadow-sm" @click="createNewConfig" :disabled="!status.installed" style="font-size: 0.75rem;">
                    <i class="fa-solid fa-plus me-1"></i>{{ t('frp.new_config') }}
                </button>
            </div>
        </div>

        <div class="overflow-auto custom-scrollbar px-1 px-md-3 pb-4 flex-grow-1">

            <!-- 顶部状态横栏 -->
            <div class="card mb-3 mb-md-4 overflow-hidden">
                <div class="card-body p-0">
                    <div class="d-flex align-items-stretch flex-wrap">
                        <!-- 安装状态区 -->
                        <div class="d-flex align-items-center gap-3 px-3 px-md-4 py-3 flex-grow-1" style="min-width: 220px;">
                            <div class="rounded-3 d-flex align-items-center justify-content-center flex-shrink-0"
                                 :class="status.installed ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary'"
                                 style="width: 44px; height: 44px; border-radius: 12px !important;">
                                <i class="fa-solid" :class="status.installed ? 'fa-check-circle' : 'fa-cloud-arrow-down'" style="font-size: 1.2rem;"></i>
                            </div>
                            <div v-if="status.installed" class="overflow-hidden">
                                <div class="fw-bold text-truncate">frpc <span class="text-primary">v{{ status.version }}</span></div>
                                <div class="text-muted" style="font-size: 0.7rem;">{{ status.installedAt ? new Date(status.installedAt).toLocaleString() : '' }}</div>
                            </div>
                            <div v-else>
                                <div class="fw-bold text-muted">{{ t('frp.not_installed') }}</div>
                                <button class="btn btn-primary btn-sm fw-bold rounded-pill px-3 mt-1" @click="openReleasesModal" style="font-size: 0.72rem;">
                                    <i class="fa-solid fa-download me-1"></i>{{ t('frp.install') }}
                                </button>
                            </div>
                        </div>

                        <!-- 分隔线 + 统计 -->
                        <div v-if="status.installed" class="d-none d-md-flex align-items-center border-start" style="padding: 0 1.5rem;">
                            <div class="text-center">
                                <div class="fw-bold fs-5 text-primary">{{ configs.length }}</div>
                                <div class="text-muted" style="font-size: 0.68rem; text-transform: uppercase; letter-spacing: 0.5px;">{{ t('frp.config_list') }}</div>
                            </div>
                        </div>
                        <div v-if="status.installed" class="d-none d-md-flex align-items-center border-start" style="padding: 0 1.5rem;">
                            <div class="text-center">
                                <div class="fw-bold fs-5" :class="runningCount > 0 ? 'text-success' : 'text-secondary'">{{ runningCount }}</div>
                                <div class="text-muted" style="font-size: 0.68rem; text-transform: uppercase; letter-spacing: 0.5px;">{{ t('frp.running') }}</div>
                            </div>
                        </div>

                        <!-- 卸载按钮区 -->
                        <div v-if="status.installed" class="d-flex align-items-center ms-auto px-3 px-md-4">
                            <button class="btn btn-sm btn-outline-danger rounded-pill px-3 fw-bold" @click="askUninstall" style="font-size: 0.72rem;">
                                <i class="fa-solid fa-trash me-1"></i>{{ t('frp.uninstall') }}
                            </button>
                        </div>
                    </div>

                    <!-- 安装进度条 -->
                    <Transition name="fade">
                        <div v-if="activeInstall" class="border-top px-3 px-md-4 py-2 bg-body-tertiary">
                            <div class="d-flex align-items-center gap-2">
                                <span class="spinner-border spinner-border-sm text-primary" style="width: 12px; height: 12px;"></span>
                                <div class="flex-grow-1">
                                    <div class="modern-progress" style="height: 6px;">
                                        <div class="modern-progress-bar" :style="{width: (activeInstall.percent || 0) + '%'}"></div>
                                    </div>
                                </div>
                                <span class="text-muted text-nowrap" style="font-size: 0.7rem;" v-if="formattedSpeed">{{ formattedSpeed }}</span>
                                <span class="text-muted text-nowrap" style="font-size: 0.7rem;">{{ activeInstall.message }}</span>
                                <button class="btn btn-sm btn-link text-danger p-0 ms-1" @click="cancelInstall" :title="t('common.cancel')">
                                    <i class="fa-solid fa-times-circle"></i>
                                </button>
                            </div>
                        </div>
                    </Transition>
                </div>
            </div>

            <!-- 配置网格 -->
            <div v-if="status.installed">
                <!-- 空状态 -->
                <div v-if="configs.length === 0" class="card text-center py-5">
                    <div class="card-body">
                        <div class="rounded-circle bg-primary-subtle mx-auto d-flex align-items-center justify-content-center mb-3" style="width: 64px; height: 64px;">
                            <i class="fa-solid fa-route text-primary" style="font-size: 1.5rem;"></i>
                        </div>
                        <div class="fw-bold mb-1">{{ t('frp.no_configs') }}</div>
                        <div class="text-muted small mb-3">{{ t('frp.no_configs_hint') }}</div>
                        <div class="d-flex justify-content-center gap-2">
                            <button class="btn btn-outline-primary fw-bold rounded-pill px-4 shadow-sm" @click="openDirectImportModal">
                                <i class="fa-solid fa-file-arrow-up me-2"></i>{{ t('frp.import_config') }}
                            </button>
                            <button class="btn btn-primary fw-bold rounded-pill px-4 shadow-sm" @click="createNewConfig">
                                <i class="fa-solid fa-plus me-2"></i>{{ t('frp.new_config') }}
                            </button>
                        </div>
                    </div>
                </div>

                <!-- 配置卡片列表 -->
                <div v-else class="row g-3">
                    <div v-for="cfg in configs" :key="cfg.id" class="col-md-6 col-lg-4">
                        <div class="card h-100 frp-config-card" style="cursor: pointer;" @click="editConfig(cfg)">
                            <!-- 卡片顶部内容 -->
                            <div class="card-body p-3 p-md-4">
                                <div class="d-flex align-items-start justify-content-between mb-3">
                                    <div class="d-flex align-items-center gap-2 overflow-hidden">
                                        <div class="rounded-3 d-flex align-items-center justify-content-center flex-shrink-0"
                                             :class="cfg.running ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary'"
                                             style="width: 38px; height: 38px; border-radius: 10px !important;">
                                            <i class="fa-solid" :class="cfg.running ? 'fa-tower-broadcast' : 'fa-plug'" style="font-size: 0.95rem;"></i>
                                        </div>
                                        <div class="overflow-hidden">
                                            <div class="d-flex align-items-center gap-2">
                                                <span class="fw-bold text-truncate">{{ cfg.name }}</span>
                                                <span class="badge rounded-pill fw-bold" 
                                                      :class="cfg.format === 'ini' ? 'bg-warning-subtle text-warning border border-warning-subtle' : 'bg-primary-subtle text-primary border border-primary-subtle'" 
                                                      style="font-size: 0.62rem; padding: 2px 7px;">
                                                    {{ (cfg.format || 'toml').toUpperCase() }}
                                                </span>
                                            </div>
                                            <div class="d-flex align-items-center gap-1 mt-1" style="font-size: 0.7rem;">
                                                <span class="status-indicator" :class="cfg.running ? 'bg-success' : 'bg-secondary'" style="width: 6px; height: 6px;"></span>
                                                <span :class="cfg.running ? 'text-success' : 'text-muted'">{{ cfg.running ? t('frp.running') : t('frp.stopped') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- 创建时间 -->
                                <div class="text-muted mb-3" style="font-size: 0.68rem;">
                                    <i class="fa-regular fa-clock me-1"></i>{{ cfg.createdAt ? new Date(cfg.createdAt).toLocaleDateString() : '' }}
                                </div>

                                <!-- 操作按钮 -->
                                <div class="d-flex gap-2 frp-config-card-actions" @click.stop>
                                    <button v-if="!cfg.running" class="btn btn-success btn-sm flex-grow-1 fw-bold" @click.stop="startConfig(cfg)" style="border-radius: 10px; font-size: 0.75rem;">
                                        <i class="fa-solid fa-play me-1"></i>{{ t('frp.start') }}
                                    </button>
                                    <button v-else class="btn btn-danger btn-sm flex-grow-1 fw-bold" @click.stop="stopConfig(cfg)" style="border-radius: 10px; font-size: 0.75rem;">
                                        <i class="fa-solid fa-stop me-1"></i>{{ t('frp.stop') }}
                                    </button>
                                    <button v-if="cfg.running" class="btn btn-outline-warning btn-sm fw-bold px-2" @click.stop="restartConfig(cfg)" style="border-radius: 10px; font-size: 0.75rem;" :title="t('frp.restart')">
                                        <i class="fa-solid fa-rotate"></i>
                                    </button>
                                    <button v-if="cfg.running" class="btn btn-outline-secondary btn-sm fw-bold px-2" @click.stop="viewLogsFromCard(cfg)" style="border-radius: 10px; font-size: 0.75rem;" :title="t('frp.logs')">
                                        <i class="fa-solid fa-terminal"></i>
                                    </button>
                                    <button class="btn btn-outline-danger btn-sm fw-bold px-2 border-0" @click.stop="deleteConfig(cfg)" style="border-radius: 10px; font-size: 0.75rem;" :title="t('common.delete')">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 日志面板 -->
                <Transition name="fade">
                    <div v-if="selectedLogConfigId" class="card mt-3 mt-md-4">
                        <div class="card-header bg-body-tertiary border-0 fw-bold py-2 px-3 px-md-4 d-flex justify-content-between align-items-center" style="border-radius: 16px 16px 0 0;">
                            <span class="small text-uppercase text-muted">
                                <i class="fa-solid fa-terminal me-2"></i>{{ t('frp.logs') }}
                                <span class="badge bg-primary-subtle text-primary rounded-pill ms-1" style="font-size: 0.65rem;">{{ selectedLogConfigName }}</span>
                            </span>
                            <button class="btn btn-sm btn-link text-muted p-0" @click="selectedLogConfigId = null" :title="t('common.cancel')">
                                <i class="fa-solid fa-times"></i>
                            </button>
                        </div>
                        <div ref="logContainer" class="card-body p-0 overflow-auto custom-scrollbar font-monospace bg-dark text-success-emphasis"
                             style="max-height: 300px; font-size: 0.75rem; border-radius: 0 0 16px 16px;">
                            <div v-if="logs.length === 0" class="text-center text-muted py-4 small">
                                {{ t('common.no_data') }}
                            </div>
                            <div v-else class="p-3">
                                <div v-for="(line, i) in logs" :key="i" class="text-light" style="line-height: 1.6; word-break: break-all;">{{ line }}</div>
                            </div>
                        </div>
                    </div>
                </Transition>
            </div>
        </div>

        <!-- 版本管理器对话框 -->
        <Teleport to="body">
            <div class="modal fade" id="frpReleasesModal" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
                    <div class="modal-content border-0 shadow-lg" style="border-radius: 16px;">
                        <div class="modal-header border-0 pb-0 pt-4 px-4">
                            <h5 class="modal-title fw-bold"><i class="fa-solid fa-cloud-arrow-down me-2 text-primary"></i>{{ t('frp.version_manager') }}</h5>
                            <div class="d-flex align-items-center gap-2">
                                <button class="btn btn-sm btn-link text-primary p-0" @click="fetchReleases" :disabled="loadingReleases" :title="t('common.refresh')">
                                    <i class="fa-solid fa-rotate" :class="{'fa-spin': loadingReleases}"></i>
                                </button>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                        </div>

                        <div class="modal-body px-4 py-3">
                            <!-- GitHub 代理设置卡片 -->
                            <div class="card border-0 mb-3 shadow-none" style="background: var(--c-surface-elevated); border: 1px solid var(--c-border) !important; border-radius: 12px;">
                                <div class="card-body p-3">
                                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                                        <div class="form-check form-switch m-0 d-flex align-items-center gap-2">
                                            <input class="form-check-input mt-0 cursor-pointer" type="checkbox" id="frpUseProxySwitch" v-model="useGithubProxy" @change="saveProxySettings">
                                            <label class="form-check-label fw-bold small cursor-pointer text-body" for="frpUseProxySwitch">
                                                <i class="fa-brands fa-github me-1 text-primary"></i>{{ t('frp.use_github_proxy') }}
                                            </label>
                                        </div>
                                        <span class="small" style="font-size: 0.72rem; color: var(--c-text-tertiary);">{{ t('frp.proxy_tips') }}</span>
                                    </div>
                                    <div v-if="useGithubProxy" class="mt-2 pt-2 border-top" style="border-color: var(--c-border-subtle) !important;">
                                        <div class="input-group input-group-sm mb-2">
                                            <span class="input-group-text" style="background: var(--c-surface); border-color: var(--c-border); color: var(--c-primary);">
                                                <i class="fa-solid fa-link"></i>
                                            </span>
                                            <input type="text" class="form-control" style="background: var(--c-surface); border-color: var(--c-border); color: var(--c-text-primary);" v-model="githubProxyUrl" @input="saveProxySettings" :placeholder="t('frp.proxy_url_placeholder')">
                                        </div>
                                        <div class="d-flex flex-wrap gap-1 align-items-center">
                                            <span style="font-size: 0.72rem; color: var(--c-text-secondary);">{{ t('frp.proxy_presets') }}:</span>
                                            <button v-for="preset in proxyPresets" :key="preset" type="button" 
                                                class="btn btn-xs py-0 px-2 rounded-pill" 
                                                :class="githubProxyUrl === preset ? 'btn-primary' : 'btn-outline-secondary'" 
                                                style="font-size: 0.7rem;" 
                                                @click="setPresetProxy(preset)">
                                                {{ preset }}
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div v-if="loadingReleases" class="text-center py-5">
                                <div class="spinner-border text-primary" role="status"></div>
                                <div class="small text-muted mt-2">{{ t('frp.fetch_releases') }}</div>
                            </div>
                            <div v-else-if="releases.length === 0" class="text-center text-muted py-5 small">
                                <i class="fa-solid fa-ghost fa-2x mb-2 opacity-25 d-block"></i>
                                {{ t('frp.no_releases') }}
                            </div>
                            <div v-else class="table-responsive rounded-3 overflow-hidden" style="border: 1px solid var(--c-border);">
                                <table class="table table-hover mb-0 align-middle">
                                    <tbody>
                                        <tr v-for="r in releases" :key="r.version">
                                            <td style="width: 40px;" class="text-center px-2 px-md-3">
                                                <div class="rounded-circle bg-warning-subtle text-warning d-inline-flex align-items-center justify-content-center" style="width: 30px; height: 30px;">
                                                    <i class="fa-solid fa-code-branch" style="font-size: 0.8rem;"></i>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="fw-bold small">v{{ r.version }}
                                                    <span v-if="r === releases[0]" class="badge bg-success-subtle text-success border border-success-subtle rounded-pill ms-1" style="font-size: 9px;">{{ t('frp.latest') }}</span>
                                                </div>
                                                <div class="text-muted" style="font-size: 0.7rem;">{{ new Date(r.publishedAt).toLocaleDateString() }}</div>
                                            </td>
                                            <td class="text-muted small d-none d-sm-table-cell">{{ (r.size / 1024 / 1024).toFixed(1) }} MB</td>
                                            <td class="text-end px-2 px-md-3">
                                                <button v-if="isInstalled(r.version)" class="btn btn-xs btn-success py-1 px-2 fw-bold" disabled style="font-size: 0.7rem;">
                                                    <i class="fa-solid fa-check me-1"></i><span class="d-none d-sm-inline">{{ t('frp.installed') }}</span>
                                                </button>
                                                <button v-else-if="activeInstall" class="btn btn-xs btn-secondary py-1 px-2 fw-bold" disabled style="font-size: 0.7rem;">
                                                    <span class="spinner-border spinner-border-sm" style="width: 10px; height: 10px;"></span>
                                                </button>
                                                <button v-else class="btn btn-xs btn-outline-primary py-1 px-2 fw-bold" @click="installVersion(r)" style="font-size: 0.7rem;">
                                                    <i class="fa-solid fa-download me-1"></i>{{ t('frp.install') }}
                                                </button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Teleport>

        <!-- 配置编辑与导入对话框 -->
        <Teleport to="body">
            <div class="modal fade" id="frpConfigModal" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content border-0 shadow-lg" style="border-radius: 16px;">
                        <div class="modal-header border-0 pb-0 pt-4 px-4">
                            <h5 class="modal-title fw-bold">
                                <i class="fa-solid fa-file-code me-2 text-info"></i>
                                {{ editingConfig.id ? t('frp.edit_config') : t('frp.new_config') }}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body px-4 pb-0">
                            <!-- 隐藏的文件输入组件，用于支持本地文件导入 -->
                            <input type="file" ref="fileInput" class="d-none" accept=".ini,.toml,.conf,.txt" @change="handleFileSelected">

                            <!-- 配置名称 -->
                            <div class="mb-3">
                                <label class="form-label small fw-bold text-muted">{{ t('frp.config_name') }}</label>
                                <input type="text" class="form-control" v-model="editingConfig.name" :placeholder="t('frp.config_name_placeholder')">
                            </div>

                            <!-- 格式选择与导入工具栏 -->
                            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 p-2 mb-3 rounded-3" style="background: var(--c-surface-elevated); border: 1px solid var(--c-border);">
                                <div class="d-flex align-items-center gap-2">
                                    <span class="small fw-bold text-muted"><i class="fa-solid fa-sliders me-1"></i>{{ t('frp.config_format') }}:</span>
                                    <div class="btn-group btn-group-sm">
                                        <button type="button" class="btn fw-bold" 
                                                :class="editingConfig.format === 'toml' ? 'btn-primary' : 'btn-outline-secondary'" 
                                                @click="switchFormat('toml')">
                                            TOML (.toml)
                                        </button>
                                        <button type="button" class="btn fw-bold" 
                                                :class="editingConfig.format === 'ini' ? 'btn-primary' : 'btn-outline-secondary'" 
                                                @click="switchFormat('ini')">
                                            INI (.ini)
                                        </button>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <button type="button" class="btn btn-sm btn-outline-primary fw-bold" @click="triggerFileInput" :title="t('frp.import_file_tip')">
                                        <i class="fa-solid fa-file-arrow-up me-1"></i>{{ t('frp.import_file') }}
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-primary fw-bold" @click="importFromClipboard" :title="t('frp.import_clipboard_tip')">
                                        <i class="fa-solid fa-clipboard me-1"></i>{{ t('frp.import_clipboard') }}
                                    </button>
                                </div>
                            </div>

                            <!-- 模式切换：图形模式 / 文本模式 -->
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="fw-bold small text-muted text-uppercase"><i class="fa-solid fa-pen-to-square me-1"></i>{{ t('frp.config') }}</span>
                                <div class="form-check form-switch m-0">
                                    <input class="form-check-input" type="checkbox" id="configModeSwitch2" v-model="configFormMode">
                                    <label class="form-check-label small fw-bold" for="configModeSwitch2">{{ configFormMode ? t('frp.gui_mode') : t('frp.text_mode') }}</label>
                                </div>
                            </div>

                            <!-- 表单模式 -->
                            <div v-if="configFormMode">
                                <div class="row g-3 mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label small fw-bold text-muted">{{ t('frp.server_addr') }}</label>
                                        <input type="text" class="form-control" v-model="configForm.serverAddr" placeholder="x.x.x.x">
                                        <div class="form-text small opacity-75" style="font-size: 0.7rem;">{{ t('frp.server_addr_desc') }}</div>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small fw-bold text-muted">{{ t('frp.server_port') }}</label>
                                        <input type="number" class="form-control" v-model.number="configForm.serverPort" placeholder="7000">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label small fw-bold text-muted">{{ t('frp.auth_token') }}</label>
                                        <input type="password" class="form-control" v-model="configForm.authToken" placeholder="token">
                                    </div>
                                </div>
                                
                                <!-- 隧道列表 -->
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="fw-bold small text-muted text-uppercase"><i class="fa-solid fa-route me-1"></i>{{ t('frp.tunnels') }}</span>
                                    <button class="btn btn-primary btn-sm fw-bold rounded-pill px-3" @click="addTunnel" style="font-size: 0.75rem;">
                                        <i class="fa-solid fa-plus me-1"></i>{{ t('frp.add_tunnel') }}
                                    </button>
                                </div>
                                <div v-for="(tunnel, idx) in configForm.tunnels" :key="idx" class="card bg-body-tertiary border-0 mb-2" style="border-radius: 12px;">
                                    <div class="card-body p-3">
                                        <div class="row g-2 align-items-end">
                                            <div class="col-md-2">
                                                <label class="form-label small fw-bold text-muted mb-1">{{ t('frp.tunnel_name') }}</label>
                                                <input type="text" class="form-control form-control-sm" v-model="tunnel.name" :placeholder="'tunnel-' + idx">
                                            </div>
                                            <div class="col-md-2">
                                                <label class="form-label small fw-bold text-muted mb-1">{{ t('frp.tunnel_type') }}</label>
                                                <CustomSelect v-model="tunnel.type" :options="[{value: 'tcp', label: 'TCP'}, {value: 'udp', label: 'UDP'}]" size="sm" />
                                            </div>
                                            <div class="col-md-2">
                                                <label class="form-label small fw-bold text-muted mb-1">{{ t('frp.local_ip') }}</label>
                                                <input type="text" class="form-control form-control-sm" v-model="tunnel.localIP" placeholder="127.0.0.1">
                                            </div>
                                            <div class="col-md-2">
                                                <label class="form-label small fw-bold text-muted mb-1">{{ t('frp.local_port') }}</label>
                                                <input type="number" class="form-control form-control-sm" v-model.number="tunnel.localPort" placeholder="25565">
                                            </div>
                                            <div class="col-md-2">
                                                <label class="form-label small fw-bold text-muted mb-1">{{ t('frp.remote_port') }}</label>
                                                <input type="number" class="form-control form-control-sm" v-model.number="tunnel.remotePort" placeholder="25565">
                                            </div>
                                            <div class="col-md-2 text-end">
                                                <button class="btn btn-sm btn-outline-danger border-0" @click="removeTunnel(idx)" :title="t('common.delete')">
                                                    <i class="fa-solid fa-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div v-if="configForm.tunnels.length === 0" class="text-center text-muted py-3 small">
                                    <i class="fa-solid fa-route opacity-25 d-block mb-1" style="font-size: 1.5rem;"></i>
                                    {{ t('frp.no_tunnels') }}
                                </div>
                            </div>

                            <!-- 文本模式 -->
                            <div v-else>
                                <textarea class="form-control font-monospace" v-model="editingConfig.configRaw" rows="14"
                                          style="font-size: 0.8rem; resize: vertical; border-radius: 12px;"
                                          :placeholder="currentConfigPlaceholder"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer border-0 p-4 pt-3 d-flex justify-content-between">
                            <button v-if="editingConfig.id" class="btn btn-sm btn-outline-secondary rounded-pill px-3" @click="viewLogs(editingConfig)">
                                <i class="fa-solid fa-terminal me-1"></i>{{ t('frp.logs') }}
                            </button>
                            <div v-else></div>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">{{ t('common.cancel') }}</button>
                                <button type="button" class="btn btn-primary px-4 fw-bold" @click="saveConfig" :disabled="savingConfig">
                                    <span v-if="savingConfig" class="spinner-border spinner-border-sm me-1"></span>
                                    {{ t('common.save') }}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Teleport>

        <!-- 剪贴板手动粘贴兜底模态框 -->
        <Teleport to="body">
            <div class="modal fade" id="frpPasteModal" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content border-0 shadow-lg" style="border-radius: 16px;">
                        <div class="modal-header border-0 pb-0 pt-4 px-4">
                            <h5 class="modal-title fw-bold">
                                <i class="fa-solid fa-clipboard me-2 text-primary"></i>
                                {{ t('frp.clipboard_modal_title') }}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body px-4 py-3">
                            <p class="text-muted small mb-2">{{ t('frp.clipboard_modal_desc') }}</p>
                            <textarea class="form-control font-monospace" v-model="pasteModalText" rows="10"
                                      style="font-size: 0.8rem; border-radius: 12px;"
                                      placeholder="[common]&#10;server_addr = ...&#10;&#10;[tunnel]&#10;type = tcp&#10;..."></textarea>
                        </div>
                        <div class="modal-footer border-0 p-4 pt-0 d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">{{ t('common.cancel') }}</button>
                            <button type="button" class="btn btn-primary px-4 fw-bold" @click="confirmPasteImport" :disabled="!pasteModalText.trim()">
                                {{ t('frp.clipboard_modal_confirm') }}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </Teleport>
    </div>
    `,
    setup() {
        const { proxy } = getCurrentInstance();

        // 封装稳固的多语言解析器 t()
        const t = (key, params = {}) => {
            // 1. 优先调用宿主 Vue 全局 $t
            if (proxy && typeof proxy.$t === 'function') {
                const val = proxy.$t(key, params);
                if (val && val !== key) return val;
            }

            // 2. 提取相对子键名
            const subKey = key.startsWith('frp.') ? key.substring(4) : (key.startsWith('common.') ? key.substring(7) : key);
            const currentLang = (store && store.lang === 'en') ? 'en' : 'zh';

            // 3. 尝试从宿主已合并的插件翻译中获取
            const pluginTrans = messages?.[currentLang]?.plugins?.['mc-panel-plugin-frp']?.[subKey];
            if (pluginTrans) {
                return typeof pluginTrans === 'string'
                    ? pluginTrans.replace(/{(\w+)}/g, (_, k) => params[k] !== undefined ? params[k] : `{${k}}`)
                    : pluginTrans;
            }

            // 4. 查阅组件内嵌本地字典
            const localTrans = I18N_LOCAL[currentLang]?.[subKey] || I18N_LOCAL['zh']?.[subKey];
            if (localTrans) {
                return typeof localTrans === 'string'
                    ? localTrans.replace(/{(\w+)}/g, (_, k) => params[k] !== undefined ? params[k] : `{${k}}`)
                    : localTrans;
            }

            return key;
        };

        const status = reactive({ installed: false, version: null, installedAt: null });
        const configs = ref([]);
        const releases = ref([]);
        const loadingReleases = ref(false);
        const activeInstall = ref(null);
        const savingConfig = ref(false);
        const configFormMode = ref(true);
        const logs = ref([]);
        const logContainer = ref(null);
        const selectedLogConfigId = ref(null);
        const fileInput = ref(null);
        const pasteModalText = ref('');

        let releasesModal = null;
        let configModal = null;
        let pasteModal = null;

        // GitHub 代理加速设置
        const useGithubProxy = ref(localStorage.getItem('frp_use_proxy') !== 'false');
        const githubProxyUrl = ref(localStorage.getItem('frp_proxy_url') || 'https://ghfast.top/');
        const proxyPresets = ['https://ghfast.top/', 'https://mirror.ghproxy.com/', 'https://gh-proxy.com/'];
        const saveProxySettings = () => {
            localStorage.setItem('frp_use_proxy', useGithubProxy.value ? 'true' : 'false');
            localStorage.setItem('frp_proxy_url', githubProxyUrl.value);
        };
        const setPresetProxy = (preset) => {
            githubProxyUrl.value = preset;
            saveProxySettings();
        };

        const editingConfig = reactive({
            id: null,
            name: '',
            format: 'toml',
            configRaw: ''
        });

        const configForm = reactive({
            serverAddr: '',
            serverPort: 7000,
            authToken: '',
            tunnels: []
        });

        const tomlPlaceholder = `serverAddr = "x.x.x.x"
serverPort = 7000

auth.method = "token"
auth.token = "your_token"

[[proxies]]
name = "minecraft"
type = "tcp"
localIP = "127.0.0.1"
localPort = 25565
remotePort = 25565`;

        const iniPlaceholder = `[common]
server_addr = x.x.x.x
server_port = 7000
token = your_token

[minecraft]
type = tcp
local_ip = 127.0.0.1
local_port = 25565
remote_port = 25565`;

        const currentConfigPlaceholder = computed(() => {
            return editingConfig.format === 'ini' ? iniPlaceholder : tomlPlaceholder;
        });

        const formattedSpeed = computed(() => {
            const speed = activeInstall.value?.speed;
            if (!speed || speed <= 0) return '';
            if (speed >= 1024 * 1024) return (speed / 1024 / 1024).toFixed(2) + ' MB/s';
            return (speed / 1024).toFixed(0) + ' KB/s';
        });

        const selectedLogConfigName = computed(() => {
            const cfg = configs.value.find(c => c.id === selectedLogConfigId.value);
            return cfg ? cfg.name : '';
        });

        const runningCount = computed(() => {
            return configs.value.filter(c => c.running).length;
        });

        // --- 智能格式嗅探 ---
        const detectFormat = (raw) => {
            if (!raw || typeof raw !== 'string') return 'toml';
            const text = raw.trim();
            if (text.includes('[common]')) return 'ini';
            if (text.includes('[[proxies]]')) return 'toml';

            const lines = text.split('\n');
            for (const l of lines) {
                const trimmed = l.trim();
                if (trimmed.startsWith('serverAddr') || trimmed.startsWith('serverPort') || trimmed.startsWith('auth.token')) {
                    return 'toml';
                }
                if (trimmed.startsWith('server_addr') || trimmed.startsWith('server_port')) {
                    return 'ini';
                }
                if (trimmed.startsWith('[') && !trimmed.startsWith('[[') && trimmed.endsWith(']')) {
                    return 'ini';
                }
            }
            return 'toml';
        };

        // --- TOML 互转逻辑 ---
        const formToToml = () => {
            let toml = `serverAddr = "${configForm.serverAddr || '127.0.0.1'}"\nserverPort = ${configForm.serverPort || 7000}\n`;
            if (configForm.authToken) {
                toml += `\nauth.method = "token"\nauth.token = "${configForm.authToken}"\n`;
            }
            for (const t of configForm.tunnels) {
                toml += `\n[[proxies]]\nname = "${t.name || 'tunnel'}"\ntype = "${t.type || 'tcp'}"\nlocalIP = "${t.localIP || '127.0.0.1'}"\nlocalPort = ${t.localPort || 25565}\nremotePort = ${t.remotePort || 25565}\n`;
            }
            return toml;
        };

        const tomlToForm = (raw) => {
            configForm.serverAddr = '';
            configForm.serverPort = 7000;
            configForm.authToken = '';
            configForm.tunnels = [];
            if (!raw) return;

            try {
                const lines = raw.split('\n');
                let currentTunnel = null;
                for (const line of lines) {
                    const trimmed = line.trim();
                    if (trimmed.startsWith('#') || trimmed === '') continue;

                    if (trimmed === '[[proxies]]') {
                        if (currentTunnel) configForm.tunnels.push(currentTunnel);
                        currentTunnel = { name: '', type: 'tcp', localIP: '127.0.0.1', localPort: 25565, remotePort: 25565 };
                        continue;
                    }

                    const match = trimmed.match(/^([a-zA-Z_.]+)\s*=\s*(.+)$/);
                    if (!match) continue;
                    const key = match[1].trim();
                    let val = match[2].trim().replace(/^"(.*)"$/, '$1');

                    if (key === 'serverAddr') configForm.serverAddr = val;
                    else if (key === 'serverPort') configForm.serverPort = parseInt(val) || 7000;
                    else if (key === 'auth.token') configForm.authToken = val;
                    else if (currentTunnel) {
                        if (key === 'name') currentTunnel.name = val;
                        else if (key === 'type') currentTunnel.type = val.toLowerCase();
                        else if (key === 'localIP') currentTunnel.localIP = val;
                        else if (key === 'localPort') currentTunnel.localPort = parseInt(val) || 25565;
                        else if (key === 'remotePort') currentTunnel.remotePort = parseInt(val) || 25565;
                    }
                }
                if (currentTunnel) configForm.tunnels.push(currentTunnel);
            } catch (e) {
                console.warn('Failed to parse TOML to form:', e);
            }
        };

        // --- INI 互转逻辑 ---
        const formToIni = () => {
            let ini = `[common]\nserver_addr = ${configForm.serverAddr || '127.0.0.1'}\nserver_port = ${configForm.serverPort || 7000}\n`;
            if (configForm.authToken) {
                ini += `token = ${configForm.authToken}\n`;
            }
            for (const t of configForm.tunnels) {
                ini += `\n[${t.name || 'tunnel'}]\ntype = ${t.type || 'tcp'}\nlocal_ip = ${t.localIP || '127.0.0.1'}\nlocal_port = ${t.localPort || 25565}\nremote_port = ${t.remotePort || 25565}\n`;
            }
            return ini;
        };

        const iniToForm = (raw) => {
            configForm.serverAddr = '';
            configForm.serverPort = 7000;
            configForm.authToken = '';
            configForm.tunnels = [];
            if (!raw) return;

            try {
                const lines = raw.split('\n');
                let currentSection = null;
                let currentTunnel = null;

                for (const line of lines) {
                    const trimmed = line.trim();
                    if (!trimmed || trimmed.startsWith('#') || trimmed.startsWith(';')) continue;

                    const sectionMatch = trimmed.match(/^\[(.*)\]$/);
                    if (sectionMatch && !trimmed.startsWith('[[')) {
                        if (currentTunnel) {
                            configForm.tunnels.push(currentTunnel);
                            currentTunnel = null;
                        }
                        currentSection = sectionMatch[1].trim();
                        if (currentSection.toLowerCase() !== 'common') {
                            currentTunnel = {
                                name: currentSection,
                                type: 'tcp',
                                localIP: '127.0.0.1',
                                localPort: 25565,
                                remotePort: 25565
                            };
                        }
                        continue;
                    }

                    const kvMatch = trimmed.match(/^([a-zA-Z0-9_.-]+)\s*=\s*(.*)$/);
                    if (!kvMatch) continue;
                    const key = kvMatch[1].trim().toLowerCase();
                    let val = kvMatch[2].trim().replace(/^["'](.*)["']$/, '$1');

                    if (currentSection && currentSection.toLowerCase() === 'common') {
                        if (key === 'server_addr' || key === 'serveraddr') configForm.serverAddr = val;
                        else if (key === 'server_port' || key === 'serverport') configForm.serverPort = parseInt(val) || 7000;
                        else if (key === 'token' || key === 'auth.token') configForm.authToken = val;
                    } else if (currentTunnel) {
                        if (key === 'type') currentTunnel.type = val.toLowerCase();
                        else if (key === 'local_ip' || key === 'localip') currentTunnel.localIP = val;
                        else if (key === 'local_port' || key === 'localport') currentTunnel.localPort = parseInt(val) || 25565;
                        else if (key === 'remote_port' || key === 'remoteport') currentTunnel.remotePort = parseInt(val) || 25565;
                    }
                }
                if (currentTunnel) {
                    configForm.tunnels.push(currentTunnel);
                }
            } catch (e) {
                console.warn('Failed to parse INI to form:', e);
            }
        };

        const rawToForm = (raw, format) => {
            if (format === 'ini') iniToForm(raw);
            else tomlToForm(raw);
        };

        const formToRaw = (format) => {
            return format === 'ini' ? formToIni() : formToToml();
        };

        // 格式切换（TOML <-> INI）
        const switchFormat = (newFormat) => {
            if (editingConfig.format === newFormat) return;
            if (configFormMode.value) {
                editingConfig.format = newFormat;
            } else {
                if (editingConfig.configRaw && editingConfig.configRaw.trim()) {
                    if (newFormat === 'ini') {
                        tomlToForm(editingConfig.configRaw);
                        editingConfig.configRaw = formToIni();
                    } else {
                        iniToForm(editingConfig.configRaw);
                        editingConfig.configRaw = formToToml();
                    }
                }
                editingConfig.format = newFormat;
            }
        };

        const addTunnel = () => {
            configForm.tunnels.push({
                name: 'minecraft-' + configForm.tunnels.length,
                type: 'tcp',
                localIP: '127.0.0.1',
                localPort: 25565,
                remotePort: 25565
            });
        };
        const removeTunnel = (idx) => { configForm.tunnels.splice(idx, 1); };

        // 模式切换同步
        watch(configFormMode, (isForm) => {
            if (isForm) {
                rawToForm(editingConfig.configRaw, editingConfig.format);
            } else {
                editingConfig.configRaw = formToRaw(editingConfig.format);
            }
        });

        // --- 文件导入与剪切板导入 ---
        const triggerFileInput = () => {
            if (fileInput.value) fileInput.value.click();
        };

        const handleFileSelected = (e) => {
            const file = e.target.files?.[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = (evt) => {
                const content = evt.target?.result;
                if (typeof content !== 'string') return;
                applyImportedContent(content, file.name.replace(/\.[^/.]+$/, ''));
            };
            reader.readAsText(file);
            e.target.value = '';
        };

        const applyImportedContent = (content, suggestedName = '') => {
            const fmt = detectFormat(content);
            editingConfig.format = fmt;
            editingConfig.configRaw = content;
            if (suggestedName && (!editingConfig.name || editingConfig.name === t('frp.new_config'))) {
                editingConfig.name = suggestedName;
            } else if (!editingConfig.name) {
                editingConfig.name = '导入配置-' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            }
            rawToForm(content, fmt);
            showToast(t('frp.import_success', { format: fmt.toUpperCase() }), 'success');
        };

        const importFromClipboard = async () => {
            try {
                if (navigator.clipboard && navigator.clipboard.readText) {
                    const text = await navigator.clipboard.readText();
                    if (text && text.trim()) {
                        applyImportedContent(text);
                        return;
                    } else if (text !== undefined && text.trim() === '') {
                        showToast(t('frp.clipboard_empty'), 'warning');
                        return;
                    }
                }
            } catch (err) {
                console.info('Clipboard access restricted, opening modal:', err);
            }
            openPasteModal();
        };

        const openPasteModal = () => {
            pasteModalText.value = '';
            if (!pasteModal) {
                pasteModal = new bootstrap.Modal(document.getElementById('frpPasteModal'));
            }
            pasteModal.show();
        };

        const confirmPasteImport = () => {
            if (!pasteModalText.value.trim()) return;
            applyImportedContent(pasteModalText.value.trim());
            if (pasteModal) pasteModal.hide();
        };

        const openDirectImportModal = () => {
            createNewConfig();
            nextTick(() => {
                triggerFileInput();
            });
        };

        // --- API 请求 ---
        const loadStatus = async () => {
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-frp/status');
                status.installed = res.data.installed;
                status.version = res.data.version;
                status.installedAt = res.data.installedAt;
                configs.value = res.data.configs || [];
            } catch (e) { }
        };

        const fetchReleases = async () => {
            loadingReleases.value = true;
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-frp/releases');
                releases.value = res.data.releases || [];
            } catch (e) {
                showToast(t('frp.no_releases'), 'danger');
            } finally {
                loadingReleases.value = false;
            }
        };

        const isInstalled = (version) => {
            return status.installed && status.version && (status.version === version || status.version.includes(version));
        };

        const installVersion = async (r) => {
            if (activeInstall.value) return;
            try {
                await api.post('/api/plugins/mc-panel-plugin-frp/install', {
                    version: r.version,
                    downloadUrl: r.downloadUrl,
                    useProxy: useGithubProxy.value,
                    proxyUrl: githubProxyUrl.value
                });
            } catch (e) {
                showToast(e.response?.data?.error || t('common.error'), 'danger');
            }
        };

        const cancelInstall = async () => {
            try { await api.post('/api/plugins/mc-panel-plugin-frp/install/cancel'); } catch (e) { }
        };

        const askUninstall = () => {
            openModal({
                title: t('frp.uninstall'),
                message: t('frp.uninstall_confirm'),
                callback: async () => {
                    try {
                        await api.post('/api/plugins/mc-panel-plugin-frp/uninstall');
                        showToast(t('common.success'));
                        loadStatus();
                    } catch (e) {
                        showToast(e.response?.data?.error || t('common.error'), 'danger');
                    }
                }
            });
        };

        const openReleasesModal = () => {
            if (!releasesModal) {
                releasesModal = new bootstrap.Modal(document.getElementById('frpReleasesModal'));
            }
            releasesModal.show();
            if (releases.value.length === 0) fetchReleases();
        };

        // --- 配置管理 ---
        const createNewConfig = () => {
            editingConfig.id = null;
            editingConfig.name = '';
            editingConfig.format = 'toml';
            editingConfig.configRaw = '';
            configFormMode.value = true;
            rawToForm('', 'toml');
            openConfigModal();
        };

        const editConfig = async (cfg) => {
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-frp/configs/' + cfg.id);
                editingConfig.id = res.data.id;
                editingConfig.name = res.data.name;
                const rawConfig = res.data.config || '';
                const fmt = res.data.format || detectFormat(rawConfig);
                editingConfig.format = fmt;
                editingConfig.configRaw = rawConfig;
                configFormMode.value = true;
                rawToForm(editingConfig.configRaw, fmt);
                openConfigModal();
            } catch (e) {
                showToast(e.response?.data?.error || t('common.error'), 'danger');
            }
        };

        const openConfigModal = () => {
            if (!configModal) {
                configModal = new bootstrap.Modal(document.getElementById('frpConfigModal'));
            }
            configModal.show();
        };

        const saveConfig = async () => {
            if (!editingConfig.name) {
                showToast(t('frp.config_name_required'), 'warning');
                return;
            }
            savingConfig.value = true;
            try {
                const configContent = configFormMode.value ? formToRaw(editingConfig.format) : editingConfig.configRaw;
                await api.post('/api/plugins/mc-panel-plugin-frp/configs', {
                    id: editingConfig.id || undefined,
                    name: editingConfig.name,
                    format: editingConfig.format,
                    config: configContent
                });
                showToast(t('frp.config_saved'), 'success');
                configModal.hide();
                loadStatus();
            } catch (e) {
                showToast(e.response?.data?.error || t('common.error'), 'danger');
            } finally {
                savingConfig.value = false;
            }
        };

        const deleteConfig = (cfg) => {
            openModal({
                title: t('common.delete'),
                message: t('frp.delete_config_confirm', { name: cfg.name }),
                callback: async () => {
                    try {
                        await api.post('/api/plugins/mc-panel-plugin-frp/configs/delete', { id: cfg.id });
                        showToast(t('common.success'));
                        loadStatus();
                        if (selectedLogConfigId.value === cfg.id) selectedLogConfigId.value = null;
                    } catch (e) {
                        showToast(e.response?.data?.error || t('common.error'), 'danger');
                    }
                }
            });
        };

        // --- 进程管理 ---
        const startConfig = async (cfg) => {
            try {
                await api.post('/api/plugins/mc-panel-plugin-frp/start', { configId: cfg.id });
                showToast(t('frp.started_success'), 'success');
                cfg.running = true;
                selectedLogConfigId.value = cfg.id;
                loadLogs(cfg.id);
            } catch (e) {
                showToast(e.response?.data?.error || t('frp.start_fail'), 'danger');
            }
        };

        const stopConfig = async (cfg) => {
            try {
                await api.post('/api/plugins/mc-panel-plugin-frp/stop', { configId: cfg.id });
                showToast(t('frp.stopped_success'), 'success');
            } catch (e) {
                showToast(e.response?.data?.error || t('common.error'), 'danger');
            }
        };

        const restartConfig = async (cfg) => {
            try {
                await api.post('/api/plugins/mc-panel-plugin-frp/restart', { configId: cfg.id });
                showToast(t('frp.started_success'), 'success');
                selectedLogConfigId.value = cfg.id;
                loadLogs(cfg.id);
            } catch (e) {
                showToast(e.response?.data?.error || t('common.error'), 'danger');
            }
        };

        const viewLogs = (cfg) => {
            selectedLogConfigId.value = cfg.id;
            loadLogs(cfg.id);
            configModal.hide();
        };

        const viewLogsFromCard = (cfg) => {
            selectedLogConfigId.value = cfg.id;
            loadLogs(cfg.id);
        };

        const loadLogs = async (configId) => {
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-frp/logs/' + configId);
                logs.value = res.data.logs || [];
                scrollLogsToBottom();
            } catch (e) { }
        };

        const scrollLogsToBottom = () => {
            nextTick(() => {
                if (logContainer.value) {
                    logContainer.value.scrollTop = logContainer.value.scrollHeight;
                }
            });
        };

        // Socket 监听
        let socket = null;
        onMounted(async () => {
            loadStatus();

            try {
                const { io: ioClient } = await import('/socket.io/socket.io.esm.min.js');
                socket = ioClient();

                socket.on('frp_install_progress', (data) => {
                    activeInstall.value = data;
                    if (data.step === 'done') {
                        showToast(data.message, 'success');
                        loadStatus();
                        setTimeout(() => { activeInstall.value = null; }, 2000);
                    } else if (data.step === 'error') {
                        if (data.message !== '已取消') showToast(data.message, 'danger');
                        setTimeout(() => { activeInstall.value = null; }, 3000);
                    }
                });

                socket.on('frp_log', (data) => {
                    if (data.configId === selectedLogConfigId.value) {
                        logs.value.push(data.line);
                        if (logs.value.length > 500) logs.value.shift();
                        scrollLogsToBottom();
                    }
                });

                socket.on('frp_status', (data) => {
                    const cfg = configs.value.find(c => c.id === data.configId);
                    if (cfg) cfg.running = data.running;
                });
            } catch (e) {
                console.warn('Socket not available for FRP', e);
            }
        });

        onUnmounted(() => {
            if (socket) {
                socket.off('frp_install_progress');
                socket.off('frp_log');
                socket.off('frp_status');
            }
        });

        return {
            t, store, status, configs, releases, loadingReleases, activeInstall, formattedSpeed,
            savingConfig, configFormMode, configForm, currentConfigPlaceholder,
            editingConfig, logs, logContainer, selectedLogConfigId, selectedLogConfigName,
            runningCount, fileInput, pasteModalText,
            fetchReleases, installVersion, cancelInstall, isInstalled, askUninstall,
            openReleasesModal, createNewConfig, editConfig, saveConfig, deleteConfig,
            addTunnel, removeTunnel, switchFormat,
            triggerFileInput, handleFileSelected, importFromClipboard, openPasteModal, confirmPasteImport, openDirectImportModal,
            startConfig, stopConfig, restartConfig, viewLogs, viewLogsFromCard,
            useGithubProxy, githubProxyUrl, proxyPresets, saveProxySettings, setPresetProxy
        };
    }
};
