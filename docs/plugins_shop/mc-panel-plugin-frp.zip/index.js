const fs = require('fs-extra');
const path = require('path');
const os = require('os');
const https = require('https');
const http = require('http');
const { spawn, execSync } = require('child_process');
const { pipeline } = require('stream/promises');
const express = require('express');
const axios = require('axios');
const AdmZip = require('adm-zip');

const MODRINTH_UA = 'MCWebPanel/1.0';

function nativeHttpGet(urlStr, options = {}) {
    return new Promise((resolve, reject) => {
        const parsed = new URL(urlStr);
        const mod = parsed.protocol === 'https:' ? https : http;
        const reqOptions = {
            hostname: parsed.hostname,
            port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
            path: parsed.pathname + parsed.search,
            method: options.method || 'GET',
            headers: options.headers || {},
            timeout: options.connectTimeout || 15000,
        };
        const maxRedirects = options.maxRedirects !== undefined ? options.maxRedirects : 10;
        const req = mod.request(reqOptions, (res) => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                const redirectUrl = new URL(res.headers.location, urlStr).href;
                if (maxRedirects > 0) {
                    nativeHttpGet(redirectUrl, { ...options, maxRedirects: maxRedirects - 1 })
                        .then(resolve).catch(reject);
                } else {
                    reject(new Error('Too many redirects'));
                }
                return;
            }
            if (res.statusCode >= 400) {
                res.resume();
                reject(new Error(`HTTP ${res.statusCode} from ${urlStr}`));
                return;
            }
            resolve(res);
        });
        req.on('error', reject);
        req.on('timeout', () => { req.destroy(); reject(new Error(`连接超时: ${urlStr}`)); });
        if (options.signal) {
            options.signal.addEventListener('abort', () => { req.destroy(); reject(new Error('Aborted')); });
        }
        req.end();
    });
}

module.exports = async (api) => {
    const logger = api.logger;
    const DATA_DIR = api.getGlobalDataDir();
    const FRP_DIR = path.join(DATA_DIR, 'frp');
    const FRP_META_FILE = path.join(FRP_DIR, 'frp.json');
    fs.ensureDirSync(FRP_DIR);

    const activeDownloads = new Map();

    const readFrpMeta = () => {
        try {
            const data = fs.readJsonSync(FRP_META_FILE);
            if (!data.configs) data.configs = [];
            return data;
        } catch (e) { return { installed: false, configs: [] }; }
    };

    const writeFrpMeta = (data) => {
        fs.writeJsonSync(FRP_META_FILE, data, { spaces: 2 });
    };

    const getFrpBinaryPath = () => {
        return path.join(FRP_DIR, process.platform === 'win32' ? 'frpc.exe' : 'frpc');
    };

    const getConfigFilePath = (configId) => {
        return path.join(FRP_DIR, `frpc-${configId}.toml`);
    };

    const frpInstances = new Map();
    const MAX_FRP_LOGS = 500;

    const appendFrpLog = (configId, line) => {
        const entry = `[${new Date().toLocaleTimeString()}] ${line}`;
        const inst = frpInstances.get(configId);
        if (inst) {
            inst.logs.push(entry);
            if (inst.logs.length > MAX_FRP_LOGS) inst.logs.shift();
        }
        api.io.emit('frp_log', { configId, line: entry });
    };

    const startFrpProcess = (configId, configFilePath) => {
        const frpcPath = getFrpBinaryPath();
        const proc = spawn(frpcPath, ['-c', configFilePath], {
            cwd: FRP_DIR,
            env: { ...process.env }
        });
        const inst = { process: proc, logs: [] };
        frpInstances.set(configId, inst);

        appendFrpLog(configId, `frpc 进程已启动 (PID: ${proc.pid})`);
        api.io.emit('frp_status', { configId, running: true });

        proc.stdout.on('data', (data) => {
            data.toString().split('\n').filter(l => l.trim()).forEach(l => appendFrpLog(configId, l));
        });
        proc.stderr.on('data', (data) => {
            data.toString().split('\n').filter(l => l.trim()).forEach(l => appendFrpLog(configId, '[stderr] ' + l));
        });
        proc.on('error', (err) => {
            appendFrpLog(configId, 'frpc 启动失败: ' + err.message);
            frpInstances.delete(configId);
            api.io.emit('frp_status', { configId, running: false });
        });
        proc.on('exit', (code, signal) => {
            appendFrpLog(configId, `frpc 进程退出 (code: ${code}, signal: ${signal})`);
            frpInstances.delete(configId);
            api.io.emit('frp_status', { configId, running: false });
        });
        return proc;
    };

    const stopFrpProcess = async (configId) => {
        const inst = frpInstances.get(configId);
        if (!inst) return;
        try { inst.process.kill('SIGTERM'); } catch (e) { }
        appendFrpLog(configId, '正在停止 frpc...');
        await new Promise(resolve => {
            const check = setInterval(() => {
                if (!frpInstances.has(configId)) { clearInterval(check); resolve(); }
            }, 200);
            setTimeout(() => { clearInterval(check); resolve(); }, 5000);
        });
    };

    const applyGithubProxy = (url) => {
        if (!url || typeof url !== 'string') return url;
        const config = api.getConfig();
        if (config && config.githubProxy && url.includes('github.com')) {
            let proxy = config.githubProxy;
            if (!proxy.endsWith('/')) proxy += '/';
            if (url.startsWith(proxy)) return url;
            return proxy + url;
        }
        return url;
    };

    const router = express.Router();

    router.get('/status', (req, res) => {
        const meta = readFrpMeta();
        const frpcPath = getFrpBinaryPath();
        const installed = meta.installed && fs.existsSync(frpcPath);
        const configs = (meta.configs || []).map(c => ({
            ...c,
            running: frpInstances.has(c.id),
            config: undefined
        }));
        res.json({
            installed,
            version: installed ? (meta.version || 'Unknown') : null,
            installedAt: meta.installedAt || null,
            configs
        });
    });

    router.get('/releases', async (req, res) => {
        try {
            const arch = os.arch() === 'x64' ? 'amd64' : os.arch() === 'arm64' ? 'arm64' : os.arch();
            const osType = process.platform === 'linux' ? 'linux' : process.platform === 'darwin' ? 'darwin' : 'windows';

            const apiUrl = 'https://api.github.com/repos/fatedier/frp/releases';
            const axiosOpts = {
                timeout: 15000,
                headers: { 'User-Agent': MODRINTH_UA, 'Accept': 'application/vnd.github.v3+json' },
                params: { per_page: 15 }
            };

            let resp;
            try {
                resp = await axios.get(apiUrl, axiosOpts);
            } catch (directErr) {
                logger.warn(`[FRP] GitHub API direct failed: ${directErr.message}, trying proxy...`);
                const config = api.getConfig();
                const proxyUrls = [];
                if (config?.githubProxy) {
                    let proxy = config.githubProxy;
                    if (!proxy.endsWith('/')) proxy += '/';
                    proxyUrls.push(proxy + apiUrl);
                }
                const KNOWN_MIRRORS = ['https://ghfast.top/', 'https://mirror.ghproxy.com/'];
                for (const m of KNOWN_MIRRORS) {
                    proxyUrls.push(m + apiUrl);
                }
                let lastErr = directErr;
                for (const proxyUrl of proxyUrls) {
                    try {
                        resp = await axios.get(proxyUrl, { ...axiosOpts, timeout: 30000 });
                        lastErr = null;
                        break;
                    } catch (proxyErr) {
                        lastErr = proxyErr;
                    }
                }
                if (!resp) throw lastErr;
            }

            const releases = resp.data
                .filter(r => !r.prerelease && !r.draft)
                .map(r => {
                    const suffix = osType === 'windows' ? `${osType}_${arch}.zip` : `${osType}_${arch}.tar.gz`;
                    const asset = r.assets.find(a => a.name.includes(suffix));
                    return asset ? {
                        version: r.tag_name.replace(/^v/, ''),
                        tagName: r.tag_name,
                        releaseName: r.name,
                        publishedAt: r.published_at,
                        downloadUrl: asset.browser_download_url,
                        size: asset.size,
                        fileName: asset.name
                    } : null;
                })
                .filter(r => r !== null);

            const meta = readFrpMeta();
            res.json({ releases, installedVersion: meta.installed ? meta.version : null });
        } catch (e) {
            logger.error('Failed to fetch releases:', e.message);
            res.status(500).json({ error: '获取版本列表失败: ' + e.message });
        }
    });

    router.post('/install', async (req, res) => {
        const { version, downloadUrl, useProxy, proxyUrl } = req.body;
        if (!downloadUrl || !version) return res.status(400).json({ error: '参数不完整' });

        for (const [cid] of frpInstances) {
            await stopFrpProcess(cid);
        }

        res.json({ success: true, message: '开始下载...' });

        const controller = new AbortController();
        activeDownloads.set('frp-install', controller);

        const tryDownloadWithAxios = async (url, label) => {
            logger.info(`[FRP Install] [axios] Downloading from ${label}: ${url}`);
            api.io.emit('frp_install_progress', { step: 'downloading', percent: 0, message: `正在从${label}下载...` });

            const response = await axios({
                method: 'get',
                url,
                responseType: 'stream',
                timeout: 600000,
                signal: controller.signal,
                headers: { 'User-Agent': MODRINTH_UA },
                validateStatus: (status) => status >= 200 && status < 400,
                maxRedirects: 10,
                httpAgent: new http.Agent({ timeout: 15000 }),
                httpsAgent: new https.Agent({ timeout: 15000 })
            });

            logger.info(`[FRP Install] [axios] Connected to ${label}, status: ${response.status}, size: ${response.headers['content-length'] || 'unknown'}`);
            return { stream: response.data, contentLength: parseInt(response.headers['content-length'] || '0', 10) };
        };

        const tryDownloadNative = async (url, label) => {
            logger.info(`[FRP Install] [native] Downloading from ${label}: ${url}`);
            api.io.emit('frp_install_progress', { step: 'downloading', percent: 0, message: `正在从${label}下载(原生模式)...` });

            const resp = await nativeHttpGet(url, {
                headers: { 'User-Agent': MODRINTH_UA },
                maxRedirects: 10,
                signal: controller.signal
            });

            logger.info(`[FRP Install] [native] Connected to ${label}, status: ${resp.statusCode}, size: ${resp.headers['content-length'] || 'unknown'}`);
            return { stream: resp, contentLength: parseInt(resp.headers['content-length'] || '0', 10) };
        };

        const tryDownload = async (url, label) => {
            try {
                return await tryDownloadWithAxios(url, label);
            } catch (axiosErr) {
                if (controller.signal.aborted) throw axiosErr;
                logger.warn(`[FRP Install] axios failed for ${label}: ${axiosErr.message}`);
                try {
                    return await tryDownloadNative(url, label);
                } catch (nativeErr) {
                    if (controller.signal.aborted) throw nativeErr;
                    throw new Error(`${label}下载失败(axios: ${axiosErr.message}, native: ${nativeErr.message})`);
                }
            }
        };

        try {
            const isZip = downloadUrl.endsWith('.zip');
            const tmpFile = path.join(FRP_DIR, isZip ? 'frp-tmp.zip' : 'frp-tmp.tar.gz');

            let urlsToTry = [];
            const shouldProxy = useProxy !== false;
            const customProxy = (proxyUrl || '').trim();

            if (shouldProxy) {
                if (customProxy) {
                    let formattedProxy = customProxy;
                    if (!formattedProxy.endsWith('/') && !formattedProxy.includes('%s')) {
                        formattedProxy += '/';
                    }
                    const targetUrl = formattedProxy.includes('%s')
                        ? formattedProxy.replace('%s', downloadUrl)
                        : (formattedProxy + downloadUrl);

                    let hostLabel = '自定义代理';
                    try {
                        const parsed = new URL(formattedProxy.replace('%s', ''));
                        hostLabel = parsed.hostname || '自定义代理';
                    } catch (_) {}
                    urlsToTry.push({ url: targetUrl, label: `用户代理(${hostLabel})` });
                }

                const proxiedUrl = applyGithubProxy(downloadUrl);
                if (proxiedUrl !== downloadUrl && !urlsToTry.some(u => u.url === proxiedUrl)) {
                    urlsToTry.push({ url: proxiedUrl, label: 'GitHub代理' });
                }

                const KNOWN_FRP_MIRRORS = [
                    'https://ghfast.top/',
                    'https://mirror.ghproxy.com/',
                    'https://gh-proxy.com/',
                ];
                for (const mirror of KNOWN_FRP_MIRRORS) {
                    if (downloadUrl.includes('github.com')) {
                        const mirrorUrl = mirror + downloadUrl;
                        if (!urlsToTry.some(u => u.url === mirrorUrl)) {
                            urlsToTry.push({ url: mirrorUrl, label: `镜像(${new URL(mirror).hostname})` });
                        }
                    }
                }
                urlsToTry.push({ url: downloadUrl, label: 'GitHub源站' });
            } else {
                urlsToTry.push({ url: downloadUrl, label: 'GitHub源站' });
            }

            let dlResult = null;
            let lastError = null;
            for (let i = 0; i < urlsToTry.length; i++) {
                const { url, label } = urlsToTry[i];
                try {
                    if (i > 0) {
                        logger.info(`[FRP Install] Trying fallback ${i}/${urlsToTry.length - 1}: ${label}`);
                        api.io.emit('frp_install_progress', { step: 'downloading', percent: 0, message: `正在尝试${label}...` });
                    }
                    dlResult = await tryDownload(url, label);
                    lastError = null;
                    break;
                } catch (err) {
                    if (controller.signal.aborted) throw err;
                    lastError = err;
                    logger.warn(`[FRP Install] ${label} failed: ${err.message}`);
                }
            }

            if (!dlResult) {
                const failedSources = urlsToTry.map(u => `[${u.label}]`).join(', ');
                throw new Error(`所有下载源均失败(${failedSources}): ${lastError?.message || '未知错误'}`);
            }

            const totalBytes = dlResult.contentLength;
            let downloadedBytes = 0;
            const writer = fs.createWriteStream(tmpFile);
            let lastUpdateTime = Date.now();
            let lastDownloadedBytes = 0;

            dlResult.stream.on('data', (chunk) => {
                downloadedBytes += chunk.length;
                const now = Date.now();
                if (now - lastUpdateTime >= 1000) {
                    const speed = (downloadedBytes - lastDownloadedBytes) / ((now - lastUpdateTime) / 1000);
                    lastUpdateTime = now;
                    lastDownloadedBytes = downloadedBytes;
                    if (totalBytes > 0) {
                        const percent = Math.round((downloadedBytes / totalBytes) * 80);
                        api.io.emit('frp_install_progress', {
                            step: 'downloading', percent,
                            message: `下载中... ${(downloadedBytes / 1024 / 1024).toFixed(1)}MB / ${(totalBytes / 1024 / 1024).toFixed(1)}MB`,
                            speed
                        });
                    }
                }
            });

            await pipeline(dlResult.stream, writer, { signal: controller.signal });

            api.io.emit('frp_install_progress', { step: 'extracting', percent: 85, message: '正在解压...' });

            const extractDir = path.join(FRP_DIR, 'extract-tmp');
            fs.ensureDirSync(extractDir);

            if (isZip) {
                const zip = new AdmZip(tmpFile);
                zip.extractAllTo(extractDir, true);
            } else {
                execSync(`tar -xzf "${tmpFile}" -C "${extractDir}"`, { timeout: 120000 });
            }

            const frpcName = process.platform === 'win32' ? 'frpc.exe' : 'frpc';
            let frpcSource = null;
            const findFrpc = (dir) => {
                const entries = fs.readdirSync(dir, { withFileTypes: true });
                for (const entry of entries) {
                    const fullPath = path.join(dir, entry.name);
                    if (entry.isFile() && entry.name === frpcName) { frpcSource = fullPath; return; }
                    if (entry.isDirectory()) findFrpc(fullPath);
                    if (frpcSource) return;
                }
            };
            findFrpc(extractDir);

            if (!frpcSource) throw new Error('在下载的包中未找到 frpc 二进制文件');

            const frpcDest = getFrpBinaryPath();
            await fs.copy(frpcSource, frpcDest, { overwrite: true });

            if (process.platform !== 'win32') {
                try { execSync(`chmod +x "${frpcDest}"`); } catch (e) { }
            }

            await fs.remove(tmpFile);
            await fs.remove(extractDir);

            let detectedVer = version;
            try {
                const verOutput = execSync(`"${frpcDest}" --version`, { encoding: 'utf8', timeout: 5000 }).trim();
                if (verOutput) detectedVer = verOutput;
            } catch (e) { }

            const meta = readFrpMeta();
            meta.installed = true;
            meta.version = detectedVer;
            meta.installedAt = new Date().toISOString();
            meta.frpcPath = frpcDest;
            writeFrpMeta(meta);

            api.io.emit('frp_install_progress', { step: 'done', percent: 100, message: `安装完成! (${detectedVer})` });
        } catch (e) {
            if (e.name === 'AbortError' || e.code === 'ERR_CANCELED' || (controller && controller.signal.aborted)) {
                api.io.emit('frp_install_progress', { step: 'error', percent: 0, message: '已取消' });
            } else {
                logger.error('FRP Install Error:', e);
                api.io.emit('frp_install_progress', { step: 'error', percent: 0, message: '安装失败: ' + e.message });
            }
            try { await fs.remove(path.join(FRP_DIR, 'frp-tmp.tar.gz')); } catch (e2) { }
            try { await fs.remove(path.join(FRP_DIR, 'frp-tmp.zip')); } catch (e2) { }
            try { await fs.remove(path.join(FRP_DIR, 'extract-tmp')); } catch (e2) { }
        } finally {
            activeDownloads.delete('frp-install');
        }
    });

    router.post('/install/cancel', (req, res) => {
        if (activeDownloads.has('frp-install')) {
            activeDownloads.get('frp-install').abort();
            activeDownloads.delete('frp-install');
            res.json({ success: true, message: '已取消' });
        } else {
            res.status(404).json({ error: '没有正在进行的安装' });
        }
    });

    router.post('/uninstall', async (req, res) => {
        for (const [cid] of frpInstances) {
            await stopFrpProcess(cid);
        }
        const frpcPath = getFrpBinaryPath();
        try { await fs.remove(frpcPath); } catch (e) { }
        const meta = readFrpMeta();
        meta.installed = false;
        meta.version = null;
        writeFrpMeta(meta);
        res.json({ success: true });
    });

    router.get('/configs', (req, res) => {
        const meta = readFrpMeta();
        const configs = (meta.configs || []).map(c => ({
            ...c,
            running: frpInstances.has(c.id)
        }));
        res.json(configs);
    });

    router.get('/configs/:id', (req, res) => {
        const meta = readFrpMeta();
        const cfg = (meta.configs || []).find(c => c.id === req.params.id);
        if (!cfg) return res.status(404).json({ error: '配置不存在' });
        res.json({ ...cfg, running: frpInstances.has(cfg.id) });
    });

    router.post('/configs', (req, res) => {
        const { id, name, config } = req.body;
        if (!name) return res.status(400).json({ error: '名称不能为空' });
        if (config === undefined) return res.status(400).json({ error: '缺少配置内容' });

        const meta = readFrpMeta();
        if (!meta.configs) meta.configs = [];

        if (id) {
            const idx = meta.configs.findIndex(c => c.id === id);
            if (idx === -1) return res.status(404).json({ error: '配置不存在' });
            meta.configs[idx].name = name;
            meta.configs[idx].config = config;
            fs.writeFileSync(getConfigFilePath(id), config, 'utf8');
            writeFrpMeta(meta);
            res.json({ success: true, id });
        } else {
            const newId = 'frp-' + Date.now();
            const newCfg = {
                id: newId,
                name,
                config,
                createdAt: new Date().toISOString()
            };
            meta.configs.push(newCfg);
            fs.writeFileSync(getConfigFilePath(newId), config, 'utf8');
            writeFrpMeta(meta);
            res.json({ success: true, id: newId });
        }
    });

    router.post('/configs/delete', async (req, res) => {
        const { id } = req.body;
        if (!id) return res.status(400).json({ error: '缺少配置 ID' });

        if (frpInstances.has(id)) {
            await stopFrpProcess(id);
        }

        const meta = readFrpMeta();
        const idx = (meta.configs || []).findIndex(c => c.id === id);
        if (idx === -1) return res.status(404).json({ error: '配置不存在' });
        meta.configs.splice(idx, 1);
        writeFrpMeta(meta);

        try { await fs.remove(getConfigFilePath(id)); } catch (e) { }
        res.json({ success: true });
    });

    router.post('/start', (req, res) => {
        const { configId } = req.body;
        if (!configId) return res.status(400).json({ error: '缺少配置 ID' });
        if (frpInstances.has(configId)) return res.status(400).json({ error: '该配置已在运行中' });

        const meta = readFrpMeta();
        const frpcPath = getFrpBinaryPath();
        if (!meta.installed || !fs.existsSync(frpcPath)) {
            return res.status(400).json({ error: 'FRP 客户端未安装' });
        }
        const cfg = (meta.configs || []).find(c => c.id === configId);
        if (!cfg) return res.status(404).json({ error: '配置不存在' });

        const configFilePath = getConfigFilePath(configId);
        if (!fs.existsSync(configFilePath)) {
            fs.writeFileSync(configFilePath, cfg.config || '', 'utf8');
        }

        try {
            const proc = startFrpProcess(configId, configFilePath);
            res.json({ success: true, pid: proc.pid });
        } catch (e) {
            res.status(500).json({ error: '启动失败: ' + e.message });
        }
    });

    router.post('/stop', async (req, res) => {
        const { configId } = req.body;
        if (!configId) return res.status(400).json({ error: '缺少配置 ID' });
        if (!frpInstances.has(configId)) return res.status(400).json({ error: '该配置未在运行' });
        try {
            await stopFrpProcess(configId);
            res.json({ success: true });
        } catch (e) {
            res.status(500).json({ error: '停止失败: ' + e.message });
        }
    });

    router.post('/restart', async (req, res) => {
        const { configId } = req.body;
        if (!configId) return res.status(400).json({ error: '缺少配置 ID' });

        if (frpInstances.has(configId)) {
            await stopFrpProcess(configId);
        }

        const meta = readFrpMeta();
        const frpcPath = getFrpBinaryPath();
        if (!meta.installed || !fs.existsSync(frpcPath)) {
            return res.status(400).json({ error: 'FRP 客户端未安装' });
        }
        const cfg = (meta.configs || []).find(c => c.id === configId);
        if (!cfg) return res.status(404).json({ error: '配置不存在' });

        const configFilePath = getConfigFilePath(configId);
        if (!fs.existsSync(configFilePath)) {
            fs.writeFileSync(configFilePath, cfg.config || '', 'utf8');
        }

        try {
            const proc = startFrpProcess(configId, configFilePath);
            res.json({ success: true, pid: proc.pid });
        } catch (e) {
            res.status(500).json({ error: '重启失败: ' + e.message });
        }
    });

    router.get('/logs/:configId', (req, res) => {
        const inst = frpInstances.get(req.params.configId);
        res.json({ logs: inst ? inst.logs : [] });
    });

    api.registerRoutes('/', router);

    api.registerSidebarItem({
        id: 'frp-manager',
        labelKey: 'sidebar.frp_manager',
        icon: 'fa-network-wired',
        color: '#6366f1',
        view: 'frp-manager',
        location: 'global'
    });

    api.registerComponent('frp-manager', 'frontend/FrpManager.js');

    logger.info('FRP Plugin initialized');

    return {
        destroy: async () => {
            for (const [cid] of frpInstances) {
                await stopFrpProcess(cid);
            }
            logger.info('FRP Plugin destroyed, all processes stopped');
        }
    };
};
