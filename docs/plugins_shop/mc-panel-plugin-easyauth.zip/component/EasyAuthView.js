import { ref, reactive, onMounted, watch, computed, getCurrentInstance } from '/js/vue.esm-browser.js';
import { api } from '/js/api.js';
import { store } from '/js/store.js';
import { showToast, openModal } from '/js/utils.js';
import Avatar from '/js/components/Avatar.js';

// --- 正则工具 ---
const createRegex = (key) => new RegExp(`((?:^|\\n|\\s)${key}\\s*[:=]\\s*)([^\\n#]+)`, 'm');

// --- Schema 定义 ---
const SCHEMAS = {
    'main.conf': [
        { titleKey: 'easyauth.config_groups.login_session', items: [{ key: 'premium-auto-login', labelKey: 'easyauth.config_labels.premium_auto_login', type: 'boolean' }, { key: 'offline-by-default', labelKey: 'easyauth.config_labels.offline_by_default', type: 'boolean' }, { key: 'session-timeout', labelKey: 'easyauth.config_labels.session_timeout', type: 'number' }, { key: 'max-login-tries', labelKey: 'easyauth.config_labels.max_login_tries', type: 'number' }, { key: 'kick-timeout', labelKey: 'easyauth.config_labels.kick_timeout', type: 'number' }] },
        { titleKey: 'easyauth.config_groups.global_password', items: [{ key: 'enable-global-password', labelKey: 'easyauth.config_labels.enable_global_password', type: 'boolean' }, { key: 'single-use-global-password', labelKey: 'easyauth.config_labels.single_use_global_password', type: 'boolean' }] },
        { titleKey: 'easyauth.config_groups.others', items: [{ key: 'hide-player-coords', labelKey: 'easyauth.config_labels.hide_player_coords', type: 'boolean' }, { key: 'debug', labelKey: 'easyauth.config_labels.debug', type: 'boolean' }] }
    ],
    'extended.conf': [
        { titleKey: 'easyauth.config_groups.restrictions', items: [{ key: 'allow-chat', labelKey: 'easyauth.config_labels.allow_chat', type: 'boolean' }, { key: 'allow-commands', labelKey: 'easyauth.config_labels.allow_commands', type: 'boolean' }, { key: 'allow-movement', labelKey: 'easyauth.config_labels.allow_movement', type: 'boolean' }, { key: 'allow-block-interaction', labelKey: 'easyauth.config_labels.allow_block_interaction', type: 'boolean' }, { key: 'allow-block-breaking', labelKey: 'easyauth.config_labels.allow_block_breaking', type: 'boolean' }, { key: 'hide-inventory', labelKey: 'easyauth.config_labels.hide_inventory', type: 'boolean' }, { key: 'player-invulnerable', labelKey: 'easyauth.config_labels.player_invulnerable', type: 'boolean' }] },
        { titleKey: 'easyauth.config_groups.rules', items: [{ key: 'min-password-length', labelKey: 'easyauth.config_labels.min_password_length', type: 'number' }, { key: 'max-password-length', labelKey: 'easyauth.config_labels.max_password_length', type: 'number' }, { key: 'username-regexp', labelKey: 'easyauth.config_labels.username_regexp', type: 'text' }] }
    ],
    'translation.conf': [{ titleKey: 'easyauth.config_groups.others', items: [{ key: 'enable-server-side-translation', labelKey: 'easyauth.config_labels.enable_server_side_translation', type: 'boolean' }] }],
    'storage.conf': [
        { titleKey: 'easyauth.config_groups.storage', items: [{ key: 'database-type', labelKey: 'easyauth.config_labels.database_type', type: 'select', options: ['sqlite', 'mysql', 'mongodb'] }, { key: 'sqlite-path', labelKey: 'easyauth.config_labels.sqlite_path', type: 'text' }, { key: 'sqlite-table', labelKey: 'easyauth.config_labels.sqlite_table', type: 'text' }, { key: 'mysql-host', labelKey: 'easyauth.config_labels.mysql_host', type: 'text' }, { key: 'mysql-user', labelKey: 'easyauth.config_labels.mysql_user', type: 'text' }, { key: 'mysql-password', labelKey: 'easyauth.config_labels.mysql_password', type: 'text' }, { key: 'mysql-database', labelKey: 'easyauth.config_labels.mysql_database', type: 'text' }, { key: 'mysql-table', labelKey: 'easyauth.config_labels.mysql_table', type: 'text' }, { key: 'mongodb-connection-string', labelKey: 'easyauth.config_labels.mongodb_connection_string', type: 'text' }, { key: 'mongodb-database', labelKey: 'easyauth.config_labels.mongodb_database', type: 'text' }, { key: 'use-simpleauth-db', labelKey: 'easyauth.config_labels.use_simpleauth_db', type: 'boolean' }] }
    ],
    'technical.conf': [
        { titleKey: 'easyauth.config_groups.technical', items: [{ key: 'global-password', labelKey: 'easyauth.config_labels.global_password_hash', type: 'text' }] }
    ]
};

export default {
    components: { Avatar },
    template: `
    <div class="animate-in">
        <div v-if="!hasEasyAuth" class="d-flex flex-column align-items-center justify-content-center py-5 text-muted">
            <i class="fa-solid fa-user-shield fa-4x mb-3 opacity-25"></i>
            <h4>未检测到 EasyAuth 模组</h4>
            <p class="mt-2 text-center">此功能专为 <b>EasyAuth</b> 认证模组设计。<br>如已安装相应模组或数据库文件，您可以强制打开管理界面。</p>
            <div class="mt-4 d-flex gap-2">
                <button class="btn btn-primary px-4 rounded-pill fw-bold" @click="store.view = 'modrinth'">
                    <i class="fa-solid fa-cloud-arrow-down me-2"></i>前往下载
                </button>
                <button class="btn btn-outline-secondary px-4 rounded-pill fw-bold" @click="forceOpen = true; loadUsers();">
                    <i class="fa-solid fa-shield-halved me-2"></i>强制进入
                </button>
            </div>
        </div>

        <template v-else>
            <div class="page-header d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <div>
                    <h3 class="mb-1 text-nowrap">{{ $t('sidebar.auth') }}</h3>
                    <div class="small text-muted d-flex align-items-center gap-2">
                        <span v-if="dbStatus.hasDb" class="badge bg-success-subtle text-success border border-success-subtle">
                            <i class="fa-solid fa-database me-1"></i>{{ dbStatus.dbPath }}
                        </span>
                        <span v-else class="badge bg-secondary-subtle text-secondary border border-secondary-subtle">
                            <i class="fa-solid fa-circle-question me-1"></i>数据库尚未生成 (玩家注册后自动创建)
                        </span>
                    </div>
                </div>
                <div v-if="currentTab === 'config'" class="btn-group">
                    <button v-if="currentSchema" class="btn btn-outline-secondary" @click="toggleEditMode">
                        <i class="fa-solid" :class="editMode==='gui'?'fa-code':'fa-sliders'"></i>
                        <span class="d-none d-md-inline ms-1">{{ editMode==='gui' ? $t('common.text_mode') : $t('common.gui_mode') }}</span>
                    </button>
                    <button class="btn btn-success" @click="saveConfig" :disabled="saving">
                        <i class="fa-solid fa-save me-0 me-md-2"></i><span class="d-none d-md-inline">{{ saving ? $t('common.saving') : $t('common.save') }}</span>
                    </button>
                </div>
            </div>

            <div class="card bg-body-tertiary border-secondary mb-3 p-1 rounded-3" style="background-color: var(--c-surface) !important;">
                <ul class="nav nav-pills nav-fill">
                    <li class="nav-item">
                        <a class="nav-link cursor-pointer px-4" :class="{active: currentTab==='users'}" @click="currentTab='users'">
                            <i class="fa-solid fa-users me-2"></i>{{ $t('easyauth.users') }} ({{ userList.length }})
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link cursor-pointer px-4" :class="{active: currentTab==='config'}" @click="currentTab='config'">
                            <i class="fa-solid fa-sliders me-2"></i>{{ $t('easyauth.config') }}
                        </a>
                    </li>
                </ul>
            </div>

            <!-- 1. 用户列表 -->
            <div v-if="currentTab === 'users'">
                <div class="input-group mb-3 shadow-sm">
                    <span class="input-group-text bg-body-tertiary border-secondary"><i class="fa-solid fa-search"></i></span>
                    <input type="text" class="form-control border-secondary" v-model="searchUser" :placeholder="$t('common.search') + ' 玩家名称...'">
                    <button class="btn btn-outline-secondary border-secondary" @click="loadUsers" :disabled="loading">
                        <i class="fa-solid fa-rotate" :class="{'fa-spin': loading}"></i> {{ $t('common.refresh') }}
                    </button>
                </div>

                <div class="card shadow-sm border-secondary overflow-hidden" style="background-color: var(--c-surface) !important;">
                    <!-- 桌面端表格视图 -->
                    <div class="table-responsive d-none d-md-block">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light border-secondary">
                                <tr>
                                    <th>{{ $t('common.player') }}</th>
                                    <th>{{ $t('common.status') }}</th>
                                    <th class="d-none d-md-table-cell">最近 IP</th>
                                    <th class="d-none d-sm-table-cell">注册 / 活跃时间</th>
                                    <th class="text-end pe-3">{{ $t('common.actions') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="user in filteredUsers" :key="user.username">
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <avatar :player="user.username" :size="28" class="me-2 rounded"></avatar>
                                            <div>
                                                <div class="fw-bold">{{ user.username }}</div>
                                                <div v-if="user.uuid" class="text-muted font-monospace" style="font-size: 0.72rem;">{{ user.uuid }}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge" :class="user.is_registered ? 'bg-success' : 'bg-warning'">
                                            {{ user.is_registered ? $t('easyauth.registered') : $t('easyauth.unregistered') }}
                                        </span>
                                    </td>
                                    <td class="d-none d-md-table-cell">
                                        <span v-if="user.last_ip" class="font-monospace small text-body-secondary">{{ user.last_ip }}</span>
                                        <span v-else class="text-muted small">-</span>
                                    </td>
                                    <td class="d-none d-sm-table-cell">
                                        <div class="small text-body-secondary">
                                            <div v-if="user.registration_date">注册: {{ formatDateTime(user.registration_date) }}</div>
                                            <div v-if="user.last_login">活跃: {{ formatDateTime(user.last_login) }}</div>
                                            <div v-if="!user.registration_date && !user.last_login" class="text-muted">-</div>
                                        </div>
                                    </td>
                                    <td class="text-end pe-3">
                                        <button class="btn btn-sm btn-outline-primary me-2" @click="askChangePass(user.username)">
                                            <i class="fa-solid fa-key me-0 me-md-1"></i><span class="d-none d-md-inline">{{ $t('easyauth.password') }}</span>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" @click="askDeleteUser(user.username)">
                                            <i class="fa-solid fa-trash-can me-0 me-md-1"></i><span class="d-none d-md-inline">{{ $t('easyauth.unregister') }}</span>
                                        </button>
                                    </td>
                                </tr>
                                <tr v-if="filteredUsers.length === 0">
                                    <td colspan="5" class="text-center text-muted py-5">
                                        <i class="fa-solid fa-inbox fa-3x mb-3 opacity-25"></i>
                                        <div v-if="!dbStatus.hasDb">
                                            <p class="mb-1 fw-bold">未找到数据库文件</p>
                                            <p class="small text-muted mb-0">当玩家在游戏内输入 <code>/register 密码 密码</code> 注册后，系统将自动生成数据库并在此展示。</p>
                                        </div>
                                        <div v-else>
                                            <p class="mb-0">暂无匹配的玩家数据</p>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- 移动端卡片视图 -->
                    <div class="d-md-none p-2.5 p-sm-3 d-flex flex-column gap-2.5">
                        <div v-for="user in filteredUsers" :key="user.username" class="card border rounded-3 p-3 shadow-sm bg-body" style="background: var(--c-surface-elevated, var(--c-surface)) !important; border-color: var(--c-border) !important;">
                            <!-- 头部：头像、玩家名与状态 -->
                            <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
                                <div class="d-flex align-items-center gap-2.5 min-w-0 flex-grow-1">
                                    <avatar :player="user.username" :size="36" class="rounded flex-shrink-0"></avatar>
                                    <div class="min-w-0 flex-grow-1">
                                        <div class="fw-bold text-truncate" style="color: var(--c-text-primary); font-size: 0.95rem;">{{ user.username }}</div>
                                        <div v-if="user.uuid" class="text-muted font-monospace text-truncate" style="font-size: 0.7rem;" :title="user.uuid">
                                            {{ user.uuid }}
                                        </div>
                                    </div>
                                </div>
                                <span class="badge rounded-pill px-2.5 py-1 flex-shrink-0" :class="user.is_registered ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-warning-subtle text-warning border border-warning-subtle'" style="font-size: 0.68rem;">
                                    {{ user.is_registered ? $t('easyauth.registered') : $t('easyauth.unregistered') }}
                                </span>
                            </div>

                            <!-- 元数据行：IP与注册/活跃时间 -->
                            <div v-if="user.last_ip || user.registration_date || user.last_login" class="small text-muted py-2 my-1 border-top border-bottom d-flex flex-column gap-1" style="font-size: 0.72rem; border-color: var(--c-border) !important;">
                                <div v-if="user.last_ip" class="d-flex align-items-center justify-content-between">
                                    <span class="text-secondary"><i class="fa-solid fa-network-wired me-1.5 opacity-75"></i>最近 IP</span>
                                    <span class="font-monospace text-body">{{ user.last_ip }}</span>
                                </div>
                                <div v-if="user.registration_date" class="d-flex align-items-center justify-content-between">
                                    <span class="text-secondary"><i class="fa-regular fa-calendar-plus me-1.5 opacity-75"></i>注册时间</span>
                                    <span class="font-monospace text-body">{{ formatDateTime(user.registration_date) }}</span>
                                </div>
                                <div v-if="user.last_login" class="d-flex align-items-center justify-content-between">
                                    <span class="text-secondary"><i class="fa-regular fa-clock me-1.5 opacity-75"></i>活跃时间</span>
                                    <span class="font-monospace text-body">{{ formatDateTime(user.last_login) }}</span>
                                </div>
                            </div>

                            <!-- 底部操作按钮 -->
                            <div class="d-flex gap-2 justify-content-end pt-1">
                                <button class="btn btn-sm btn-outline-primary rounded-pill px-3 py-1 d-flex align-items-center gap-1.5 flex-grow-1 flex-sm-grow-0 justify-content-center" @click="askChangePass(user.username)">
                                    <i class="fa-solid fa-key"></i>
                                    <span class="small">{{ $t('easyauth.password') }}</span>
                                </button>
                                <button class="btn btn-sm btn-outline-danger rounded-pill px-3 py-1 d-flex align-items-center gap-1.5 flex-grow-1 flex-sm-grow-0 justify-content-center" @click="askDeleteUser(user.username)">
                                    <i class="fa-solid fa-trash-can"></i>
                                    <span class="small">{{ $t('easyauth.unregister') }}</span>
                                </button>
                            </div>
                        </div>

                        <!-- 移动端空状态 -->
                        <div v-if="filteredUsers.length === 0" class="text-center text-muted py-4">
                            <i class="fa-solid fa-inbox fa-3x mb-3 opacity-25"></i>
                            <div v-if="!dbStatus.hasDb">
                                <p class="mb-1 fw-bold">未找到数据库文件</p>
                                <p class="small text-muted mb-0">当玩家在游戏内输入 <code>/register 密码 密码</code> 注册后，系统将自动生成数据库并在此展示。</p>
                            </div>
                            <div v-else>
                                <p class="mb-0">暂无匹配的玩家数据</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 2. 配置管理 -->
            <div v-if="currentTab === 'config'" class="row g-3 config-layout">
                <div class="col-md-3 config-sidebar">
                    <div class="list-group overflow-auto shadow-sm config-list border border-secondary rounded-3" style="background-color: var(--c-surface) !important;">
                        <button v-for="file in configFiles" :key="file" class="list-group-item list-group-item-action border-0 mb-1 rounded-2" 
                                style="background: transparent; color: inherit;"
                                :class="{active: currentFile===file, 'bg-primary text-white': currentFile===file}" 
                                @click="loadFile(file)">
                            <i class="fa-regular fa-file-code me-2"></i>{{ file }}
                        </button>
                        <div v-if="configFiles.length === 0" class="p-3 text-muted text-center small">
                            暂无配置文件
                        </div>
                    </div>
                </div>
                <div class="col-md-9 config-content">
                    <Transition name="fade" mode="out-in">
                        <div v-if="editMode === 'text' || !currentSchema" class="card h-100 shadow-sm border-secondary" style="background-color: var(--c-surface) !important;" key="text">
                            <div class="card-header border-bottom border-secondary small text-muted d-flex justify-content-between" style="background: rgba(255,255,255,0.03)">
                                <span>{{ currentFile || '选择配置文件' }}</span>
                                <span v-if="fileContent" class="badge bg-secondary-subtle text-secondary">{{ lineCount }} 行</span>
                            </div>
                            <textarea v-if="currentFile" class="form-control border-0 rounded-0 text-body h-100" style="font-family: monospace; resize: none; background: transparent; min-height: 60vh;" v-model="fileContent" spellcheck="false"></textarea>
                        </div>
                        <div v-else class="h-100 overflow-auto pr-2 custom-scrollbar" key="gui">
                            <div class="row g-3">
                                <div class="col-md-12" v-for="(group, idx) in currentSchema" :key="idx">
                                    <div class="card border-secondary shadow-sm" style="background-color: var(--c-surface) !important;">
                                        <div class="card-header border-bottom border-secondary fw-bold" style="background: rgba(255,255,255,0.03)">{{ $t(group.titleKey) }}</div>
                                        <div class="card-body">
                                            <div v-for="item in group.items" :key="item.key" class="mb-3 row align-items-center">
                                                <label class="col-sm-5 col-form-label small text-body-secondary">{{ $t(item.labelKey) }}</label>
                                                <div class="col-sm-7">
                                                    <div v-if="item.type === 'boolean'" class="form-check form-switch m-0"><input class="form-check-input" type="checkbox" v-model="formModel[item.key]"></div>
                                                    <input v-else-if="item.type === 'number'" type="number" class="form-control form-control-sm" v-model="formModel[item.key]">
                                                    <CustomSelect v-else-if="item.type === 'select'" v-model="formModel[item.key]" :options="item.options" size="sm" />
                                                    <input v-else type="text" class="form-control form-control-sm" v-model="formModel[item.key]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Transition>
                </div>
            </div>
        </template>
    </div>
    `,
    setup() {
        const currentTab = ref('users');
        const userList = ref([]);
        const searchUser = ref('');
        const configFiles = ref([]);
        const currentFile = ref('');
        const fileContent = ref('');
        const editMode = ref('text');
        const loading = ref(false);
        const saving = ref(false);
        const forceOpen = ref(false);
        const formModel = reactive({});
        const dbStatus = reactive({ hasDb: false, dbPath: null, tableName: null });
        const currentSchema = computed(() => SCHEMAS[currentFile.value] || null);
        const { proxy } = getCurrentInstance();
        const $t = proxy.$t;

        const hasEasyAuth = computed(() => {
            return Boolean(store.hasEasyAuth || store.stats?.hasEasyAuth || dbStatus.hasDb || userList.value.length > 0 || forceOpen.value);
        });

        const lineCount = computed(() => {
            return fileContent.value ? fileContent.value.split('\n').length : 0;
        });

        const formatDateTime = (val) => {
            if (!val) return '';
            try {
                const d = new Date(val);
                if (!isNaN(d.getTime())) {
                    return d.toLocaleString();
                }
            } catch (e) { }
            return String(val).replace(/\[.*\]$/, '');
        };

        const loadStatus = async () => {
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-easyauth/easyauth/status');
                Object.assign(dbStatus, res.data || {});
            } catch (e) { }
        };

        const loadUsers = async () => {
            loading.value = true;
            try {
                await loadStatus();
                const res = await api.get('/api/plugins/mc-panel-plugin-easyauth/easyauth/users');
                userList.value = Array.isArray(res.data) ? res.data : [];
            } catch (e) {
                console.error('Failed to load EasyAuth users:', e);
                showToast($t('common.error') + ': ' + (e.response?.data?.error || e.message), 'danger');
            } finally {
                loading.value = false;
            }
        };

        const askChangePass = (username) => {
            openModal({
                title: `${$t('easyauth.password')}: ${username}`,
                message: $t('easyauth.new_password_prompt'),
                mode: 'input',
                placeholder: $t('easyauth.new_password_placeholder'),
                callback: async (newPass) => {
                    if (!newPass) return;
                    try {
                        const res = await api.post('/api/plugins/mc-panel-plugin-easyauth/easyauth/password', { username, password: newPass });
                        if (res.data.success) {
                            showToast($t('common.success'));
                        } else {
                            showToast(res.data.message || $t('common.error'), 'warning');
                        }
                    } catch (e) {
                        showToast($t('common.error') + ': ' + (e.response?.data?.error || e.message), 'danger');
                    }
                }
            });
        };

        const askDeleteUser = (username) => {
            openModal({
                title: $t('common.confirm'),
                message: `${$t('easyauth.confirm_unregister')} [${username}]?`,
                callback: async () => {
                    try {
                        const res = await api.post('/api/plugins/mc-panel-plugin-easyauth/easyauth/delete', { username });
                        if (res.data.success) {
                            showToast($t('common.success'));
                            loadUsers();
                        } else {
                            showToast(res.data.message || $t('easyauth.failed'), 'warning');
                        }
                    } catch (e) {
                        showToast($t('easyauth.failed') + ': ' + (e.response?.data?.error || e.message), 'danger');
                    }
                }
            });
        };

        const loadFileList = async () => {
            try {
                const res = await api.get('/api/plugins/mc-panel-plugin-easyauth/easyauth/configs');
                configFiles.value = Array.isArray(res.data) ? res.data : [];
                if (configFiles.value.length && !currentFile.value) {
                    loadFile(configFiles.value.find(f => f.includes('main')) || configFiles.value[0]);
                }
            } catch (e) { }
        };

        const loadFile = async (fn) => {
            try {
                const res = await api.get(`/api/plugins/mc-panel-plugin-easyauth/easyauth/configs/${fn}`);
                fileContent.value = res.data.content || '';
                currentFile.value = fn;
                if (currentSchema.value) {
                    editMode.value = 'gui';
                    parseToGui();
                } else {
                    editMode.value = 'text';
                }
            } catch (e) { }
        };

        const parseToGui = () => {
            const text = fileContent.value;
            if (!currentSchema.value) return;
            currentSchema.value.forEach(g => g.items.forEach(i => {
                const match = text.match(createRegex(i.key));
                if (match) {
                    let v = match[2].trim().split('#')[0].trim().replace(/^['"](.*)['"]$/, '$1');
                    if (i.type === 'boolean') formModel[i.key] = (v === 'true');
                    else if (i.type === 'number') formModel[i.key] = Number(v);
                    else formModel[i.key] = v;
                } else {
                    formModel[i.key] = i.type === 'boolean' ? false : '';
                }
            }));
        };

        const syncToText = () => {
            let text = fileContent.value;
            if (!currentSchema.value) return;
            currentSchema.value.forEach(g => g.items.forEach(i => {
                if (formModel[i.key] !== undefined) {
                    text = text.replace(createRegex(i.key), (m, p1) => p1 + String(formModel[i.key]));
                }
            }));
            fileContent.value = text;
        };

        const saveConfig = async () => {
            if (!currentFile.value) return;
            if (editMode.value === 'gui') syncToText();
            try {
                saving.value = true;
                await api.post(`/api/plugins/mc-panel-plugin-easyauth/easyauth/configs/${currentFile.value}`, { content: fileContent.value });
                showToast($t('common.success'));
            } catch (e) {
                showToast($t('common.error') + ': ' + (e.response?.data?.error || e.message), 'danger');
            } finally {
                saving.value = false;
            }
        };

        const toggleEditMode = () => {
            if (editMode.value === 'text') {
                parseToGui();
                editMode.value = 'gui';
            } else {
                syncToText();
                editMode.value = 'text';
            }
        };

        const filteredUsers = ref([]);
        watch([userList, searchUser], () => {
            const q = searchUser.value.trim().toLowerCase();
            filteredUsers.value = userList.value.filter(u => !q || (u.username && u.username.toLowerCase().includes(q)));
        });

        watch(currentTab, (val) => {
            if (val === 'users') loadUsers();
            if (val === 'config') loadFileList();
        });

        onMounted(() => {
            loadUsers();
            loadFileList();
        });

        return {
            store,
            hasEasyAuth,
            forceOpen,
            currentTab,
            userList,
            filteredUsers,
            searchUser,
            configFiles,
            currentFile,
            fileContent,
            lineCount,
            editMode,
            loading,
            saving,
            dbStatus,
            currentSchema,
            formModel,
            formatDateTime,
            loadUsers,
            askDeleteUser,
            askChangePass,
            loadFile,
            saveConfig,
            toggleEditMode
        };
    }
};
