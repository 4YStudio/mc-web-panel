const path = require('path');
const fs = require('fs-extra');
const { execFile } = require('child_process');
const bcrypt = require('bcryptjs');

// 尝试加载 sqlite3 驱动模块
let sqlite3Module = null;
try {
    sqlite3Module = require('sqlite3');
} catch (e) {
    try {
        sqlite3Module = require(path.join(__dirname, 'node_modules', 'sqlite3'));
    } catch (e2) {
        sqlite3Module = null;
    }
}

// 统一数据库访问帮助对象 (支持原生 sqlite3 模块与系统 sqlite3 CLI 双模式降级)
const dbHelper = {
    open: (dbPath, modeStr) => {
        if (sqlite3Module) {
            const sqlite3 = sqlite3Module.verbose ? sqlite3Module.verbose() : sqlite3Module;
            const mode = modeStr === 'READWRITE'
                ? (sqlite3.OPEN_READWRITE || 2)
                : (sqlite3.OPEN_READONLY || 1);
            return new Promise((resolve, reject) => {
                const db = new sqlite3.Database(dbPath, mode, (err) => {
                    if (err) {
                        // 若原生模块打开失败，降级为 CLI 句柄
                        resolve({ type: 'cli', dbPath });
                    } else {
                        resolve({ type: 'native', db });
                    }
                });
            });
        }
        return Promise.resolve({ type: 'cli', dbPath });
    },

    all: (handle, sql, params = []) => {
        if (handle.type === 'native') {
            return new Promise((resolve, reject) => {
                handle.db.all(sql, params, (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows || []);
                });
            });
        }
        // CLI 模式降级
        return new Promise((resolve, reject) => {
            // 参数替换安全转义
            let formattedSql = sql;
            for (const param of params) {
                const escaped = typeof param === 'string' ? `'${param.replace(/'/g, "''")}'` : String(param);
                formattedSql = formattedSql.replace('?', escaped);
            }
            execFile('sqlite3', ['-json', handle.dbPath, formattedSql], (err, stdout, stderr) => {
                if (err) {
                    if (stderr && stderr.includes('no such table')) return resolve([]);
                    return reject(new Error(stderr || err.message));
                }
                try {
                    const trimmed = (stdout || '').trim();
                    if (!trimmed) return resolve([]);
                    const data = JSON.parse(trimmed);
                    resolve(Array.isArray(data) ? data : [data]);
                } catch (e) {
                    resolve([]);
                }
            });
        });
    },

    run: (handle, sql, params = []) => {
        if (handle.type === 'native') {
            return new Promise((resolve, reject) => {
                handle.db.run(sql, params, function (err) {
                    if (err) reject(err);
                    else resolve({ changes: this.changes });
                });
            });
        }
        // CLI 模式降级
        return new Promise((resolve, reject) => {
            let formattedSql = sql;
            for (const param of params) {
                const escaped = typeof param === 'string' ? `'${param.replace(/'/g, "''")}'` : String(param);
                formattedSql = formattedSql.replace('?', escaped);
            }
            execFile('sqlite3', [handle.dbPath, formattedSql], (err, stdout, stderr) => {
                if (err) return reject(new Error(stderr || err.message));
                // 获取变更行数
                execFile('sqlite3', [handle.dbPath, 'SELECT changes();'], (cErr, cStdout) => {
                    const changes = parseInt((cStdout || '').trim(), 10) || 1;
                    resolve({ changes });
                });
            });
        });
    },

    close: (handle) => {
        if (handle.type === 'native' && handle.db) {
            return new Promise((resolve) => {
                handle.db.close(() => resolve());
            });
        }
        return Promise.resolve();
    }
};

// 递归查找目录下的 db 文件
const scanDirectoryForDb = (dirPath) => {
    if (!fs.existsSync(dirPath)) return null;
    try {
        const files = fs.readdirSync(dirPath);
        for (const file of files) {
            const fullPath = path.join(dirPath, file);
            const stat = fs.statSync(fullPath);
            if (stat.isFile() && (file.endsWith('.db') || file.endsWith('.sqlite') || file.endsWith('.sqlite3'))) {
                return fullPath;
            }
        }
    } catch (e) { }
    return null;
};

// 解析 storage.conf 中的配置
const parseStorageConf = (instDir) => {
    const configDirs = [
        path.join(instDir, 'config', 'EasyAuth'),
        path.join(instDir, 'config', 'easyauth'),
        path.join(instDir, 'EasyAuth'),
        path.join(instDir, 'easyauth')
    ];

    for (const cDir of configDirs) {
        const confFile = path.join(cDir, 'storage.conf');
        if (fs.existsSync(confFile)) {
            try {
                const content = fs.readFileSync(confFile, 'utf8');
                const pathMatch = content.match(/sqlite-path\s*=\s*["']?([^"'\r\n#]+)["']?/);
                const tableMatch = content.match(/sqlite-table\s*=\s*["']?([^"'\r\n#]+)["']?/);
                const typeMatch = content.match(/database-type\s*=\s*["']?([^"'\r\n#]+)["']?/);
                return {
                    dbType: typeMatch ? typeMatch[1].trim() : 'sqlite',
                    sqlitePath: pathMatch ? pathMatch[1].trim() : null,
                    sqliteTable: tableMatch ? tableMatch[1].trim() : 'easyauth'
                };
            } catch (e) { }
        }
    }
    return null;
};

// 查找数据库文件全路径及配置表名
const findDbInfo = (instDir) => {
    // 1. 优先读取 storage.conf
    const confInfo = parseStorageConf(instDir);
    if (confInfo && confInfo.sqlitePath) {
        const customCandidates = [
            path.resolve(instDir, confInfo.sqlitePath),
            path.resolve(instDir, 'config', confInfo.sqlitePath),
            path.resolve(instDir, 'EasyAuth', confInfo.sqlitePath),
            path.resolve(instDir, 'easyauth', confInfo.sqlitePath)
        ];
        for (const p of customCandidates) {
            if (fs.existsSync(p) && fs.statSync(p).isFile()) {
                return { dbPath: p, tableName: confInfo.sqliteTable || 'easyauth' };
            }
        }
    }

    // 2. 检查标准候选路径 (同时兼顾 Linux 大小写)
    const standardCandidates = [
        path.join(instDir, 'EasyAuth', 'easyauth.db'),
        path.join(instDir, 'easyauth', 'easyauth.db'),
        path.join(instDir, 'config', 'EasyAuth', 'easyauth.db'),
        path.join(instDir, 'config', 'easyauth', 'easyauth.db'),
        path.join(instDir, 'config', 'EasyAuth', 'players.db'),
        path.join(instDir, 'config', 'easyauth', 'players.db'),
        path.join(instDir, 'EasyAuth', 'players.db'),
        path.join(instDir, 'easyauth', 'players.db'),
        path.join(instDir, 'mods', 'EasyAuth', 'easyauth.db'),
        path.join(instDir, 'mods', 'easyauth', 'easyauth.db')
    ];
    for (const p of standardCandidates) {
        if (fs.existsSync(p) && fs.statSync(p).isFile()) {
            return { dbPath: p, tableName: confInfo?.sqliteTable || 'easyauth' };
        }
    }

    // 3. 回退扫描
    const dirsToScan = [
        path.join(instDir, 'EasyAuth'),
        path.join(instDir, 'easyauth'),
        path.join(instDir, 'config', 'EasyAuth'),
        path.join(instDir, 'config', 'easyauth')
    ];
    for (const d of dirsToScan) {
        const found = scanDirectoryForDb(d);
        if (found) return { dbPath: found, tableName: confInfo?.sqliteTable || 'easyauth' };
    }

    return null;
};

// 查找配置目录
const findConfigDir = (instDir) => {
    const candidates = [
        path.join(instDir, 'config', 'EasyAuth'),
        path.join(instDir, 'config', 'easyauth'),
        path.join(instDir, 'EasyAuth'),
        path.join(instDir, 'easyauth'),
        path.join(instDir, 'mods', 'EasyAuth'),
        path.join(instDir, 'mods', 'easyauth')
    ];
    for (const p of candidates) {
        if (fs.existsSync(p)) return p;
    }
    return null;
};

const detectTable = async (db, preferredTable) => {
    const tables = await dbHelper.all(db, "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'");
    const tableNames = tables.map(t => t.name);
    if (preferredTable && tableNames.includes(preferredTable)) return preferredTable;
    if (tableNames.includes('easyauth')) return 'easyauth';
    if (tableNames.includes('users')) return 'users';
    if (tableNames.includes('auth_users')) return 'auth_users';
    if (tableNames.includes('players')) return 'players';
    if (tableNames.includes('accounts')) return 'accounts';
    if (tableNames.length > 0) return tableNames[0];
    throw new Error(`数据库中未找到任何数据表. 现有: [${tableNames.join(', ')}]`);
};

const detectNameCol = (columns) => {
    if (columns.includes('username')) return 'username';
    if (columns.includes('name')) return 'name';
    if (columns.includes('player')) return 'player';
    if (columns.includes('username_lower')) return 'username_lower';
    return null;
};

module.exports = (api) => {
    const withInstance = (req, res, next) => {
        const instanceId = (req.query && req.query.instanceId) || (req.body && req.body.instanceId) || api.getActiveInstanceId() || 'default';
        const instDir = api.getInstanceDir(instanceId);
        if (!instDir) return res.status(404).json({ error: '实例不存在' });
        req.instanceId = instanceId;
        req.instDir = instDir;
        next();
    };

    api.registerSidebarItem({
        id: 'easyauth',
        labelKey: 'sidebar.auth',
        icon: 'fa-user-shield',
        view: 'easyauth-view',
        location: 'instance'
    });
    api.registerComponent('easyauth-view', 'component/EasyAuthView.js');

    const router = require('express').Router();

    // 查询当前实例数据库状态
    router.get('/status', withInstance, async (req, res) => {
        const dbInfo = findDbInfo(req.instDir);
        const configDir = findConfigDir(req.instDir);
        res.json({
            hasDb: Boolean(dbInfo),
            dbPath: dbInfo ? path.relative(req.instDir, dbInfo.dbPath) : null,
            tableName: dbInfo?.tableName || null,
            hasConfig: Boolean(configDir),
            configDir: configDir ? path.relative(req.instDir, configDir) : null
        });
    });

    // 获取玩家用户列表
    router.get('/users', withInstance, async (req, res) => {
        const { instDir } = req;
        const dbInfo = findDbInfo(instDir);
        if (!dbInfo) {
            return res.json([]);
        }

        let dbHandle;
        try {
            dbHandle = await dbHelper.open(dbInfo.dbPath, 'READONLY');
            const tableName = await detectTable(dbHandle, dbInfo.tableName);
            const columnsData = await dbHelper.all(dbHandle, `PRAGMA table_info(${tableName})`);
            const columns = columnsData.map(c => c.name);

            const nameCol = detectNameCol(columns);
            const idCol = columns.includes('id') ? 'id' : (columns.includes('uuid') ? 'uuid' : null);

            if (!nameCol) throw new Error(`无法识别用户名字段，现有列: ${columns.join(', ')}`);

            const rows = await dbHelper.all(dbHandle, `SELECT * FROM ${tableName}`);

            const users = rows.map(r => {
                let isRegistered = 1;
                let lastIp = r.last_ip || '';
                let lastLogin = '';
                let regDate = '';

                // 解析 EasyAuth 的 data JSON 列
                if (r.data) {
                    try {
                        const dataObj = typeof r.data === 'string' ? JSON.parse(r.data) : r.data;
                        if (dataObj) {
                            if (dataObj.password !== undefined) {
                                isRegistered = Boolean(dataObj.password && dataObj.password.length > 0) ? 1 : 0;
                            }
                            if (dataObj.last_ip) lastIp = dataObj.last_ip;
                            if (dataObj.last_authenticated_date) lastLogin = dataObj.last_authenticated_date;
                            if (dataObj.registration_date) regDate = dataObj.registration_date;
                        }
                    } catch (err) { }
                }

                if (r.is_registered !== undefined) {
                    isRegistered = r.is_registered ? 1 : 0;
                }

                return {
                    id: idCol ? r[idCol] : (r.id || r.uuid || ''),
                    username: r[nameCol],
                    uuid: r.uuid || '',
                    is_registered: isRegistered,
                    last_ip: lastIp,
                    last_login: lastLogin,
                    registration_date: regDate
                };
            });

            res.json(users);
        } catch (e) {
            api.logger.error('[EasyAuth Error]', e);
            res.status(500).json({ error: 'DB读取失败: ' + e.message });
        } finally {
            if (dbHandle) await dbHelper.close(dbHandle);
        }
    });

    // 注销 / 删除玩家
    router.post('/delete', withInstance, async (req, res) => {
        const { instDir } = req;
        const dbInfo = findDbInfo(instDir);
        const { username } = req.body;
        if (!username) return res.status(400).json({ error: '缺少玩家名称' });
        if (!dbInfo) return res.status(404).json({ error: '数据库不存在' });

        let dbHandle;
        try {
            dbHandle = await dbHelper.open(dbInfo.dbPath, 'READWRITE');
            const tableName = await detectTable(dbHandle, dbInfo.tableName);
            const columnsData = await dbHelper.all(dbHandle, `PRAGMA table_info(${tableName})`);
            const columns = columnsData.map(c => c.name);
            const nameCol = detectNameCol(columns);
            if (!nameCol) throw new Error('无法识别用户名字段');

            let sql = `DELETE FROM ${tableName} WHERE ${nameCol} = ?`;
            let params = [username];
            if (columns.includes('username_lower')) {
                sql = `DELETE FROM ${tableName} WHERE ${nameCol} = ? OR username_lower = ?`;
                params = [username, username.toLowerCase()];
            }

            const result = await dbHelper.run(dbHandle, sql, params);
            if (result.changes > 0) {
                res.json({ success: true });
            } else {
                res.json({ success: false, message: '玩家不存在' });
            }
        } catch (e) {
            api.logger.error('[EasyAuth Delete Error]', e);
            res.status(500).json({ error: '操作失败: ' + e.message });
        } finally {
            if (dbHandle) await dbHelper.close(dbHandle);
        }
    });

    // 获取配置文件列表
    router.get('/configs', withInstance, async (req, res) => {
        const EASYAUTH_CONFIG_DIR = findConfigDir(req.instDir);
        try {
            if (!EASYAUTH_CONFIG_DIR) return res.json([]);
            const files = await fs.readdir(EASYAUTH_CONFIG_DIR);
            const confFiles = files.filter(f => f.endsWith('.conf') || f.endsWith('.json'));
            res.json(confFiles);
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // 读取单个配置文件
    router.get('/configs/:filename', withInstance, async (req, res) => {
        const EASYAUTH_CONFIG_DIR = findConfigDir(req.instDir);
        if (!EASYAUTH_CONFIG_DIR) return res.status(404).json({ error: '配置目录不存在' });
        const safeName = path.basename(req.params.filename);
        const filePath = path.join(EASYAUTH_CONFIG_DIR, safeName);
        if (!fs.existsSync(filePath)) return res.status(404).json({ error: '文件不存在' });
        try {
            const content = await fs.readFile(filePath, 'utf-8');
            res.json({ content, filename: safeName });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // 保存单个配置文件
    router.post('/configs/:filename', withInstance, async (req, res) => {
        const EASYAUTH_CONFIG_DIR = findConfigDir(req.instDir);
        if (!EASYAUTH_CONFIG_DIR) return res.status(404).json({ error: '配置目录不存在' });
        const safeName = path.basename(req.params.filename);
        const filePath = path.join(EASYAUTH_CONFIG_DIR, safeName);
        try {
            await fs.writeFile(filePath, req.body.content || '', 'utf-8');
            res.json({ success: true });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // 修改玩家密码 (兼容原生 data JSON 列与独立 password 列)
    router.post('/password', withInstance, async (req, res) => {
        const { instDir } = req;
        const dbInfo = findDbInfo(instDir);
        const { username, password } = req.body;
        if (!username) return res.status(400).json({ error: '缺少玩家名称' });
        if (!password || password.length < 3) return res.status(400).json({ error: '密码太短 (至少需3位)' });
        if (!dbInfo) return res.status(404).json({ error: '数据库不存在' });

        let dbHandle;
        try {
            dbHandle = await dbHelper.open(dbInfo.dbPath, 'READWRITE');
            const tableName = await detectTable(dbHandle, dbInfo.tableName);
            const columnsData = await dbHelper.all(dbHandle, `PRAGMA table_info(${tableName})`);
            const columns = columnsData.map(c => c.name);
            const nameCol = detectNameCol(columns);
            if (!nameCol) throw new Error('无法识别用户名字段');

            const hashedPassword = await bcrypt.hash(password, 10);
            let result;

            if (columns.includes('data')) {
                // EasyAuth 架构：密码保存在 data 列的 JSON 字符串中
                let querySql = `SELECT data FROM ${tableName} WHERE ${nameCol} = ?`;
                let queryParams = [username];
                if (columns.includes('username_lower')) {
                    querySql = `SELECT data FROM ${tableName} WHERE ${nameCol} = ? OR username_lower = ?`;
                    queryParams = [username, username.toLowerCase()];
                }

                const existingRows = await dbHelper.all(dbHandle, querySql, queryParams);
                if (existingRows.length === 0) {
                    return res.json({ success: false, message: '玩家不存在' });
                }

                let dataObj = {};
                try {
                    dataObj = JSON.parse(existingRows[0].data || '{}');
                } catch (e) {
                    dataObj = {};
                }
                dataObj.password = hashedPassword;
                const updatedData = JSON.stringify(dataObj);

                let updateSql = `UPDATE ${tableName} SET data = ? WHERE ${nameCol} = ?`;
                let updateParams = [updatedData, username];
                if (columns.includes('username_lower')) {
                    updateSql = `UPDATE ${tableName} SET data = ? WHERE ${nameCol} = ? OR username_lower = ?`;
                    updateParams = [updatedData, username, username.toLowerCase()];
                }
                result = await dbHelper.run(dbHandle, updateSql, updateParams);
            } else if (columns.includes('password')) {
                // 普通独立 password 列
                let updateSql = `UPDATE ${tableName} SET password = ? WHERE ${nameCol} = ?`;
                let updateParams = [hashedPassword, username];
                if (columns.includes('username_lower')) {
                    updateSql = `UPDATE ${tableName} SET password = ? WHERE ${nameCol} = ? OR username_lower = ?`;
                    updateParams = [hashedPassword, username, username.toLowerCase()];
                }
                result = await dbHelper.run(dbHandle, updateSql, updateParams);
            } else {
                throw new Error(`数据表 ${tableName} 中未找到可更新的密码或数据列`);
            }

            if (result.changes > 0) {
                res.json({ success: true });
            } else {
                res.json({ success: false, message: '玩家不存在或未更新' });
            }
        } catch (e) {
            api.logger.error('[EasyAuth Password Error]', e);
            res.status(500).json({ error: '修改失败: ' + e.message });
        } finally {
            if (dbHandle) await dbHelper.close(dbHandle);
        }
    });

    api.registerRoutes('/easyauth', router);
};
