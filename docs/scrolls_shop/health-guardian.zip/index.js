/**
 * 健康防沉迷守护卷轴 (Health Guardian Scroll) v1.1.0
 * 
 * 核心设计：
 * 1. 即时在线检测：启动时自动同步当前所有已在线玩家，绝不漏记；
 * 2. 实例持久化存储：使用 scroll.storage 存储玩家入服会话与提醒记录；
 * 3. 稳健间隔算法：基于 lastRemindedMinute 计算间隔，消除整点漂移，支持最低 1 分钟；
 * 4. 立体多通道提醒：ActionBar + tellraw 私信 + playsound 拾取音效；
 * 5. 聊天栏查询交互：玩家输入 !health、!防沉迷、!时长 立即私聊反馈在线时长与剩余时间。
 */
module.exports = async function(scroll) {
    const sessions = new Map();
    const savedSessions = scroll.storage.get('sessions', {});
    const now = Date.now();

    const syncCurrentOnline = () => {
        const onlineList = scroll.getOnlinePlayers ? scroll.getOnlinePlayers() : [];
        for (const player of onlineList) {
            if (!sessions.has(player)) {
                const saved = savedSessions[player];
                const joinTime = (saved && (now - saved.lastActive < 5 * 60 * 1000)) ? saved.joinTime : now;
                sessions.set(player, {
                    joinTime,
                    lastRemindedMinute: (saved && saved.lastRemindedMinute) || 0
                });
            }
        }
    };

    syncCurrentOnline();

    const saveToStorage = () => {
        const data = {};
        const curTime = Date.now();
        for (const [p, s] of sessions.entries()) {
            data[p] = {
                joinTime: s.joinTime,
                lastRemindedMinute: s.lastRemindedMinute,
                lastActive: curTime
            };
        }
        scroll.storage.set('sessions', data);
    };

    scroll.onPlayerJoin(({ player }) => {
        if (!player) return;
        const curTime = Date.now();
        const saved = scroll.storage.get('sessions', {})[player];
        const joinTime = (saved && (curTime - saved.lastActive < 5 * 60 * 1000)) ? saved.joinTime : curTime;
        sessions.set(player, {
            joinTime,
            lastRemindedMinute: (saved && saved.lastRemindedMinute) || 0
        });
        saveToStorage();
    });

    scroll.onPlayerQuit(({ player }) => {
        if (!player) return;
        saveToStorage();
        sessions.delete(player);
    });

    const sendReminder = async (player, onlineMinutes) => {
        const hours = (onlineMinutes / 60).toFixed(1).replace('.0', '');
        const template = scroll.config.remindMessage || '您已连续开荒 {minutes} 分钟啦，站起来活动一下，保护视力哦！';
        const content = template
            .replace(/\{minutes\}/g, onlineMinutes)
            .replace(/\{hours\}/g, hours);

        const formatted = '§6[健康提醒] §e' + content;

        if (scroll.config.enableActionBar !== false) {
            await scroll.sendActionBar(player, formatted);
        }

        if (scroll.config.enableChatMessage !== false) {
            if (scroll.sendMessage) {
                await scroll.sendMessage(player, formatted);
            }
        }

        if (scroll.config.enableSound !== false) {
            if (scroll.playSound) {
                await scroll.playSound(player, 'entity.experience_orb.pickup');
            }
        }
    };

    const timerInterval = 30 * 1000;
    scroll.schedule(timerInterval, async () => {
        syncCurrentOnline();

        const intervalMin = Math.max(1, Number(scroll.config.remindIntervalMinutes) || 60);
        const curTime = Date.now();

        for (const [player, s] of sessions.entries()) {
            const elapsedMinutes = Math.floor((curTime - s.joinTime) / 60000);
            if (elapsedMinutes >= intervalMin) {
                if (!s.lastRemindedMinute || (elapsedMinutes - s.lastRemindedMinute >= intervalMin)) {
                    s.lastRemindedMinute = elapsedMinutes;
                    await sendReminder(player, elapsedMinutes);
                }
            }
        }

        saveToStorage();
    });

    scroll.onChat(async ({ player, message }) => {
        const msg = (message || '').trim();
        if (/^(!health|!防沉迷|!时长|!online|!time)$/i.test(msg)) {
            let s = sessions.get(player);
            const curTime = Date.now();
            if (!s) {
                s = { joinTime: curTime, lastRemindedMinute: 0 };
                sessions.set(player, s);
            }
            const elapsedMinutes = Math.floor((curTime - s.joinTime) / 60000);
            const hours = (elapsedMinutes / 60).toFixed(1).replace('.0', '');
            const intervalMin = Math.max(1, Number(scroll.config.remindIntervalMinutes) || 60);
            const nextInMinutes = Math.max(1, intervalMin - ((elapsedMinutes - (s.lastRemindedMinute || 0)) % intervalMin));

            const reply = '§6[健康守护] §e您当前已连续在线 §a' + elapsedMinutes + ' 分钟§e（约 §b' + hours + ' 小时§e），距离下次休息提醒还有 §c' + nextInMinutes + ' 分钟§e。';
            if (scroll.sendMessage) {
                await scroll.sendMessage(player, reply);
                await scroll.playSound(player, 'entity.experience_orb.pickup');
            } else {
                await scroll.sendActionBar(player, reply);
            }
        }
    });

    scroll.logger.info('健康防沉迷守护卷轴 (v1.1.0) 已就绪');

    return {
        destroy: async () => {
            saveToStorage();
            sessions.clear();
            scroll.logger.info('健康防沉迷守护卷轴已注销');
        }
    };
};
