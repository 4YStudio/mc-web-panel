/**
 * 健康守护卷轴 (Health Guardian Scroll)
 * 追踪连续游戏时长并在 ActionBar 提示休息
 */
module.exports = async function(scroll) {
    // 记录玩家进入时间 { [player]: timestamp }
    const joinTimestamps = new Map();

    scroll.onPlayerJoin(({ player }) => {
        joinTimestamps.set(player, Date.now());
    });

    scroll.onPlayerQuit(({ player }) => {
        joinTimestamps.delete(player);
    });

    // 每分钟轮询一次在线玩家时长
    scroll.schedule(60 * 1000, async (instanceId) => {
        const intervalMin = Math.max(5, Number(scroll.config.remindIntervalMinutes) || 60);
        const now = Date.now();

        for (const [player, joinTime] of joinTimestamps.entries()) {
            const onlineMinutes = Math.floor((now - joinTime) / (60 * 1000));
            if (onlineMinutes > 0 && onlineMinutes % intervalMin === 0) {
                const hours = (onlineMinutes / 60).toFixed(1).replace('.0', '');
                const raw = scroll.config.remindMessage || '您已连续开荒 {hours} 小时啦，站起来活动一下，保护视力哦！';
                const msg = raw.replace(/\{hours\}/g, hours);

                // 通过 ActionBar 发送无侵入轻量提示
                await scroll.sendActionBar(player, `§6[健康提醒] §e${msg}`, instanceId);
            }
        }
    });
};
