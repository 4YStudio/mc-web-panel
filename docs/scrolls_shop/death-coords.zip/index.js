/**
 * 卷轴：阵亡坐标私信守护 (Death Coordinates)
 */
module.exports = async function(scroll) {
    scroll.onDeath(async ({ player, deathReason, raw }) => {
        scroll.logger.info('捕获玩家阵亡: ' + player + ', 死因: ' + deathReason);

        const deathTime = new Date().toLocaleTimeString();

        if (scroll.config.sendPrivateMsg) {
            await scroll.sleep(1500);
            scroll.sendCommand('tellraw ' + player + ' ["",{"text":"[💀 阵亡守护] ","color":"dark_red","bold":true},{"text":"您于 ' + deathTime + ' 不幸阵亡！死因: ' + (deathReason || '未知') + '。","color":"gray"}]');
            scroll.sendCommand('tellraw ' + player + ' ["",{"text":"[💀 阵亡守护] ","color":"dark_red","bold":true},{"text":"提示: 可按 F3 确认回程方向，请尽快前往遗址拾取掉落物！","color":"gold"}]');
        }

        if (scroll.config.actionBarTip) {
            scroll.sendActionBar(player, '§c💀 阵亡记录已生成 (' + deathTime + ')');
        }
    });

    scroll.logger.info('阵亡坐标私信守护卷轴已就绪');

    return {
        destroy: async () => {
            scroll.logger.info('阵亡坐标私信守护卷轴已注销');
        }
    };
};
