/**
 * 卷轴：单人快速跳过夜晚 (Fast Sleep) v1.1.0
 * 
 * 核心机制：
 * 1. 原生规则下发 (Minecraft 1.17+)：自动执行 /gamerule playersSleepingPercentage 1，
 *    原版引擎在 1 名玩家入睡时即可原生平滑跳夜；
 * 2. 聊天指令交互 (全版本通用)：玩家输入 !sleep、!day、睡觉、晚安 时触发倒计时并执行切换；
 * 3. 日志与进度拦截：捕获 [Sweet Dreams] 进度、躺床日志并广播提示；
 * 4. 退出自动还原：卷轴注销时恢复 /gamerule playersSleepingPercentage 100。
 */
module.exports = async function(scroll) {
    let isSkipping = false;

    // 1. 下发 Minecraft 1.17+ 原生单人睡觉规则
    const applyGamerule = () => {
        if (scroll.config.enableNativeGamerule !== false) {
            scroll.sendCommand('gamerule playersSleepingPercentage 1');
            scroll.logger.info('已应用原生单人跳夜规则: /gamerule playersSleepingPercentage 1');
        }
    };

    // 启动及服务器就绪时立即下发
    applyGamerule();
    scroll.onServerStart(() => {
        applyGamerule();
    });

    // 触发执行跳夜操作
    const triggerSkipNight = async (triggerSource, playerName) => {
        if (isSkipping) return;
        isSkipping = true;

        const countdown = Math.max(0, Math.min(10, Number(scroll.config.countdownSec ?? 3)));
        const who = playerName ? ('玩家 §b' + playerName + '§e ') : '';

        if (triggerSource === 'sleep') {
            scroll.broadcast('§6[晨曦微光] §e' + who + '已经入睡，将于 §c' + countdown + '秒 §e后迎来黎明...');
        } else if (triggerSource === 'chat') {
            scroll.broadcast('§6[晨曦微光] §e' + who + '请求迎来白昼，将于 §c' + countdown + '秒 §e后迎来黎明...');
        } else {
            scroll.broadcast('§6[晨曦微光] §e黎明即将来临，将于 §c' + countdown + '秒 §e后破晓...');
        }

        if (countdown > 1) {
            await scroll.sleep((countdown - 1) * 1000);
        }

        scroll.sendCommand('time set day');
        scroll.sendCommand('weather clear');

        if (scroll.config.announceTitle !== false) {
            scroll.sendCommand('title @a times 10 40 10');
            scroll.sendCommand('title @a subtitle {"text":"祝您今天冒险愉快！","color":"yellow"}');
            scroll.sendCommand('title @a title {"text":"☀ 旭日初升 ☀","color":"gold","bold":true}');
            scroll.sendCommand('playsound entity.player.levelup master @a');
        }

        scroll.broadcast('§a[晨曦微光] ☀ 天空破晓，新的一天开始了！');

        setTimeout(() => {
            isSkipping = false;
        }, 8000);
    };

    // 2. 监听玩家聊天指令 (!sleep, !day, 睡觉, 晚安)
    scroll.onChat(async ({ player, message }) => {
        if (scroll.config.enableChatCommand === false) return;
        const msg = (message || '').trim();
        if (/^(!sleep|!day|睡觉|晚安|跳过夜晚|skipnight)$/i.test(msg)) {
            if (isSkipping) {
                if (scroll.sendMessage) {
                    await scroll.sendMessage(player, '§e[晨曦微光] 正在迎来白昼，请稍候...');
                }
                return;
            }
            await triggerSkipNight('chat', player);
        }
    });

    // 3. 监听控制台日志（进度与入睡日志）
    scroll.onLog(async (event) => {
        const raw = (event && (event.raw || event.line)) || '';
        if (!raw || isSkipping) return;

        // 匹配各类入睡日志
        const sleepMatch = raw.match(/([a-zA-Z0-9_.-]+)\s+(?:is now sleeping|went to bed|躺上了床|入睡了)/i);
        if (sleepMatch) {
            await triggerSkipNight('sleep', sleepMatch[1]);
            return;
        }

        // 匹配原版入睡进度成就 Sweet Dreams
        const advMatch = raw.match(/([a-zA-Z0-9_.-]+)\s+(?:has made the advancement|完成了进度)\s*\[(?:Sweet Dreams|甜蜜的梦)\]/i);
        if (advMatch) {
            await triggerSkipNight('sleep', advMatch[1]);
        }
    });

    scroll.logger.info('单人快速跳过夜晚卷轴 (v1.1.0) 已就绪');

    return {
        destroy: async () => {
            isSkipping = false;
            if (scroll.config.enableNativeGamerule !== false) {
                scroll.sendCommand('gamerule playersSleepingPercentage 100');
            }
            scroll.logger.info('单人快速跳过夜晚卷轴已注销并恢复默认规则');
        }
    };
};
