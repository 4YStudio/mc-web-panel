/**
 * 卷轴：单人快速跳过夜晚 (Fast Sleep) v1.3.0
 * 
 * 核心机制：
 * 1. 原生规则单次静默下发 (Minecraft 1.17+)：
 *    - 仅在服务端处于运行中（已在运行或启动就绪）时执行一次；
 *    - 执行前自动静默客户端指令回显 (/gamerule sendCommandFeedback false)，杜绝客户端聊天栏刷屏；
 *    - 下发 /gamerule playersSleepingPercentage 1，Minecraft 原生引擎在 1 名玩家入睡时自动平滑跳夜；
 *    - 彻底移除定时轮询与进服重复下发，不再打扰服主与玩家；
 * 2. 聊天指令交互 (全版本通用)：
 *    - 玩家输入 !sleep, !day, /sleep, 睡觉, 晚安, 早安, 跳过夜晚, 天亮 等均可触发切换；
 * 3. 进阶日志与成就捕获：
 *    - 仅在玩家实际入睡时捕获日志或成就，并触发跳夜与破晓通知；
 * 4. 退出自动还原：
 *    - 卷轴卸载时恢复 /gamerule playersSleepingPercentage 100。
 */
module.exports = async function(scroll) {
    let isSkipping = false;
    let ruleApplied = false;

    // 保证 gamerule playersSleepingPercentage 1 生效（静默下发，仅执行一次）
    const applyGamerule = (reason = '') => {
        if (ruleApplied) return true;
        if (scroll.config.enableNativeGamerule !== false) {
            // 先确保关闭指令在客户端的回显，避免客户端弹出 [Server: ...]
            scroll.sendCommand('gamerule sendCommandFeedback false');
            const ok = scroll.sendCommand('gamerule playersSleepingPercentage 1');
            if (ok) {
                ruleApplied = true;
                scroll.logger.info(`[单人跳夜] 已应用原生单人跳夜规则: /gamerule playersSleepingPercentage 1 ${reason ? '(' + reason + ')' : ''}`);
            }
            return ok;
        }
        return false;
    };

    // 1. 如果服务器当前已经在运行中，立即执行一次
    if (typeof scroll.isServerRunning === 'function' && scroll.isServerRunning()) {
        applyGamerule('服务器当前运行中');
    }

    // 2. 监听服务端就绪事件（仅在每次开服完成时执行一次）
    if (typeof scroll.onServerStart === 'function') {
        scroll.onServerStart(async () => {
            await scroll.sleep(1500);
            ruleApplied = false; // 开服后允许执行一次
            applyGamerule('服务端启动完成');
        });
    }

    // 服务端停止时重置标记
    if (typeof scroll.onServerStop === 'function') {
        scroll.onServerStop(() => {
            ruleApplied = false;
        });
    }

    // 触发执行跳夜操作
    const triggerSkipNight = async (triggerSource, playerName) => {
        if (isSkipping) return;
        isSkipping = true;

        const countdown = Math.max(0, Math.min(10, Number(scroll.config.countdownSec ?? 3)));
        const who = playerName ? ('玩家 §b' + playerName + '§e ') : '';

        scroll.logger.info(`触发跳过夜晚流程 (来源: ${triggerSource}${playerName ? ', 玩家: ' + playerName : ''})`);

        if (triggerSource === 'sleep') {
            scroll.broadcast('§6[晨曦微光] §e' + who + '已经入睡，将于 §c' + countdown + '秒 §e后迎来黎明...');
        } else if (triggerSource === 'chat') {
            scroll.broadcast('§6[晨曦微光] §e' + who + '请求迎来白昼，将于 §c' + countdown + '秒 §e后迎来黎明...');
        } else {
            scroll.broadcast('§6[晨曦微光] §e黎明即将来临，将于 §c' + countdown + '秒 §e后破晓...');
        }

        if (countdown > 0) {
            await scroll.sleep(countdown * 1000);
        }

        // 保持静默，切换时间与天气不向客户端产生 [Server: ...]
        scroll.sendCommand('gamerule sendCommandFeedback false');
        scroll.sendCommand('time set day');
        scroll.sendCommand('weather clear');

        if (scroll.config.announceTitle !== false) {
            scroll.sendCommand('title @a times 10 40 10');
            scroll.sendCommand('title @a subtitle {"text":"祝您今天冒险愉快！","color":"yellow"}');
            scroll.sendCommand('title @a title {"text":"☀ 旭日初升 ☀","color":"gold","bold":true}');
            scroll.sendCommand('playsound entity.player.levelup master @a');
        }

        scroll.broadcast('§a[晨曦微光] ☀ 天空破晓，新的一天开始了！');
        scroll.logger.info('已成功执行昼夜与天气切换 (time set day, weather clear)');

        setTimeout(() => {
            isSkipping = false;
        }, 8000);
    };

    // 监听玩家聊天指令
    scroll.onChat(async ({ player, message }) => {
        if (scroll.config.enableChatCommand === false) return;
        const msg = (message || '').trim();
        if (/^(!sleep|!day|\/sleep|睡觉|晚安|早安|跳过夜晚|天亮|白天|起床|skipnight)$/i.test(msg) ||
            /(睡觉|晚安|早安|天亮|跳过夜晚)/.test(msg)) {
            if (isSkipping) {
                if (scroll.sendMessage) {
                    await scroll.sendMessage(player, '§e[晨曦微光] 正在迎来白昼，请稍候...');
                }
                return;
            }
            await triggerSkipNight('chat', player);
        }
    });

    // 监听控制台日志（进度与入睡日志）
    scroll.onLog(async (event) => {
        const raw = (event && (event.raw || event.line)) || '';
        if (!raw || isSkipping) return;

        // 匹配各种入睡日志
        const sleepMatch = raw.match(/([a-zA-Z0-9_.-]+)\s+(?:is now sleeping|went to bed|躺上了床|入睡了)/i);
        if (sleepMatch) {
            await triggerSkipNight('sleep', sleepMatch[1]);
            return;
        }

        // 捕获 Sweet Dreams 进度
        if (raw.includes('Sweet Dreams') || raw.includes('甜蜜的梦') || raw.includes('sweet_dreams')) {
            const playerMatch = raw.match(/([a-zA-Z0-9_.-]+)\s+(?:has made the advancement|完成了进度)/i);
            const pName = playerMatch ? playerMatch[1] : null;
            await triggerSkipNight('advancement', pName);
        }
    });

    scroll.logger.info('单人快速跳过夜晚卷轴 (v1.3.0) 已就绪');

    return {
        destroy: async () => {
            if (scroll.config.enableNativeGamerule !== false) {
                scroll.sendCommand('gamerule sendCommandFeedback false');
                scroll.sendCommand('gamerule playersSleepingPercentage 100');
                scroll.logger.info('[单人跳夜] 卷轴已停用，已恢复原版规则: /gamerule playersSleepingPercentage 100');
            }
        }
    };
};
