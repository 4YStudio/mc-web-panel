/**
 * 卷轴：单人快速跳过夜晚 (Fast Sleep)
 */
module.exports = async function(scroll) {
    let isSkipping = false;

    scroll.onLog(async ({ raw }) => {
        if (isSkipping) return;

        const sleepMatch = raw.match(/([A-Za-z0-9_]+) (?:is now sleeping|went to bed|躺上了床)/i);
        if (sleepMatch) {
            const player = sleepMatch[1];
            isSkipping = true;
            const countdown = Number(scroll.config.countdownSec || 3);

            scroll.broadcast('§6[晨曦微光] §e玩家 §b' + player + ' §e已经入睡，将于 §c' + countdown + '秒 §e后迎来黎明...');
            
            if (countdown > 1) {
                await scroll.sleep((countdown - 1) * 1000);
            }

            scroll.sendCommand('time set day');
            scroll.sendCommand('weather clear');

            if (scroll.config.announceTitle) {
                scroll.sendCommand('title @a times 10 40 10');
                scroll.sendCommand('title @a subtitle {"text":"祝您今天冒险愉快！","color":"yellow"}');
                scroll.sendCommand('title @a title {"text":"☀ 旭日初升 ☀","color":"gold","bold":true}');
            }

            scroll.broadcast('§a[晨曦微光] ☀ 天空破晓，新的一天开始了！');

            setTimeout(() => {
                isSkipping = false;
            }, 10000);
        }
    });

    scroll.logger.info('单人快速跳过夜晚卷轴已启动就绪');

    return {
        destroy: async () => {
            isSkipping = false;
            scroll.logger.info('单人快速跳过夜晚卷轴已注销');
        }
    };
};
