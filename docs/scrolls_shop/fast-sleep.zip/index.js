/**
 * 卷轴：单人快速跳过夜晚 (Fast Sleep) v2.4.0
 * 
 * 核心交互机制：
 * 1. 零轮询、零性能消耗的原生躺床事件侦测 (Zero-Polling Event Detector)：
 *    - 自动为当前实例世界部署轻量级原生事件数据包 (fast_sleep)；
 *    - 当任意玩家右键躺上床时，由原版 Advancement 机制瞬间触发 say 广播事件；
 *    - 彻底杜绝使用定时器高频下发命令轮询，0 控制台垃圾命令回显，0 客户端躺床抽搐抖动；
 * 2. 全服沉浸式富文本交互 (Interactive Tellraw Buttons & Broadcast)：
 *    - 玩家躺床或在聊天栏输入 !sleep / 睡觉 时，全服广播详尽的黎明破晓通知；
 *    - 附带双彩色交互按钮：[✔ 我也入睡 (加速黎明)] 与 [✖ 我要熬夜 (否决跳夜)]；
 * 3. 全服 ActionBar 破晓倒计时与钟声音效 (ActionBar & Note Block Bells)：
 *    - 破晓倒计时期间，在全服玩家屏幕下方实时跳动进度槽与剩余秒数，伴随清脆钟声音效；
 *    - 其他玩家点击 [✔ 我也入睡] 或聊天回复 !sleep 可加速黎明到来；
 * 4. 熬夜否决机制 (Veto / Anti-Skip)：
 *    - 正在野外刷怪或需要黑夜的玩家点击 [✖ 我要熬夜] 或输入 !nosleep / 熬夜 可瞬间中止跳夜或紧急拉回黑夜；
 * 5. 群星流转平滑拂晓动效与清晨活力增益 (Timelapse & Morning Buffs)：
 *    - 倒计时结束时平滑步进时间，呈现斗转星移、旭日东升的视觉效果；
 *    - 全屏金色大标题“☀ 旭日初升 ☀”并播放升级音效，自动驱散暴风雨，早睡玩家获得 30 秒清晨速度与饱腹活力。
 */

const fs = require('fs');
const path = require('path');

module.exports = async function(scroll) {
    let isSkipping = false;
    let vetoed = false;
    let vetoPlayer = null;
    let lastSkipTime = 0;
    let supporters = new Set();
    let currentCountdown = 0;

    // 确保当前实例的数据包环境就绪（用于零轮询、零开销捕获玩家入睡动作）
    const ensureDatapack = () => {
        try {
            const instanceDir = path.join(process.cwd(), 'instances', scroll.instanceId || 'default');
            const dpDir = path.join(instanceDir, 'world', 'datapacks', 'fast_sleep');
            const packMeta = path.join(dpDir, 'pack.mcmeta');
            const advFile = path.join(dpDir, 'data', 'fast_sleep', 'advancements', 'sleep.json');
            const funcFile = path.join(dpDir, 'data', 'fast_sleep', 'functions', 'on_sleep.mcfunction');

            fs.mkdirSync(path.dirname(advFile), { recursive: true });
            fs.mkdirSync(path.dirname(funcFile), { recursive: true });

            fs.writeFileSync(packMeta, JSON.stringify({
                pack: {
                    pack_format: 15,
                    supported_formats: { min_inclusive: 10, max_inclusive: 65 },
                    description: 'Fast Sleep Event Detector by 4YStudio'
                }
            }, null, 2), 'utf8');

            fs.writeFileSync(advFile, JSON.stringify({
                criteria: {
                    slept: { trigger: 'minecraft:slept_in_bed' }
                },
                rewards: {
                    function: 'fast_sleep:on_sleep'
                }
            }, null, 2), 'utf8');

            fs.writeFileSync(funcFile, 'advancement revoke @s only fast_sleep:sleep\nsay 🌅 [晨曦微光] 玩家躺上了床，准备迎来黎明！\n', 'utf8');

            scroll.logger.info('已就绪原生入睡事件捕获数据包 (fast_sleep)');
        } catch (e) {
            scroll.logger.warn('部署 fast_sleep 数据包失败:', e.message);
        }
    };

    // 初始化环境与规则
    const initEnvironment = () => {
        if (typeof scroll.isServerRunning === 'function' && !scroll.isServerRunning()) return;

        ensureDatapack();

        // 静默指令回显，避免游戏内聊天栏弹出 [Server: ...]
        scroll.sendCommand('gamerule sendCommandFeedback false');

        // 清理旧版残留的 fs_sleep 记分板
        scroll.sendCommand('scoreboard objectives remove fs_sleep');

        // 设置玩家入睡百分比为 100（由卷轴全面接管倒计时、投票、否决与动画仪式）
        scroll.sendCommand('gamerule playersSleepingPercentage 100');

        // 重新加载数据包使函数最新定义生效
        scroll.sendCommand('reload');

        scroll.logger.info('单人跳夜交互系统初始化完毕');
    };

    // 服务端就绪或启动时自动应用
    if (typeof scroll.isServerRunning === 'function' && scroll.isServerRunning()) {
        initEnvironment();
    }
    if (typeof scroll.onServerStart === 'function') {
        scroll.onServerStart(async () => {
            await scroll.sleep(2500);
            initEnvironment();
        });
    }

    // 触发跳夜仪式核心流程
    const triggerSkipNight = async (triggerSource, playerName) => {
        const now = Date.now();
        if (isSkipping) return;
        
        // 防高频抖动：跳夜后 8 秒冷却
        if (now - lastSkipTime < 8000) {
            if (triggerSource === 'chat' && playerName) {
                scroll.sendMessage(playerName, '§e[晨曦微光] 刚刚迎来清晨，请稍事休息后再发起跳夜。');
            }
            return;
        }

        isSkipping = true;
        vetoed = false;
        vetoPlayer = null;
        supporters.clear();
        if (playerName) supporters.add(playerName);

        const config = scroll.config || {};
        const sleepMode = config.sleepMode || 'timelapse';
        const totalCountdown = Math.max(0, Math.min(10, Number(config.countdownSec ?? 3)));
        const allowVeto = config.allowVeto !== false;
        const enableClickable = config.enableClickableChat !== false;
        const enableActionBar = config.enableActionBar !== false;
        const whoText = playerName ? `§b${playerName}§e` : '有玩家';

        scroll.logger.info(`触发跳夜仪式 (来源: ${triggerSource}, 玩家: ${playerName || '未知'}, 模式: ${sleepMode})`);

        // A. 广播跳夜通知与彩色可点击互动按钮
        if (enableClickable) {
            const rawJson = JSON.stringify([
                { text: '🌅 ', color: 'gold' },
                { text: '[晨曦微光] ', color: 'gold', bold: true },
                { text: '玩家 ', color: 'yellow' },
                { text: playerName || '有人', color: 'aqua', bold: true },
                { text: triggerSource === 'bed' ? ' 已经躺在床上，邀请大家迎接黎明！\n' : ' 发起了迎接黎明请求！\n', color: 'yellow' },
                { text: '  ▶ ', color: 'gold' },
                {
                    text: '[✔ 我也入睡 (加速黎明)]',
                    color: 'green',
                    bold: true,
                    clickEvent: { action: 'run_command', value: '!sleep' },
                    hoverEvent: { action: 'show_text', contents: { text: '点击响应入睡，每多一人响应倒计时缩短 1 秒！', color: 'green' } }
                },
                { text: '    ' },
                allowVeto ? {
                    text: '[✖ 我要熬夜 (否决跳夜)]',
                    color: 'red',
                    bold: true,
                    clickEvent: { action: 'run_command', value: '!nosleep' },
                    hoverEvent: { action: 'show_text', contents: { text: '点击否决跳夜（若您正在野外刷怪或需要黑夜环境）', color: 'red' } }
                } : { text: '' },
                { text: '\n  💡 提示: 在聊天框输入 !sleep 或 !nosleep 亦可直接参与互动', color: 'gray', italic: true }
            ]);
            scroll.sendCommand(`tellraw @a ${rawJson}`);
        } else {
            const vetoTip = allowVeto ? ' (聊天栏发送 !nosleep 可否决)' : '';
            scroll.broadcast(`§6[晨曦微光] §e${whoText} 准备迎来黎明，将于 §c${totalCountdown}秒 §e后破晓...${vetoTip}`);
        }

        // B. 倒计时流程与屏幕下方 ActionBar 进度展示
        if (totalCountdown > 0 && sleepMode !== 'instant') {
            currentCountdown = totalCountdown;
            while (currentCountdown > 0) {
                if (vetoed) break;

                // 破晓音效（清脆钟声）
                scroll.sendCommand('playsound block.note_block.chime master @a ~ ~ ~ 0.8 1.4');

                // 渲染 ActionBar 进度条
                if (enableActionBar) {
                    const progressBars = 10;
                    const filled = Math.round(((totalCountdown - currentCountdown) / totalCountdown) * progressBars);
                    const barStr = '█'.repeat(filled) + '░'.repeat(progressBars - filled);
                    const actionJson = JSON.stringify({
                        text: `🌅 黎明破晓中: ${currentCountdown}秒... [${barStr}]`,
                        color: 'gold',
                        bold: true
                    });
                    scroll.sendCommand(`title @a actionbar ${actionJson}`);
                }

                await scroll.sleep(1000);
                if (vetoed) break;
                currentCountdown--;
            }
        }

        // C. 处理被否决情况
        if (vetoed) {
            scroll.logger.info(`跳夜流程被否决 (否决者: ${vetoPlayer || '未知'})`);
            scroll.sendCommand('playsound block.note_block.bass master @a ~ ~ ~ 1.0 0.8');
            if (enableActionBar) {
                const vetoAction = JSON.stringify({
                    text: `🌙 玩家 ${vetoPlayer || ''} 否决了跳夜，漫漫长夜仍在继续...`,
                    color: 'red',
                    bold: true
                });
                scroll.sendCommand(`title @a actionbar ${vetoAction}`);
            }
            scroll.broadcast(`§c[🌙 晨曦微光] 玩家 §b${vetoPlayer || '某位冒险者'}§c 请求熬夜，跳过夜晚已取消！`);
            isSkipping = false;
            vetoed = false;
            lastSkipTime = Date.now();
            return;
        }

        // D. 执行破晓与昼夜切换
        scroll.sendCommand('gamerule sendCommandFeedback false');

        if (sleepMode === 'timelapse') {
            // 群星流转模式：平滑时间步进，呈现斗转星移、旭日东升的视觉奇观
            scroll.broadcast('§6[🌅 晨曦微光] 晨光熹微，斗转星移，黎明降临！');
            const steps = 18;
            for (let i = 0; i < steps; i++) {
                scroll.sendCommand('time add 450');
                await scroll.sleep(60);
            }
            scroll.sendCommand('time set 1000');
        } else {
            // 经典与即时模式
            scroll.sendCommand('time set day');
        }

        // 清理恶劣雷暴雨天气
        if (config.clearWeather !== false) {
            scroll.sendCommand('weather clear');
        }

        // E. 破晓全屏大标题与升级音效
        if (config.announceTitle !== false) {
            scroll.sendCommand('title @a times 10 40 10');
            scroll.sendCommand('title @a subtitle {"text":"新的一天开始了，愿你冒险平安！","color":"yellow"}');
            scroll.sendCommand('title @a title {"text":"☀ 旭日初升 ☀","color":"gold","bold":true}');
            scroll.sendCommand('playsound entity.player.levelup master @a ~ ~ ~ 1.0 1.0');
        }

        // F. 早起勤劳鸟儿的“清晨祝福” Buff（速度与饱腹）
        if (config.morningBuff !== false && supporters.size > 0) {
            for (const p of supporters) {
                if (!p) continue;
                scroll.sendCommand(`effect give ${p} minecraft:speed 30 0 true`);
                scroll.sendCommand(`effect give ${p} minecraft:saturation 10 0 true`);
                scroll.sendMessage(p, '§6[☕ 清晨祝福] §e昨夜好梦！早睡早起的你获得了 30 秒清晨活力与饱腹效果。');
            }
        }

        scroll.broadcast('§a[晨曦微光] ☀ 天空破晓，新的一天开始了！');
        scroll.logger.info('已成功迎来黎明与晴空！');

        lastSkipTime = Date.now();
        setTimeout(() => {
            isSkipping = false;
            vetoed = false;
        }, 4000);
    };

    // 监听玩家聊天指令
    scroll.onChat(async ({ player, message }) => {
        if (scroll.config?.enableChatCommand === false) return;
        const msg = (message || '').trim().toLowerCase();

        // 否决/熬夜指令
        const isVeto = /^(!nosleep|!night|!cancel|熬夜|别睡|取消|我要刷怪|不睡|不要睡|不想睡)$/i.test(msg) ||
                       /(熬夜|别睡觉|不要睡觉|不想睡觉|我还要刷怪)/.test(msg);
        if (isVeto) {
            if (isSkipping && !vetoed) {
                if (scroll.config?.allowVeto === false) {
                    scroll.sendMessage(player, '§c[晨曦微光] 当前服务器已禁用熬夜否决机制。');
                    return;
                }
                vetoed = true;
                vetoPlayer = player;
                scroll.logger.info(`玩家 ${player} 通过聊天指令否决跳夜`);
            } else if (Date.now() - lastSkipTime < 10000) {
                // 如果刚刚跳完白天 10 秒内，支持紧急拉回黑夜
                scroll.sendCommand('time set 14000');
                scroll.broadcast(`§c[🌙 晨曦微光] 玩家 §b${player}§c 开启了熬夜模式，已将时间拉回黑夜！`);
                scroll.sendCommand('playsound block.note_block.bass master @a ~ ~ ~ 1.0 0.8');
            } else {
                scroll.sendMessage(player, '§7[晨曦微光] 当前没有正在进行的跳夜流程。');
            }
            return;
        }

        // 跳夜/入睡指令
        const isSleep = /^(!sleep|!day|!skip|\/sleep|睡觉|晚安|早安|跳过夜晚|天亮|白天|起床|skipnight)$/i.test(msg) ||
                        /^(来人睡觉|快睡觉|大家睡觉|求睡觉)$/.test(msg);
        if (isSleep) {
            if (isSkipping) {
                if (!supporters.has(player)) {
                    supporters.add(player);
                    scroll.broadcast(`§a[晨曦微光] 玩家 §b${player}§a 也响应了入睡，黎明加速！`);
                    // 每有一名新玩家响应，倒计时减 1 秒
                    if (currentCountdown > 1) {
                        currentCountdown--;
                    }
                } else {
                    scroll.sendMessage(player, '§e[晨曦微光] 你已在响应列表中，黎明即将来临...');
                }
                return;
            }
            await triggerSkipNight('chat', player);
            return;
        }

        // 帮助指令
        if (/^(!sleep\s*help|跳夜帮助)$/i.test(msg)) {
            scroll.sendMessage(player, '§6=== [晨曦微光 快速跳夜帮助] ===\n§e!sleep / 睡觉: 发起或赞成跳夜\n§e!nosleep / 熬夜: 否决本次跳夜或拉回黑夜\n§e点击聊天栏中的彩色按钮亦可直接交互！');
        }
    });

    // 事件驱动型日志监听
    scroll.onLog(async (event) => {
        const raw = (event && (event.raw || event.line)) || '';
        if (!raw || isSkipping) return;

        // 清理服务端时间戳与日志通道前缀: [01:14:29] [Server thread/INFO]: 
        const clean = raw.replace(/^\[\d{2}:\d{2}:\d{2}\]\s*\[.*?\]:\s*/, '');

        // 1. 捕获 Fast Sleep 原生躺床广播事件 (兼容 [Not Secure]、各类包装括号与纯文本)
        if (clean.includes('晨曦微光')) {
            const m = clean.match(/(?:\[Not Secure\]\s*)?[<\[]([a-zA-Z0-9_.-]+)(?::|[>\]]).*?晨曦微光/);
            const pName = m ? m[1] : null;
            await triggerSkipNight('bed', pName);
            return;
        }

        // 兼容私聊标识
        if (raw.includes('[FS_BED_ENTER]')) {
            const pMatch = clean.match(/(?:\[Not Secure\]\s*)?[<\[]([a-zA-Z0-9_.-]+)/i);
            const pName = pMatch ? pMatch[1] : null;
            await triggerSkipNight('bed', pName);
            return;
        }

        // 2. 捕获主流 Mod 与核心的入睡日志（Fabric/Paper/Spigot/Vanilla）
        const sleepMatch = clean.match(/([a-zA-Z0-9_.-]+)\s+(?:is now sleeping|went to bed|躺上了床|入睡了)/i);
        if (sleepMatch) {
            await triggerSkipNight('mod', sleepMatch[1]);
            return;
        }

        // 3. 捕获 Sweet Dreams（甜蜜的梦）成就
        if (raw.includes('Sweet Dreams') || raw.includes('甜蜜的梦') || raw.includes('sweet_dreams')) {
            const playerMatch = clean.match(/([a-zA-Z0-9_.-]+)\s+(?:has made the advancement|完成了进度)/i);
            const pName = playerMatch ? playerMatch[1] : null;
            await triggerSkipNight('advancement', pName);
        }
    });

    scroll.logger.info('单人快速跳过夜晚卷轴 (Fast Sleep v2.4.0) 交互系统已就绪');

    return {
        destroy: async () => {
            if (typeof scroll.isServerRunning === 'function' && scroll.isServerRunning()) {
                scroll.sendCommand('gamerule playersSleepingPercentage 100');
                scroll.sendCommand('scoreboard objectives remove fs_sleep');
            }
            scroll.logger.info('[单人跳夜] 卷轴已注销');
        }
    };
};
