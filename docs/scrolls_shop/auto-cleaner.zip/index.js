/**
 * 智能扫地姬卷轴 (Auto Cleaner Scroll)
 * 定时广播倒计时预警并清理掉落物
 */
module.exports = async function(scroll) {
    const minutes = Math.max(1, Number(scroll.config.intervalMinutes) || 30);
    const intervalMs = minutes * 60 * 1000;

    scroll.schedule(intervalMs, async (instanceId) => {
        const warnSec = Math.max(5, Number(scroll.config.warningSeconds) || 60);

        // 1. 提前预警广播
        const warnText = (scroll.config.warningMessage || '§c[扫地姬] 地面掉落物将在 {sec} 秒后清理！')
            .replace(/\{sec\}/g, warnSec);
        await scroll.broadcast(warnText, instanceId);

        // 2. 10 秒临近提醒
        if (warnSec > 15) {
            await scroll.sleep((warnSec - 10) * 1000);
            await scroll.broadcast('§e[扫地姬] 10 秒后即将清除地面掉落物...', instanceId);
            await scroll.sleep(10 * 1000);
        } else {
            await scroll.sleep(warnSec * 1000);
        }

        // 3. 执行清除掉落物指令
        await scroll.sendCommand('kill @e[type=item]', instanceId);

        // 4. 清理完成广播
        const doneText = scroll.config.doneMessage || '§a[扫地姬] 地面掉落物已清理完毕！';
        await scroll.broadcast(doneText, instanceId);

        scroll.logger.info(`[${instanceId}] 扫地姬执行完毕`);
    });
};
