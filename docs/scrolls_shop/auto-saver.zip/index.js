/**
 * 卷轴：自动安全存档守护 (Auto Saver & World Guard)
 */
module.exports = async function(scroll) {
    let lastSaveTime = scroll.storage.get('lastSaveTime', 0);
    let totalSaves = scroll.storage.get('totalSaves', 0);
    let isSaving = false;
    let onlineCount = 0;

    const performSave = async (reason = '定时保存') => {
        if (isSaving) return;
        isSaving = true;

        try {
            const flush = scroll.config.flushDisk !== false;
            const cmd = flush ? 'save-all flush' : 'save-all';
            scroll.sendCommand(cmd);

            lastSaveTime = Date.now();
            totalSaves++;
            scroll.storage.set('lastSaveTime', lastSaveTime);
            scroll.storage.set('totalSaves', totalSaves);

            const mode = scroll.config.notifyMode || 'actionbar';
            const msg = scroll.config.notifyMessage || '§a[安全守护] §f服务器世界数据已安全保存并刷盘。';

            if (mode === 'actionbar') {
                await scroll.sendActionBar('@a', msg);
            } else if (mode === 'chat') {
                await scroll.broadcast(msg);
            }
            scroll.logger.info('[' + reason + '] 世界安全存档已执行 (' + cmd + ')，历史累计存档 ' + totalSaves + ' 次');
        } finally {
            isSaving = false;
        }
    };

    // 1. 定时任务
    let intervalMinutes = Number(scroll.config.intervalMinutes) || 15;
    if (intervalMinutes < 1) intervalMinutes = 1;
    scroll.schedule(intervalMinutes * 60 * 1000, async () => {
        await performSave('定时保存');
    });

    // 2. 服务端启动初始化保存
    if (scroll.config.saveOnStart !== false) {
        scroll.onServerStart(async () => {
            await scroll.sleep(15000);
            await performSave('服务器就绪初始化');
        });
    }

    // 3. 人数追踪与全员离线安全存档
    scroll.onPlayerJoin(() => {
        onlineCount++;
    });

    scroll.onPlayerQuit(async () => {
        onlineCount = Math.max(0, onlineCount - 1);
        if (onlineCount === 0 && scroll.config.saveOnEmpty !== false) {
            await scroll.sleep(2000);
            if (onlineCount === 0) {
                await performSave('全员离线安全落锁');
            }
        }
    });

    // 4. 聊天指令 !save
    let lastCommandTrigger = 0;
    scroll.onChat(async ({ player, message }) => {
        if (scroll.config.enableChatCommand === false) return;
        const text = (message || '').trim().toLowerCase();
        if (text === '!save' || text === '保存' || text === '!保存') {
            const now = Date.now();
            if (now - lastCommandTrigger < 30000) {
                const waitSec = Math.ceil((30000 - (now - lastCommandTrigger)) / 1000);
                await scroll.sendMessage(player, '§e[安全守护] §f上次存档于不久前完成，请等待 §c' + waitSec + '秒 §f后再试。');
                return;
            }
            lastCommandTrigger = now;
            await scroll.sendMessage(player, '§e[安全守护] §f正在为您手动执行世界与玩家数据刷盘...');
            await performSave('玩家 ' + player + ' 触发');
            await scroll.sendMessage(player, '§a[安全守护] §f存档成功！世界数据已安全刷入物理磁盘。');
            await scroll.playSound(player, 'entity.experience_orb.pickup');
        }
    });

    scroll.logger.info('自动安全存档守护已启用，保存周期: 每 ' + intervalMinutes + ' 分钟，历史保存: ' + totalSaves + ' 次');
};
