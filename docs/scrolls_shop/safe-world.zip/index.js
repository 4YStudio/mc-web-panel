/**
 * 卷轴：世界安全与防爆守护 (Safe World & Anti-Grief)
 */
module.exports = async function(scroll) {
    const applyProtectionRules = () => {
        if (scroll.config.disableMobGriefing !== false) {
            scroll.sendCommand('gamerule mobGriefing false');
            scroll.logger.info('已应用生物防爆保护: /gamerule mobGriefing false');
        }
        if (scroll.config.disableFireSpread !== false) {
            scroll.sendCommand('gamerule doFireTick false');
            scroll.logger.info('已应用火焰防蔓延保护: /gamerule doFireTick false');
        }
    };

    // 启动与就绪时自动应用
    applyProtectionRules();
    scroll.onServerStart(() => {
        applyProtectionRules();
    });

    // 1. 监控日志中的异常爆炸或 TNT
    if (scroll.config.logExplosions !== false) {
        scroll.onLog(({ line }) => {
            if (!line) return;
            if (line.includes('TNT') || line.includes('primed_tnt') || line.includes('Wither') || line.includes('凋灵')) {
                scroll.logger.warn('[安全预警] 检测到爆炸/高危实体活动日志: ' + line.trim());
            }
        });
    }

    // 2. 进服安全温馨提示
    scroll.onPlayerJoin(async ({ player }) => {
        if (scroll.config.announceProtection !== false) {
            await scroll.sleep(4000);
            if (player) {
                await scroll.sendMessage(player, '§a[安全守护] §7当前世界已启用生物防爆与防火蔓延保护，请放心建造！');
            }
        }
    });

    // 3. 聊天指令 !safe
    scroll.onChat(async ({ player, message }) => {
        if (scroll.config.enableChatCommand === false) return;
        const text = (message || '').trim().toLowerCase();
        if (text === '!safe' || text === '!防爆' || text === '!protect' || text === '!anquan') {
            const mobGriefing = scroll.config.disableMobGriefing !== false ? '§a已启用 (方块安全)' : '§c已关闭';
            const fireSpread = scroll.config.disableFireSpread !== false ? '§a已禁止 (防火灾)' : '§c允许蔓延';

            await scroll.sendMessage(player, '§6==== §e世界安全与防爆防护状态 §6====');
            await scroll.sendMessage(player, '- 苦力怕/末影人防爆 (mobGriefing): ' + mobGriefing);
            await scroll.sendMessage(player, '- 火焰蔓延防护 (doFireTick): ' + fireSpread);
            await scroll.sendMessage(player, '- 状态: §b所有方块均受保护，放心开荒');
            await scroll.sendMessage(player, '§6================================');
            await scroll.playSound(player, 'entity.experience_orb.pickup');
        }
    });

    scroll.logger.info('世界安全与防爆守护已就绪');
};
