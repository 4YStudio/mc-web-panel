/**
 * 新手迎宾卷轴 (Welcome Scroll)
 * 监听玩家加入事件，展示全屏大标题与聊天公告
 */
module.exports = async function(scroll) {
    scroll.onPlayerJoin(async ({ instanceId, player }) => {
        const title = scroll.config.title || '欢迎来到服务器！';
        const subtitle = scroll.config.subtitle || '';
        const color = scroll.config.color || 'gold';

        // 1. 发送屏幕中央大标题 (Title)
        await scroll.sendTitle(player, {
            title: title,
            subtitle: subtitle,
            color: color,
            fadeIn: 10,
            stay: 60,
            fadeOut: 20
        }, instanceId);

        // 2. 发送聊天栏全服广播
        if (scroll.config.showBroadcast) {
            const rawMsg = scroll.config.broadcastMessage || '[系统] 欢迎冒险家 {player} 踏入这片大陆！';
            const msg = rawMsg.replace(/\{player\}/g, player);
            await scroll.broadcast(msg, instanceId);
        }

        scroll.logger.info(`已为玩家 ${player} 释放迎宾卷轴`);
    });
};
