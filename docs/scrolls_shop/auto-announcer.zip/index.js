/**
 * 卷轴：定时智能公告姬 (Auto Announcer)
 */
module.exports = async function(scroll) {
    let currentIndex = scroll.storage.get('currentIndex', 0);

    const getMessages = () => {
        const raw = scroll.config.messages || '';
        const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);
        if (lines.length === 0) {
            return ['§6[服务器公告] §f欢迎来到服务器，祝您游戏愉快！'];
        }
        return lines;
    };

    const broadcastCurrent = async () => {
        const msgs = getMessages();
        if (msgs.length === 0) return;

        if (currentIndex >= msgs.length) currentIndex = 0;
        const msg = msgs[currentIndex];
        currentIndex = (currentIndex + 1) % msgs.length;
        scroll.storage.set('currentIndex', currentIndex);

        const mode = scroll.config.broadcastMode || 'both';

        if (mode === 'chat' || mode === 'both') {
            await scroll.broadcast(msg);
        }
        if (mode === 'actionbar' || mode === 'both') {
            await scroll.sendActionBar('@a', msg);
        }
        if (scroll.config.enableSound !== false) {
            await scroll.playSound('@a', 'entity.experience_orb.pickup');
        }
        scroll.logger.info('已轮播公告: ' + msg);
    };

    // 1. 定时任务调度
    let intervalMinutes = Number(scroll.config.intervalMinutes) || 5;
    if (intervalMinutes < 1) intervalMinutes = 1;
    scroll.schedule(intervalMinutes * 60 * 1000, async () => {
        await broadcastCurrent();
    });

    // 2. 玩家进服欢迎展示
    scroll.onPlayerJoin(async ({ player }) => {
        if (scroll.config.showOnJoin !== false) {
            await scroll.sleep(3000);
            const msgs = getMessages();
            if (msgs.length > 0 && player) {
                await scroll.sendMessage(player, '§6[公告姬] §f欢迎上线！最新公告：');
                await scroll.sendMessage(player, msgs[0]);
                if (scroll.config.enableSound !== false) {
                    await scroll.playSound(player, 'entity.experience_orb.pickup');
                }
            }
        }
    });

    // 3. 玩家聊天命令查阅
    scroll.onChat(async ({ player, message }) => {
        if (scroll.config.enableChatCommand === false) return;
        const text = (message || '').trim().toLowerCase();
        if (text === '!rules' || text === '!help' || text === '!公告' || text === '!gg' || text === '!rule') {
            const msgs = getMessages();
            await scroll.sendMessage(player, '§6==== §e服务器主要公告与指引 §6====');
            for (const line of msgs) {
                await scroll.sendMessage(player, line);
            }
            await scroll.sendMessage(player, '§6================================');
            if (scroll.config.enableSound !== false) {
                await scroll.playSound(player, 'entity.experience_orb.pickup');
            }
        }
    });

    scroll.logger.info('定时智能公告姬已就绪，当前共配置 ' + getMessages().length + ' 条公告');
};
